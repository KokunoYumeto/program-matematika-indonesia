# D50 common-v2.3.1 candidate adapter

Zero-copy structural index for the Indonesian Smooth Manifolds and Differential Geometry edition. The owner-native backend remains authoritative; learner prose is not copied here. This candidate is not centrally admitted or independently published.
