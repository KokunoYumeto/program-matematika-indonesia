#!/usr/bin/env python3
"""Create and verify a deterministic ZIP from a sealed v2.3.1 adapter."""

from __future__ import annotations

import argparse
import hashlib
import os
import platform
import shutil
import sys
import tempfile
import uuid
import zipfile
import zlib
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True

from v231_adapter_common import AdapterError, compact_json, parse_checksum_file, read_json, require, sha256_file
from validate_lane_adapter_v231 import validate_package


FIXED_TIMESTAMP = (1980, 1, 1, 0, 0, 0)


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _write_zip(files: list[Path], relative_files: list[str], output: Path) -> None:
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as archive:
        for path, relative in zip(files, relative_files, strict=True):
            info = zipfile.ZipInfo(relative, FIXED_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info._compresslevel = 9
            info.file_size = path.stat().st_size
            with path.open("rb") as source, archive.open(info, "w") as target:
                shutil.copyfileobj(source, target, length=1024 * 1024)


def _streams_equal_and_hash(left, right) -> tuple[bool, str]:
    digest = hashlib.sha256()
    while True:
        left_chunk = left.read(1024 * 1024)
        right_chunk = right.read(1024 * 1024)
        if left_chunk != right_chunk:
            return False, digest.hexdigest()
        if not left_chunk:
            return True, digest.hexdigest()
        digest.update(left_chunk)


def _stream_hash(stream) -> str:
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest.hexdigest()


def _verify_zip(
    output: Path,
    files: list[Path],
    relative_files: list[str],
    expected: dict[str, tuple[int, str]],
    *,
    compare_live_sources: bool = True,
) -> None:
    with zipfile.ZipFile(output, "r") as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        require(names == relative_files, "ZIP member order/name drift")
        require(len(names) == len(set(names)), "duplicate ZIP member names")
        require(archive.testzip() is None, "ZIP CRC/test failure")
        for info, path, relative in zip(infos, files, relative_files, strict=True):
            require(info.date_time == FIXED_TIMESTAMP, f"ZIP timestamp drift: {relative}")
            require(info.create_system == 3, f"ZIP creator-system drift: {relative}")
            require((info.external_attr >> 16) == 0o100644, f"ZIP mode drift: {relative}")
            require(info.compress_type == zipfile.ZIP_DEFLATED, f"ZIP compression drift: {relative}")
            expected_bytes, expected_sha256 = expected[relative]
            require(info.file_size == expected_bytes, f"ZIP byte-count mismatch: {relative}")
            if compare_live_sources:
                require(path.stat().st_size == expected_bytes, f"source byte-count changed during ZIP replay: {relative}")
                with archive.open(info, "r") as archived, path.open("rb") as source:
                    identical, archived_sha256 = _streams_equal_and_hash(archived, source)
                    require(identical, f"ZIP byte identity mismatch: {relative}")
            else:
                with archive.open(info, "r") as archived:
                    archived_sha256 = _stream_hash(archived)
            require(archived_sha256 == expected_sha256, f"ZIP member hash differs from frozen package fact: {relative}")


def _verify_sources(
    files: list[Path],
    relative_files: list[str],
    expected: dict[str, tuple[int, str]],
) -> None:
    for path, relative in zip(files, relative_files, strict=True):
        expected_bytes, expected_sha256 = expected[relative]
        require(path.stat().st_size == expected_bytes, f"source byte-count changed before ZIP commit: {relative}")
        require(sha256_file(path) == expected_sha256, f"source hash changed before ZIP commit: {relative}")


def _install_verified_zip(
    staging: Path,
    output: Path,
    *,
    replace: bool,
    original_existed: bool,
    replay_bytes: int,
    replay_sha256: str,
    files: list[Path],
    relative_files: list[str],
    expected: dict[str, tuple[int, str]],
) -> dict[str, object]:
    """Install one verified replay atomically and restore the old ZIP on failure.

    Once final installed-byte verification succeeds, backup deletion is
    post-commit housekeeping.  A transient Windows lock is attempted twice and
    reported without deleting the verified live ZIP or falsely reporting that
    the commit itself failed.
    """

    require(staging.parent == output.parent, "ZIP staging/output parents differ")
    backup: Path | None = None
    installed = False
    if original_existed:
        require(replace, "output exists; pass --replace")
        require(output.is_file() and not output.is_symlink(), "replacement output is not a safe regular file")
        if hasattr(output, "is_junction"):
            require(not output.is_junction(), "replacement output is a junction")
        backup = output.parent / f".{output.name}.rollback.{uuid.uuid4().hex}"
        require(not backup.exists(), "ZIP rollback path unexpectedly exists")
        os.replace(output, backup)
    try:
        if original_existed:
            os.replace(staging, output)
        else:
            # Atomic no-clobber installation: even --replace may not overwrite a
            # path created after the initial absent-state snapshot.
            os.link(staging, output)
            # The destination becomes visible as soon as the hard link is
            # created.  Mark it installed before unlinking the staging name so
            # a staging-name lock rolls the visible destination back instead
            # of raising with an unverified live output.
            installed = True
            staging.unlink()
        installed = True
        require(output.stat().st_size == replay_bytes, "final ZIP byte-count differs from verified replay")
        require(sha256_file(output) == replay_sha256, "final ZIP hash differs from verified replay")
        _verify_zip(output, files, relative_files, expected, compare_live_sources=False)
    except BaseException:
        if installed and output.exists():
            output.unlink()
        if backup is not None and backup.exists():
            os.replace(backup, output)
        raise
    cleanup_error: OSError | None = None
    if backup is not None:
        for _attempt in range(2):
            if not backup.exists():
                break
            try:
                backup.unlink()
                cleanup_error = None
            except OSError as exc:
                cleanup_error = exc
    retained = backup is not None and backup.exists()
    return {
        "previous_zip_existed": original_existed,
        "previous_zip_backup_removed": None if backup is None else not retained,
        "retained_zip_backup_path": str(backup) if retained else None,
        "zip_backup_cleanup_error_type": type(cleanup_error).__name__ if retained and cleanup_error else None,
    }


def _cleanup_temporary_replays(paths: list[Path]) -> dict[str, object]:
    """Best-effort bounded cleanup that never masks the packaging outcome."""

    retained: list[str] = []
    errors: list[dict[str, str]] = []
    for temporary in paths:
        cleanup_error: OSError | None = None
        for _attempt in range(2):
            if not temporary.exists():
                break
            try:
                temporary.unlink()
                cleanup_error = None
            except OSError as exc:
                cleanup_error = exc
        if temporary.exists():
            retained.append(str(temporary))
            if cleanup_error is not None:
                errors.append({
                    "path": str(temporary),
                    "error_type": type(cleanup_error).__name__,
                })
    return {
        "temporary_replay_cleanup_attempts_per_path": 2,
        "retained_temporary_replays": retained,
        "temporary_replay_cleanup_errors": errors,
    }


def package_adapter(package: Path, output: Path, replace: bool) -> dict[str, object]:
    package = package.resolve()
    output = output.resolve()
    require(package.is_dir(), f"adapter package missing: {package}")
    require(not _is_within(output, package), "ZIP output must be outside the adapter package")
    require((package / "manifest.json").is_file(), "adapter manifest missing")
    require((package / "seal.json").is_file(), "adapter seal missing")
    require((package / "PACKAGE_CHECKSUMS.sha256").is_file(), "adapter checksums missing")
    original_existed = output.exists()
    require(not original_existed or replace, "output exists; pass --replace")
    if original_existed:
        require(output.is_file() and not output.is_symlink(), "replacement output is not a safe regular file")

    # Prove the complete generic package contract before reading any member into
    # a release archive. External owner authorities are intentionally optional
    # here; corpus-specific validators bind and replay those separately.
    validation = validate_package(SimpleNamespace(
        package=package,
        repository_root=None,
        owner_package_root=None,
        require_authorities=False,
        build_a=None,
        build_b=None,
    ))
    require(validation.get("status") in {"PASS", "PARTIAL"}, "generic package validation did not pass")
    require(validation.get("manifest_payload", {}).get("files"), "generic package payload validation is missing")
    require(validation.get("seal", {}).get("checksum_entries"), "generic seal/checksum validation is missing")

    checksum_rows = parse_checksum_file(package / "PACKAGE_CHECKSUMS.sha256")
    checksum_map = {relative: digest for digest, relative in checksum_rows}
    require(len(checksum_rows) == len(checksum_map), "duplicate checksum paths")
    require("PACKAGE_CHECKSUMS.sha256" not in checksum_map, "checksum file may not self-list")
    files = sorted(
        (path for path in package.rglob("*") if path.is_file()),
        key=lambda path: path.relative_to(package).as_posix(),
    )
    relative_files = [path.relative_to(package).as_posix() for path in files]
    for path, relative in zip(files, relative_files, strict=True):
        require(not path.is_symlink(), f"symlink package member is forbidden: {relative}")
        if hasattr(path, "is_junction"):
            require(not path.is_junction(), f"junction package member is forbidden: {relative}")
        require(_is_within(path.resolve(), package), f"package member resolves outside root: {relative}")
    require(set(relative_files) == set(checksum_map) | {"PACKAGE_CHECKSUMS.sha256"}, "physical adapter inventory differs from checksum closure")
    expected: dict[str, tuple[int, str]] = {}
    for path, relative in zip(files, relative_files, strict=True):
        if relative != "PACKAGE_CHECKSUMS.sha256":
            require(sha256_file(path) == checksum_map[relative], f"pre-ZIP checksum mismatch: {relative}")
            expected[relative] = (path.stat().st_size, checksum_map[relative])
        else:
            expected[relative] = (path.stat().st_size, sha256_file(path))
    manifest = read_json(package / "manifest.json")
    package_bytes = sum(size for size, _ in expected.values())
    package_seal_sha256 = sha256_file(package / "seal.json")
    package_checksums_sha256 = expected["PACKAGE_CHECKSUMS.sha256"][1]

    output.parent.mkdir(parents=True, exist_ok=True)
    temp_paths: list[Path] = []
    temporary_cleanup: dict[str, object] = {}
    try:
        for replay in ("a", "b"):
            descriptor, temporary_name = tempfile.mkstemp(
                dir=output.parent,
                prefix=f".{output.name}.{replay}.",
                suffix=".tmp",
            )
            os.close(descriptor)
            temporary = Path(temporary_name)
            temp_paths.append(temporary)
            _write_zip(files, relative_files, temporary)
            _verify_zip(temporary, files, relative_files, expected)
        require(temp_paths[0].stat().st_size == temp_paths[1].stat().st_size, "deterministic ZIP replay byte-count mismatch")
        replay_bytes = temp_paths[0].stat().st_size
        replay_sha256 = sha256_file(temp_paths[0])
        require(replay_sha256 == sha256_file(temp_paths[1]), "deterministic ZIP replay hash mismatch")
        with temp_paths[0].open("rb") as replay_a, temp_paths[1].open("rb") as replay_b:
            identical, _ = _streams_equal_and_hash(replay_a, replay_b)
            require(identical, "deterministic ZIP replay byte mismatch")
        # Close the source TOCTOU window before publication. Everything after
        # this point verifies only the already-frozen replay bytes.
        _verify_sources(files, relative_files, expected)
        installation = _install_verified_zip(
            temp_paths[0],
            output,
            replace=replace,
            original_existed=original_existed,
            replay_bytes=replay_bytes,
            replay_sha256=replay_sha256,
            files=files,
            relative_files=relative_files,
            expected=expected,
        )
        temp_paths.pop(0)
    finally:
        # A cleanup lock must neither mask an earlier build/verification error
        # nor turn an already-verified commit into a reported failure.
        temporary_cleanup = _cleanup_temporary_replays(temp_paths)

    return {
        "schema_id": "program-matematika-indonesia/deterministic-lane-adapter-zip/1",
        "status": "PASS",
        "package_id": manifest["package_id"],
        "package_files": len(files),
        "package_bytes": package_bytes,
        "package_seal_sha256": package_seal_sha256,
        "package_checksums_sha256": package_checksums_sha256,
        "zip_filename": output.name,
        "zip_bytes": replay_bytes,
        "zip_sha256": replay_sha256,
        "generic_package_validation": validation["status"],
        "deterministic_zip_replays": 2,
        "deterministic_zip_byte_identity": "pass",
        "member_order": "lexicographic_posix_path",
        "member_timestamp": "1980-01-01T00:00:00",
        "compression": "deflate_level_9",
        "determinism_scope": "same_python_and_zlib_runtime",
        "python_runtime": platform.python_version(),
        "zlib_runtime": zlib.ZLIB_RUNTIME_VERSION,
        "crc_test": "pass",
        "member_byte_identity": "pass",
        **installation,
        **temporary_cleanup,
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replace", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    try:
        print(compact_json(package_adapter(args.package, args.output, args.replace)))
        return 0
    except Exception as exc:
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
