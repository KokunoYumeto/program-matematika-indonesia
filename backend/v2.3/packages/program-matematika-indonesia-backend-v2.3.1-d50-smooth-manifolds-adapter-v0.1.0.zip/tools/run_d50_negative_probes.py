#!/usr/bin/env python3
"""Run bounded mutation probes against a D50 candidate package.

Each probe is executed in a disposable sibling directory.  The canonical
candidate is never edited, and a probe passes only when the D50 validator
rejects the mutation.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

sys.dont_write_bytecode = True

TOOLS_ROOT = Path(__file__).resolve().parent


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for row in rows), encoding="utf-8", newline="\n")


def mutate_authority_hash(root: Path) -> None:
    value = read_json(root / "manifest.json")
    value["authorities"][0]["sha256"] = "0" * 64
    write_json(root / "manifest.json", value)


def mutate_records_hash(root: Path) -> None:
    value = read_json(root / "manifest.json")
    for fact in value["authorities"]:
        if fact.get("role") == "owner_backend_records_jsonl":
            fact["sha256"] = "f" * 64
            break
    write_json(root / "manifest.json", value)


def mutate_duplicate_native(root: Path) -> None:
    path = root / "tables" / "native_bindings.jsonl"
    rows = read_jsonl(path)
    rows[1]["payload"]["native_id"] = rows[0]["payload"]["native_id"]
    write_jsonl(path, rows)


def mutate_dangling_relation(root: Path) -> None:
    path = root / "tables" / "relations.jsonl"
    rows = read_jsonl(path)
    rows[0]["payload"]["to_native_id"] = "o011-nonexistent"
    write_jsonl(path, rows)


def mutate_target_freeze(root: Path) -> None:
    path = root / "D50_TARGET_IDENTITY_INVENTORY.json"
    value = read_json(path)
    value["freeze_before_crosswalk"] = False
    write_json(path, value)


def mutate_semantic_equivalence(root: Path) -> None:
    path = root / "tables" / "identity_crosswalks.jsonl"
    rows = read_jsonl(path)
    rows[0]["payload"]["semantic_equivalence_across_profiles"] = True
    write_jsonl(path, rows)


def mutate_translation_state(root: Path) -> None:
    path = root / "translation-state-index-v0.2.0.json"
    value = read_json(path)
    value["records"][0]["state_inferred"] = True
    write_json(path, value)


def mutate_solution_topology(root: Path) -> None:
    path = root / "D50_NATIVE_PROFILE_SUMMARY.json"
    value = read_json(path)
    # The compact profile sidecar deliberately stores only the native census;
    # perturb that authoritative total to model an invented solution/topology
    # claim without assuming a non-materialized unit_census object.
    value["record_count"] = int(value["record_count"]) + 1
    write_json(path, value)


def mutate_rights_flattening(root: Path) -> None:
    path = root / "rights-assignment-closure-v0.1.0.json"
    value = read_json(path)
    value["profile_rights_remain_distinct"] = False
    write_json(path, value)


def mutate_topology_loss(root: Path) -> None:
    path = root / "tables" / "units.jsonl"
    rows = read_jsonl(path)
    write_jsonl(path, rows[:-1])


def mutate_hosted_html(root: Path) -> None:
    path = root / "tables" / "routes.jsonl"
    rows = read_jsonl(path)
    for row in rows:
        if row["payload"].get("route_kind") == "offline_portable_html_download":
            row["payload"]["hosted_html"] = True
            break
    write_jsonl(path, rows)


def mutate_git_tree(root: Path) -> None:
    path = root / "tables" / "routes.jsonl"
    rows = read_jsonl(path)
    rows[0]["payload"]["url"] = "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id/tree/deadbeef"
    write_jsonl(path, rows)


def mutate_path_leak(root: Path) -> None:
    path = root / "README.md"
    path.write_text(path.read_text(encoding="utf-8") + "\nC:\\Users\\Floris\\private\\scratch\n", encoding="utf-8", newline="\n")


PROBES: list[tuple[str, Callable[[Path], None]]] = [
    ("NP01_changed_owner_manifest_hash", mutate_authority_hash),
    ("NP02_changed_owner_records_hash", mutate_records_hash),
    ("NP03_duplicate_native_identity", mutate_duplicate_native),
    ("NP04_dangling_relation_endpoint", mutate_dangling_relation),
    ("NP05_target_first_crosswalk_violation", mutate_target_freeze),
    ("NP06_semantic_equivalence_inference", mutate_semantic_equivalence),
    ("NP07_translation_state_upgrade", mutate_translation_state),
    ("NP08_solution_completion_invention", mutate_solution_topology),
    ("NP09_rights_component_flattening", mutate_rights_flattening),
    ("NP10_removed_exercise_or_solution_topology", mutate_topology_loss),
    ("NP11_invented_hosted_html_route", mutate_hosted_html),
    ("NP12_invented_git_tree", mutate_git_tree),
    ("NP13_absolute_path_or_credential_leak", mutate_path_leak),
]


def run(args: argparse.Namespace) -> dict[str, Any]:
    package = args.package.resolve()
    results: list[dict[str, Any]] = []
    for name, mutation in PROBES:
        with tempfile.TemporaryDirectory(prefix=f"d50-{name}-", dir=str(package.parent)) as temp:
            mutated = Path(temp) / "package"
            shutil.copytree(package, mutated)
            mutation(mutated)
            command = [
                sys.executable, "-B", str(TOOLS_ROOT / "validate_d50_smooth_manifolds_v231.py"),
                "--package", str(mutated), "--input-contract", str(args.input_contract.resolve()),
                "--repository-root", str(args.repository_root.resolve()),
                "--owner-package-root", str(args.owner_package_root.resolve()),
            ]
            completed = subprocess.run(command, capture_output=True, text=True, check=False)
            results.append({"id": name, "rejected": completed.returncode != 0, "return_code": completed.returncode, "stderr": completed.stderr[-500:]})
    passed = sum(1 for result in results if result["rejected"])
    return {"schema_id": "interlanguage/d50-smooth-manifolds-v231-negative-probes/1", "status": "PASS" if passed == len(results) else "FAIL", "probes": results, "passed": passed, "total": len(results)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--input-contract", type=Path, required=True)
    parser.add_argument("--repository-root", type=Path, required=True)
    parser.add_argument("--owner-package-root", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)
    report = run(args)
    write_json(args.report.resolve(), report)
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
