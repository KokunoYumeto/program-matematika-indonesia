#!/usr/bin/env python3
"""Validate any corpus-neutral backend-v2.3.1 lane-adapter package."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sqlite3
import sys
import tempfile
import uuid
from contextlib import contextmanager
from pathlib import Path, PurePosixPath
from typing import Any, Iterator, Mapping

sys.dont_write_bytecode = True

from jsonschema import Draft202012Validator, FormatChecker

from v231_adapter_common import (
    CAPABILITY_NAMES,
    RECORD_TYPE_BY_TABLE,
    ROW_ENVELOPE_KEYS,
    TABLE_ORDER,
    AdapterError,
    assert_file_fact,
    compact_json,
    inventory_sha256,
    iter_jsonl,
    parse_checksum_file,
    read_json,
    require,
    safe_relative_path,
    sha256_bytes,
    sha256_file,
    tree_identity,
    write_json,
)

csv.field_size_limit(1024 * 1024 * 1024)


SIDECAR_SCHEMAS = {
    "capability-declarations-v0.2.0.json": "capability-declarations-v0.2.schema.json",
    "namespace-crosswalk-v0.2.0.json": "namespace-crosswalk-v0.2.schema.json",
    "translation-state-index-v0.2.0.json": "translation-state-index-v0.2.schema.json",
    "csv-projection-manifest-v0.2.0.json": "csv-projection-manifest-v0.2.schema.json",
    "scope-declaration-v0.2.0.json": "scope-declaration-v0.2.schema.json",
}

TEXT_SUFFIXES = {".json", ".jsonl", ".csv", ".md", ".py", ".txt", ".sha256"}
SECRET_PATTERNS = [
    ("absolute_windows_user_path", re.compile(r"[A-Za-z]:\\Users\\", re.IGNORECASE)),
    ("github_classic_token", re.compile(r"\bghp_[A-Za-z0-9]{30,}\b")),
    ("github_fine_grained_token", re.compile(r"\bgithub_pat_[A-Za-z0-9_]{30,}\b")),
    ("authorization_bearer_header", re.compile(r"Authorization\s*:\s*Bearer\s+[A-Za-z0-9._~+/-]{16,}", re.IGNORECASE)),
    ("zenodo_access_token_query", re.compile(r"access_token=[A-Za-z0-9._~-]{16,}", re.IGNORECASE)),
]


class Utf8HashSink:
    def __init__(self) -> None:
        self.digest = hashlib.sha256()

    def write(self, value: str) -> int:
        self.digest.update(value.encode("utf-8"))
        return len(value)

    def hexdigest(self) -> str:
        return self.digest.hexdigest()


class RecordIndex:
    """Disk-backed index for streamed canonical records and sidecar joins."""

    COMMIT_INTERVAL = 10_000

    def __init__(self, path: Path) -> None:
        self.connection = sqlite3.connect(path)
        try:
            self.connection.execute("PRAGMA journal_mode=DELETE")
            self.connection.execute("PRAGMA synchronous=OFF")
            self.connection.execute("PRAGMA temp_store=FILE")
            self.connection.execute("PRAGMA cache_size=-8192")
            self.connection.executescript(
                """
                CREATE TABLE projected_records (
                    stable_id TEXT NOT NULL PRIMARY KEY,
                    record_type TEXT NOT NULL,
                    semantic_key TEXT NOT NULL,
                    source_table TEXT NOT NULL,
                    source_path TEXT NOT NULL,
                    source_ordinal INTEGER NOT NULL CHECK (source_ordinal > 0),
                    row_sha256 TEXT NOT NULL CHECK (length(row_sha256) = 64),
                    unit_profile_json TEXT,
                    unit_course_json TEXT,
                    UNIQUE (record_type, semantic_key),
                    UNIQUE (source_table, source_ordinal),
                    UNIQUE (source_path, source_ordinal)
                );
                CREATE INDEX projected_records_global_order
                    ON projected_records (record_type, stable_id, source_path, source_ordinal);
                CREATE TABLE crosswalk_pairs (
                    source_namespace TEXT NOT NULL,
                    source_record_id TEXT NOT NULL,
                    target_namespace TEXT NOT NULL,
                    target_record_id TEXT NOT NULL,
                    PRIMARY KEY (
                        source_namespace,
                        source_record_id,
                        target_namespace,
                        target_record_id
                    )
                ) WITHOUT ROWID;
                CREATE TABLE translation_units (
                    projected_unit_id TEXT NOT NULL PRIMARY KEY
                ) WITHOUT ROWID;
                """
            )
        except Exception:
            self.connection.close()
            raise

    def close(self) -> None:
        self.connection.close()

    def commit(self) -> None:
        self.connection.commit()

    def add_record(
        self,
        *,
        stable_id: str,
        record_type: str,
        semantic_key: str,
        source_table: str,
        source_path: str,
        source_ordinal: int,
        row_sha256: str,
        unit_profile_json: str | None,
        unit_course_json: str | None,
    ) -> None:
        try:
            self.connection.execute(
                """
                INSERT INTO projected_records (
                    stable_id,
                    record_type,
                    semantic_key,
                    source_table,
                    source_path,
                    source_ordinal,
                    row_sha256,
                    unit_profile_json,
                    unit_course_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    stable_id,
                    record_type,
                    semantic_key,
                    source_table,
                    source_path,
                    source_ordinal,
                    row_sha256,
                    unit_profile_json,
                    unit_course_json,
                ),
            )
        except sqlite3.IntegrityError as exc:
            duplicate_id = self.connection.execute(
                "SELECT 1 FROM projected_records WHERE stable_id = ?",
                (stable_id,),
            ).fetchone()
            if duplicate_id is not None:
                raise AdapterError(f"duplicate projected ID: {stable_id}") from exc
            duplicate_semantic = self.connection.execute(
                """
                SELECT 1
                FROM projected_records
                WHERE record_type = ? AND semantic_key = ?
                """,
                (record_type, semantic_key),
            ).fetchone()
            if duplicate_semantic is not None:
                raise AdapterError(
                    f"duplicate semantic key: {source_table}:{source_ordinal}"
                ) from exc
            raise AdapterError(
                f"record index constraint failure: {source_table}:{source_ordinal}"
            ) from exc

    def lookup_source(self, source_path: str, source_ordinal: int) -> tuple[str, str, str] | None:
        row = self.connection.execute(
            """
            SELECT stable_id, record_type, row_sha256
            FROM projected_records
            WHERE source_path = ? AND source_ordinal = ?
            """,
            (source_path, source_ordinal),
        ).fetchone()
        return None if row is None else (str(row[0]), str(row[1]), str(row[2]))

    def lookup_id(self, stable_id: str) -> tuple[str, str | None, str | None] | None:
        row = self.connection.execute(
            """
            SELECT record_type, unit_profile_json, unit_course_json
            FROM projected_records
            WHERE stable_id = ?
            """,
            (stable_id,),
        ).fetchone()
        if row is None:
            return None
        return str(row[0]), row[1], row[2]

    def record_count(self) -> int:
        row = self.connection.execute("SELECT count(*) FROM projected_records").fetchone()
        require(row is not None, "record index count query failed")
        return int(row[0])

    def table_count(self, table_name: str) -> int:
        row = self.connection.execute(
            "SELECT count(*) FROM projected_records WHERE source_table = ?",
            (table_name,),
        ).fetchone()
        require(row is not None, f"record index table-count query failed: {table_name}")
        return int(row[0])

    def projected_identity_set_sha256(self) -> str:
        digest = hashlib.sha256()
        cursor = self.connection.execute(
            "SELECT stable_id FROM projected_records ORDER BY stable_id"
        )
        try:
            for (stable_id,) in cursor:
                digest.update((str(stable_id) + "\n").encode("utf-8"))
        finally:
            cursor.close()
        return digest.hexdigest()

    def add_crosswalk_pair(self, pair: tuple[str, str, str, str]) -> bool:
        cursor = self.connection.execute(
            """
            INSERT OR IGNORE INTO crosswalk_pairs (
                source_namespace,
                source_record_id,
                target_namespace,
                target_record_id
            ) VALUES (?, ?, ?, ?)
            """,
            pair,
        )
        inserted = cursor.rowcount == 1
        cursor.close()
        return inserted

    def add_translation_unit(self, projected_unit_id: str) -> bool:
        cursor = self.connection.execute(
            "INSERT OR IGNORE INTO translation_units (projected_unit_id) VALUES (?)",
            (projected_unit_id,),
        )
        inserted = cursor.rowcount == 1
        cursor.close()
        return inserted

    def translation_covers_exact_units(self) -> bool:
        unit_count = self.table_count("units")
        translation_row = self.connection.execute(
            "SELECT count(*) FROM translation_units"
        ).fetchone()
        require(translation_row is not None, "translation index count query failed")
        if int(translation_row[0]) != unit_count:
            return False
        missing = self.connection.execute(
            """
            SELECT 1
            FROM projected_records AS projected
            LEFT JOIN translation_units AS translated
              ON translated.projected_unit_id = projected.stable_id
            WHERE projected.source_table = 'units'
              AND translated.projected_unit_id IS NULL
            LIMIT 1
            """
        ).fetchone()
        if missing is not None:
            return False
        extra = self.connection.execute(
            """
            SELECT 1
            FROM translation_units AS translated
            LEFT JOIN projected_records AS projected
              ON projected.stable_id = translated.projected_unit_id
             AND projected.source_table = 'units'
            WHERE projected.stable_id IS NULL
            LIMIT 1
            """
        ).fetchone()
        return extra is None

    def translation_identity_set_sha256(self) -> str:
        digest = hashlib.sha256()
        cursor = self.connection.execute(
            "SELECT projected_unit_id FROM translation_units ORDER BY projected_unit_id"
        )
        try:
            for (projected_unit_id,) in cursor:
                digest.update((str(projected_unit_id) + "\n").encode("utf-8"))
        finally:
            cursor.close()
        return digest.hexdigest()


@contextmanager
def temporary_record_index(package: Path) -> Iterator[RecordIndex]:
    """Create an out-of-package SQLite index and always remove its directory."""

    try:
        temporary_directory = tempfile.TemporaryDirectory(
            prefix=".v231-validator-",
            dir=package.parent,
        )
    except OSError:
        temporary_directory = tempfile.TemporaryDirectory(prefix="v231-validator-")
    try:
        index = RecordIndex(Path(temporary_directory.name) / "record-index.sqlite3")
        try:
            yield index
        finally:
            index.close()
    finally:
        temporary_directory.cleanup()


def fact_path(root: Path, fact: Mapping[str, Any]) -> Path:
    relative = safe_relative_path(str(fact["path"]))
    return root.joinpath(*PurePosixPath(relative).parts)


def validate_schema(instance: Any, schema_path: Path, label: str) -> None:
    schema = read_json(schema_path)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    first = next(validator.iter_errors(instance), None)
    if first is not None:
        location = "/".join(str(part) for part in first.absolute_path) or "$"
        raise AdapterError(f"schema failure {label} at {location}: {first.message}")


def validate_external_fact(
    fact: Mapping[str, Any],
    repository_root: Path | None,
    owner_root: Path | None,
    require_authorities: bool,
) -> bool:
    base = fact.get("path_base")
    if base == "package_root":
        return True
    root = repository_root if base == "program_repository_root" else owner_root if base == "owner_package_root" else None
    if root is None:
        require(not require_authorities, f"root not supplied for authority: {base}:{fact['path']}")
        return False
    assert_file_fact(root, fact)
    return True


def validate_manifest_files(package: Path, manifest: Mapping[str, Any]) -> dict[str, Any]:
    declared = manifest["files"]
    require(isinstance(declared, list) and declared, "manifest files are empty")
    declared_paths = [safe_relative_path(str(fact["path"])) for fact in declared]
    require(len(declared_paths) == len(set(declared_paths)), "duplicate manifest file paths")
    require(declared_paths == sorted(declared_paths), "manifest payload paths are not sorted")
    for fact in declared:
        require(fact.get("path_base", "package_root") == "package_root", f"manifest payload is not package-root based: {fact['path']}")
        assert_file_fact(package, fact)
    actual = {
        path.relative_to(package).as_posix()
        for path in package.rglob("*")
        if path.is_file() and path.relative_to(package).as_posix() not in {"manifest.json", "seal.json", "PACKAGE_CHECKSUMS.sha256"}
    }
    require(set(declared_paths) == actual, "manifest payload inventory differs from physical package")
    payload_identity = inventory_sha256(declared)
    require(manifest["build"]["build_a_sha256"] == payload_identity, "build A digest does not bind manifest payload")
    require(manifest["build"]["build_b_sha256"] == payload_identity, "build B digest does not bind manifest payload")
    return {"files": len(declared), "bytes": sum(int(fact["bytes"]) for fact in declared), "sha256": payload_identity}


def validate_seal_and_checksums(package: Path, manifest: Mapping[str, Any]) -> dict[str, Any]:
    seal = read_json(package / "seal.json")
    validate_schema(seal, package / "schema" / "adapter-seal-v1.schema.json", "seal.json")
    require(seal.get("algorithm") == "sha256-sorted-path-bytes-v1", "unsupported seal algorithm")
    require(seal.get("seal_excluded_from_own_digest") is True, "seal self-exclusion missing")
    require(seal.get("package_id") == manifest["package_id"], "seal package ID mismatch")
    seal_facts = seal.get("files")
    require(isinstance(seal_facts, list), "seal files missing")
    seal_paths = [safe_relative_path(str(fact["path"])) for fact in seal_facts]
    require(len(seal_paths) == len(set(seal_paths)), "duplicate seal paths")
    require(seal_paths == sorted(seal_paths), "seal paths are not sorted")
    manifest_fact = {
        "path": "manifest.json",
        "bytes": (package / "manifest.json").stat().st_size,
        "sha256": sha256_file(package / "manifest.json"),
    }
    expected = {
        str(fact["path"]): (int(fact["bytes"]), str(fact["sha256"]))
        for fact in list(manifest["files"]) + [manifest_fact]
    }
    observed = {str(fact["path"]): (int(fact["bytes"]), str(fact["sha256"])) for fact in seal_facts}
    require(observed == expected, "seal inventory differs from manifest payload plus manifest")
    for fact in seal_facts:
        assert_file_fact(package, fact)
    require(seal.get("file_count") == len(seal_facts), "seal file count mismatch")
    require(seal.get("bytes") == sum(int(fact["bytes"]) for fact in seal_facts), "seal byte aggregate mismatch")
    require(seal.get("aggregate_sha256") == inventory_sha256(seal_facts), "seal aggregate mismatch")

    checksum_rows = parse_checksum_file(package / "PACKAGE_CHECKSUMS.sha256")
    expected_checksum_paths = {
        path.relative_to(package).as_posix()
        for path in package.rglob("*")
        if path.is_file() and path.relative_to(package).as_posix() != "PACKAGE_CHECKSUMS.sha256"
    }
    require({relative for _, relative in checksum_rows} == expected_checksum_paths, "checksum inventory differs from physical package")
    for digest, relative in checksum_rows:
        path = package.joinpath(*PurePosixPath(relative).parts)
        require(sha256_file(path) == digest, f"checksum mismatch: {relative}")
    return {
        "seal_files": len(seal_facts),
        "seal_sha256": sha256_file(package / "seal.json"),
        "checksum_entries": len(checksum_rows),
        "checksums_sha256": sha256_file(package / "PACKAGE_CHECKSUMS.sha256"),
    }


def validate_tables(package: Path, dataset_id: str, record_index: RecordIndex) -> dict[str, Any]:
    record_counts: dict[str, int] = {}
    for table_name in TABLE_ORDER:
        path = package / "tables" / f"{table_name}.jsonl"
        require(path.is_file(), f"missing canonical table: {table_name}")
        source_path = f"tables/{table_name}.jsonl"
        expected_type = RECORD_TYPE_BY_TABLE[table_name]
        record_count = 0
        for ordinal, row in enumerate(iter_jsonl(path), 1):
            require(set(row) == ROW_ENVELOPE_KEYS, f"bad row envelope: {table_name}:{ordinal}")
            require(row["record_type"] == expected_type, f"record type mismatch: {table_name}:{ordinal}")
            require(row["dataset_id"] == dataset_id, f"dataset mismatch: {table_name}:{ordinal}")
            require(isinstance(row["payload"], dict), f"non-object payload: {table_name}:{ordinal}")
            projected_id = str(row["id"])
            require(projected_id.startswith("urn:uuid:"), f"non-UUID projected ID: {table_name}:{ordinal}")
            try:
                parsed_id = uuid.UUID(projected_id.removeprefix("urn:uuid:"))
            except (ValueError, AttributeError) as exc:
                raise AdapterError(f"non-UUID projected ID: {table_name}:{ordinal}") from exc
            require(projected_id == f"urn:uuid:{parsed_id}", f"non-canonical UUID URN: {table_name}:{ordinal}")
            require(isinstance(row["semantic_key"], str) and bool(row["semantic_key"]), f"empty semantic key: {table_name}:{ordinal}")
            canonical = compact_json(row)
            record_index.add_record(
                stable_id=projected_id,
                record_type=expected_type,
                semantic_key=str(row["semantic_key"]),
                source_table=table_name,
                source_path=source_path,
                source_ordinal=ordinal,
                row_sha256=sha256_bytes((canonical + "\n").encode("utf-8")),
                unit_profile_json=(
                    compact_json(row["payload"].get("profile_id"))
                    if table_name == "units"
                    else None
                ),
                unit_course_json=(
                    compact_json(row["payload"].get("course_id"))
                    if table_name == "units"
                    else None
                ),
            )
            record_count = ordinal
            if ordinal % RecordIndex.COMMIT_INTERVAL == 0:
                record_index.commit()
        record_index.commit()
        record_counts[table_name] = record_count
    total_records = sum(record_counts.values())
    require(record_index.record_count() == total_records, "record index count mismatch")
    return {
        "records": total_records,
        "global_ids": total_records,
        "record_counts": record_counts,
        "identity_set_sha256": record_index.projected_identity_set_sha256(),
    }


def validate_csv(
    package: Path,
    record_index: RecordIndex,
    csv_manifest: Mapping[str, Any],
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    require(csv_manifest["table_order"] == TABLE_ORDER, "CSV table order drift")
    require(csv_manifest["header"] == ["stable_id", "record_type", "canonical_record_json"], "CSV manifest header drift")
    require(csv_manifest["source_tables"] == "tables/*.jsonl", "CSV source-table declaration drift")
    require(csv_manifest["canonical_serialization"] == {
        "aggregate_table_order": "record_type_then_stable_id_then_source_path_then_ordinal",
        "canonical_record_json": "exact_source_jsonl_record",
        "csv_dialect": "RFC4180-compatible quoting",
        "encoding": "UTF-8",
        "newline": "LF",
        "record_terminator": "LF",
        "roundtrip": "csv_to_jsonl_to_csv_byte_identical",
        "table_row_order": "source_jsonl_order",
        "trailing_newline": True,
    }, "CSV canonical-serialization declaration drift")
    entries = csv_manifest["tables"]
    require([entry["table"] for entry in entries] == TABLE_ORDER, "CSV table entries drift")
    manifest_facts = {str(fact["path"]): fact for fact in manifest["files"]}
    csv_facts: list[Mapping[str, Any]] = []
    for entry in entries:
        table_name = entry["table"]
        jsonl_relative = f"tables/{table_name}.jsonl"
        csv_relative = f"csv/{table_name}.csv"
        jsonl_path = package / jsonl_relative
        csv_path = package / csv_relative
        require(entry["source_jsonl"].get("path_base", "package_root") == "package_root", f"CSV source fact is not package-root based: {table_name}")
        require(entry["csv"].get("path_base", "package_root") == "package_root", f"CSV fact is not package-root based: {table_name}")
        require(entry["source_jsonl"]["path"] == jsonl_relative, f"CSV source path drift: {table_name}")
        require(entry["csv"]["path"] == csv_relative, f"CSV path drift: {table_name}")
        require(jsonl_relative in manifest_facts and csv_relative in manifest_facts, f"CSV projection file absent from payload manifest: {table_name}")
        for relative, fact in ((jsonl_relative, entry["source_jsonl"]), (csv_relative, entry["csv"])):
            payload_fact = manifest_facts[relative]
            require(
                int(payload_fact["bytes"]) == int(fact["bytes"])
                and str(payload_fact["sha256"]) == str(fact["sha256"]),
                f"CSV projection fact differs from payload manifest: {relative}",
            )
        assert_file_fact(package, entry["source_jsonl"])
        assert_file_fact(package, entry["csv"])
        canonical_csv_sink = Utf8HashSink()
        canonical_csv_writer = csv.writer(canonical_csv_sink, lineterminator="\n")
        canonical_csv_writer.writerow(["stable_id", "record_type", "canonical_record_json"])
        with csv_path.open("r", encoding="utf-8", newline="") as stream:
            reader = csv.reader(stream)
            header = next(reader, None)
            require(header == ["stable_id", "record_type", "canonical_record_json"], f"CSV header mismatch: {table_name}")
            roundtrip = hashlib.sha256()
            source_rows = 0
            for ordinal, record in enumerate(iter_jsonl(jsonl_path), 1):
                csv_row = next(reader, None)
                require(csv_row is not None, f"CSV row count mismatch: {table_name}")
                require(len(csv_row) == 3, f"CSV width mismatch: {table_name}:{ordinal}")
                require(csv_row[0] == record["id"] and csv_row[1] == record["record_type"], f"CSV identity mismatch: {table_name}:{ordinal}")
                canonical = compact_json(record)
                require(csv_row[2] == canonical, f"CSV canonical JSON mismatch: {table_name}:{ordinal}")
                row_sha256 = sha256_bytes((canonical + "\n").encode("utf-8"))
                indexed = record_index.lookup_source(jsonl_relative, ordinal)
                require(
                    indexed == (str(record["id"]), str(record["record_type"]), row_sha256),
                    f"record index differs from source JSONL: {table_name}:{ordinal}",
                )
                canonical_csv_writer.writerow([str(record["id"]), str(record["record_type"]), canonical])
                roundtrip.update((canonical + "\n").encode("utf-8"))
                source_rows = ordinal
            require(next(reader, None) is None, f"CSV has extra rows: {table_name}")
        require(canonical_csv_sink.hexdigest() == entry["csv"]["sha256"], f"CSV byte canonicality mismatch: {table_name}")
        require(source_rows == record_index.table_count(table_name), f"record index row count mismatch: {table_name}")
        require(source_rows == entry["records"], f"CSV declared row count mismatch: {table_name}")
        require(roundtrip.hexdigest() == sha256_file(jsonl_path), f"CSV round trip mismatch: {table_name}")
        require(entry["roundtrip_sha256"] == roundtrip.hexdigest(), f"CSV roundtrip digest mismatch: {table_name}")
        require(entry["roundtrip_state"] == "pass", f"CSV roundtrip state mismatch: {table_name}")
        csv_facts.append(entry["csv"])

    total_records = record_index.record_count()
    global_csv_sink = Utf8HashSink()
    global_csv_writer = csv.writer(global_csv_sink, lineterminator="\n")
    global_csv_writer.writerow(["source_jsonl_path", "source_row_ordinal", "stable_id", "record_type", "canonical_record_json"])
    with (package / "records.csv").open("r", encoding="utf-8", newline="") as stream:
        reader = csv.reader(stream)
        header = next(reader, None)
        require(header == ["source_jsonl_path", "source_row_ordinal", "stable_id", "record_type", "canonical_record_json"], "global CSV header mismatch")
        global_roundtrip = hashlib.sha256()
        global_records = 0
        previous_order_key: tuple[str, str, str, int] | None = None
        for csv_row in reader:
            global_records += 1
            require(global_records <= total_records, "global CSV has extra rows")
            require(len(csv_row) == 5, f"global CSV width mismatch: row {global_records}")
            source_path = csv_row[0]
            try:
                ordinal = int(csv_row[1])
            except ValueError as exc:
                raise AdapterError(
                    f"global CSV projection mismatch: {source_path}:{csv_row[1]}"
                ) from exc
            require(
                ordinal > 0 and csv_row[1] == str(ordinal),
                f"global CSV projection mismatch: {source_path}:{csv_row[1]}",
            )
            indexed = record_index.lookup_source(source_path, ordinal)
            require(indexed is not None, f"global CSV projection mismatch: {source_path}:{ordinal}")
            stable_id, record_type, row_sha256 = indexed
            require(
                csv_row[2] == stable_id and csv_row[3] == record_type,
                f"global CSV projection mismatch: {source_path}:{ordinal}",
            )
            order_key = (record_type, stable_id, source_path, ordinal)
            require(
                previous_order_key is None or previous_order_key < order_key,
                f"global CSV ordering mismatch: {source_path}:{ordinal}",
            )
            previous_order_key = order_key
            canonical = csv_row[4]
            try:
                record = json.loads(canonical)
            except json.JSONDecodeError as exc:
                raise AdapterError(
                    f"global CSV canonical JSON mismatch: {source_path}:{ordinal}"
                ) from exc
            require(isinstance(record, dict), f"global CSV canonical JSON mismatch: {source_path}:{ordinal}")
            require(compact_json(record) == canonical, f"global CSV canonical JSON mismatch: {source_path}:{ordinal}")
            require(
                sha256_bytes((canonical + "\n").encode("utf-8")) == row_sha256,
                f"global CSV row hash mismatch: {source_path}:{ordinal}",
            )
            global_csv_writer.writerow([source_path, str(ordinal), stable_id, record_type, canonical])
            global_roundtrip.update((canonical + "\n").encode("utf-8"))
        require(global_records == total_records, "global CSV row count mismatch")
    records_fact = csv_manifest["records_csv"]
    require(records_fact.get("path_base", "package_root") == "package_root", "global CSV fact is not package-root based")
    require(records_fact["path"] == "records.csv", "global CSV path drift")
    require("records.csv" in manifest_facts, "global CSV absent from payload manifest")
    require(
        int(manifest_facts["records.csv"]["bytes"]) == int(records_fact["bytes"])
        and str(manifest_facts["records.csv"]["sha256"]) == str(records_fact["sha256"]),
        "global CSV fact differs from payload manifest",
    )
    assert_file_fact(package, records_fact)
    require(global_csv_sink.hexdigest() == records_fact["sha256"], "global CSV byte canonicality mismatch")
    require(records_fact["records"] == total_records, "global CSV record count mismatch")
    require(records_fact["roundtrip_sha256"] == global_roundtrip.hexdigest(), "global CSV roundtrip digest mismatch")
    csv_facts.append(records_fact)
    require(csv_manifest["aggregate_sha256"] == inventory_sha256(csv_facts), "CSV aggregate digest mismatch")
    return {"tables": len(entries), "records": total_records, "roundtrip": "pass", "streamed": True}


def validate_sidecars(package: Path, manifest: Mapping[str, Any], record_index: RecordIndex) -> dict[str, Any]:
    package_id = manifest["package_id"]
    dataset_id = manifest["dataset_id"]
    schema_root = package / "schema"
    sidecars: dict[str, Any] = {}
    declared_sidecar_rows = [safe_relative_path(str(fact["path"])) for fact in manifest["sidecars"]]
    require(len(declared_sidecar_rows) == len(set(declared_sidecar_rows)), "duplicate manifest sidecar paths")
    declared_sidecars = set(declared_sidecar_rows)
    require(
        set(SIDECAR_SCHEMAS).issubset(declared_sidecars),
        "manifest sidecars omit a required standard sidecar",
    )
    require(
        safe_relative_path(str(manifest["scope_declaration"]["path"]))
        == "scope-declaration-v0.2.0.json",
        "manifest scope declaration points to a different file",
    )
    require("scope-declaration-v0.2.0.json" in declared_sidecars, "scope declaration is not declared as a sidecar")
    require(
        safe_relative_path(str(manifest["csv_projection"]["manifest"]["path"]))
        == "csv-projection-manifest-v0.2.0.json",
        "manifest CSV projection points to a different file",
    )
    require("csv-projection-manifest-v0.2.0.json" in declared_sidecars, "CSV projection manifest is not declared as a sidecar")
    for filename, schema_name in SIDECAR_SCHEMAS.items():
        instance = read_json(package / filename)
        validate_schema(instance, schema_root / schema_name, filename)
        require(instance["package_id"] == package_id, f"sidecar package ID mismatch: {filename}")
        if "dataset_id" in instance:
            require(instance["dataset_id"] == dataset_id, f"sidecar dataset ID mismatch: {filename}")
        sidecars[filename] = instance

    capability = sidecars["capability-declarations-v0.2.0.json"]
    names = [row["name"] for row in capability["capabilities"]]
    require(names == CAPABILITY_NAMES, "capability names/order drift")
    require(len(set(names)) == 10, "duplicate capability names")
    authority_identities = {
        (str(fact.get("path_base")), str(fact["path"]), int(fact["bytes"]), str(fact["sha256"]))
        for fact in manifest["authorities"]
    }
    nested_facts = [capability["contract_binding"]]
    for row in capability["capabilities"]:
        state = row["state"]
        native_count = int(row["native_count"])
        projected_count = int(row["projected_count"])
        identity_digest = row["identity_set_sha256"]
        identity_scope = row["identity_set_scope"]
        shard_refs = row["shard_refs"]
        if row["schema_binding"] is not None:
            nested_facts.append(row["schema_binding"])
        nested_facts.extend(shard_refs)
        if state == "materialized":
            require(projected_count > 0, f"materialized capability has no projected rows: {row['name']}")
            require(isinstance(identity_digest, str), f"materialized capability lacks identity digest: {row['name']}")
            require(identity_scope == "projected_records", f"materialized capability has wrong identity scope: {row['name']}")
        elif state == "referenced_native_shards":
            require(native_count > 0 and bool(shard_refs), f"native-shard capability lacks native closure: {row['name']}")
            require(isinstance(identity_digest, str), f"native-shard capability lacks identity digest: {row['name']}")
            require(identity_scope in {"native_shard_records", "projected_records"}, f"native-shard capability has wrong identity scope: {row['name']}")
        elif state in {"not_projected", "absent"}:
            require(projected_count == 0, f"unprojected capability claims projected rows: {row['name']}")
            require(identity_digest is None and identity_scope == "none", f"unprojected capability claims an identity set: {row['name']}")
    nested_facts.extend(capability["rights_cross_cutting"]["shard_refs"])
    for fact in nested_facts:
        require(isinstance(fact, Mapping), "capability binding fact is null or non-object")
        identity = (
            str(fact.get("path_base")), str(fact["path"]),
            int(fact["bytes"]), str(fact["sha256"]),
        )
        require(identity in authority_identities, f"capability binding is absent from manifest authorities: {fact['path']}")

    scope = sidecars["scope-declaration-v0.2.0.json"]
    require(scope["aggregate_conformance_claim"] is False, "aggregate conformance claim must remain false")
    require(scope["scope_kind"] == "lane_adapter", "scope is not lane-adapter")
    require(scope["course_ids"] and scope["curriculum_role_ids"], "lane scope is empty")
    scope_authority = scope.get("curriculum_authority_binding")
    require(isinstance(scope_authority, Mapping), "scope curriculum authority binding is missing")
    require(
        (
            str(scope_authority.get("path_base")), str(scope_authority["path"]),
            int(scope_authority["bytes"]), str(scope_authority["sha256"]),
        ) in authority_identities,
        "scope curriculum authority is absent from manifest authorities",
    )

    crosswalk = sidecars["namespace-crosswalk-v0.2.0.json"]
    materialized_types = set(RECORD_TYPE_BY_TABLE.values())
    for mapping_ordinal, mapping in enumerate(crosswalk["mappings"], 1):
        key = (
            mapping["source_namespace"],
            mapping["source_record_id"],
            mapping["target_namespace"],
            mapping["target_record_id"],
        )
        require(record_index.add_crosswalk_pair(key), "duplicate namespace mapping")
        if mapping["target_record_type"] in materialized_types:
            target_id = str(mapping["target_record_id"])
            target = record_index.lookup_id(target_id)
            require(target is not None, f"crosswalk target is not materialized: {target_id}")
            require(
                target[0] == mapping["target_record_type"],
                f"crosswalk target type differs from materialized record: {target_id}",
            )
        if mapping_ordinal % RecordIndex.COMMIT_INTERVAL == 0:
            record_index.commit()
    record_index.commit()

    translation = sidecars["translation-state-index-v0.2.0.json"]
    records = translation["records"]
    require(translation["coverage"]["indexed_rows"] == len(records), "translation indexed-row count mismatch")
    require(translation["coverage"]["authority_rows"] == len(records), "translation authority-row count mismatch")
    require(translation["coverage"]["inferred_rows"] == 0 and translation["no_inference"] is True, "translation index infers state")
    for record_ordinal, row in enumerate(records, 1):
        projected_unit_id = str(row["projected_unit_id"])
        require(
            record_index.add_translation_unit(projected_unit_id),
            "duplicate translation-state unit IDs",
        )
        if record_ordinal % RecordIndex.COMMIT_INTERVAL == 0:
            record_index.commit()
    record_index.commit()
    require(
        record_index.translation_covers_exact_units(),
        "translation index does not cover the exact materialized unit set",
    )
    for row in records:
        projected_unit_id = str(row["projected_unit_id"])
        unit = record_index.lookup_id(projected_unit_id)
        require(
            unit is not None and unit[0] == RECORD_TYPE_BY_TABLE["units"],
            "translation index does not cover the exact materialized unit set",
        )
        unit_profile = json.loads(unit[1]) if unit[1] is not None else None
        unit_course = json.loads(unit[2]) if unit[2] is not None else None
        require(row["state_inferred"] is False, f"translation state is inferred: {row['projected_unit_id']}")
        require(row["profile_id"] == unit_profile, f"translation profile differs from unit: {row['projected_unit_id']}")
        require(row["course_id"] == unit_course, f"translation course differs from unit: {row['projected_unit_id']}")
    for fact in translation["authority_bindings"]:
        identity = (
            str(fact.get("path_base")), str(fact["path"]),
            int(fact["bytes"]), str(fact["sha256"]),
        )
        require(identity in authority_identities, f"translation authority is absent from manifest authorities: {fact['path']}")
    require(
        translation["identity_set_sha256"] == record_index.translation_identity_set_sha256(),
        "translation identity-set digest mismatch",
    )

    return {
        "capabilities": len(names),
        "namespace_mappings": len(crosswalk["mappings"]),
        "translation_rows": len(records),
        "scope_roles": scope["curriculum_role_ids"],
        "csv": validate_csv(package, record_index, sidecars["csv-projection-manifest-v0.2.0.json"], manifest),
    }


def validate_no_leaks(package: Path) -> dict[str, Any]:
    scanned = 0
    for path in sorted(item for item in package.rglob("*") if item.is_file() and item.suffix.lower() in TEXT_SUFFIXES):
        try:
            with path.open("r", encoding="utf-8", newline="") as stream:
                overlap = ""
                while True:
                    chunk = stream.read(1024 * 1024)
                    if not chunk:
                        break
                    text = overlap + chunk
                    for label, pattern in SECRET_PATTERNS:
                        require(not pattern.search(text), f"privacy/credential pattern {label}: {path.relative_to(package).as_posix()}")
                    overlap = text[-4096:]
        except UnicodeDecodeError as exc:
            raise AdapterError(f"text-like file is not UTF-8: {path.relative_to(package).as_posix()}") from exc
        scanned += 1
    return {"text_files_scanned": scanned, "credential_or_local_path_hits": 0}


def validate_package(args: argparse.Namespace) -> dict[str, Any]:
    package = args.package.resolve()
    require(package.is_dir(), f"package directory missing: {package}")
    manifest = read_json(package / "manifest.json")
    schema_path = package / "schema" / "lane-adapter-v2.3.1.schema.json"
    validate_schema(manifest, schema_path, "manifest.json")
    require(manifest["schema_version"] == "2.3.1", "wrong adapter contract")
    require(manifest["zero_copy_policy"] == {
        "owner_native_authoritative": True,
        "full_prose_centralized": False,
        "owner_ids_reminted": False,
        "aggregate_conformance_claim": False,
        "machine_data_is_learner_destination": False,
        "machine_surfaces_secondary": True,
    }, "zero-copy policy drift")
    seal_binds = manifest["seal_policy"]["binds"]
    require(len(seal_binds) == len(set(seal_binds)), "duplicate seal-policy binding declarations")
    require(
        set(seal_binds) >= {
            "schemas", "tools", "input_authorities", "tables", "sidecars",
            "csv_projections", "manifest",
        },
        "seal-policy binding declaration is incomplete",
    )

    manifest_payload = validate_manifest_files(package, manifest)
    payload_facts = {safe_relative_path(str(fact["path"])): fact for fact in manifest["files"]}

    def require_payload_binding(fact: Mapping[str, Any], label: str) -> None:
        require(fact.get("path_base", "package_root") == "package_root", f"manifest {label} is not package-root based")
        relative = safe_relative_path(str(fact["path"]))
        require(relative in payload_facts, f"manifest {label} is not sealed as package payload")
        payload_fact = payload_facts[relative]
        require(
            int(payload_fact["bytes"]) == int(fact["bytes"])
            and str(payload_fact["sha256"]) == str(fact["sha256"]),
            f"manifest {label} payload binding differs",
        )

    authority_checked = 0
    for fact in manifest["authorities"]:
        if fact.get("path_base") == "package_root":
            assert_file_fact(package, fact)
            require_payload_binding(fact, f"package authority {fact['path']}")
            authority_checked += 1
        elif validate_external_fact(fact, args.repository_root, args.owner_package_root, args.require_authorities):
            authority_checked += 1
    assert_file_fact(package, manifest["scope_declaration"])
    require_payload_binding(manifest["scope_declaration"], "scope declaration")
    for fact in manifest["sidecars"]:
        assert_file_fact(package, fact)
        require_payload_binding(fact, f"sidecar {fact['path']}")
    assert_file_fact(package, manifest["csv_projection"]["manifest"])
    require_payload_binding(manifest["csv_projection"]["manifest"], "CSV projection manifest")
    assert_file_fact(package, manifest["build"]["builder"])
    assert_file_fact(package, manifest["build"]["validator"])
    for label in ("builder", "validator"):
        fact = manifest["build"][label]
        require_payload_binding(fact, label)

    with temporary_record_index(package) as record_index:
        table_report = validate_tables(package, manifest["dataset_id"], record_index)
        require(manifest["csv_projection"]["record_count"] == table_report["records"], "manifest record count mismatch")
        require(manifest["csv_projection"]["table_csv_count"] == len(TABLE_ORDER), "manifest CSV table count mismatch")
        sidecar_report = validate_sidecars(package, manifest, record_index)
    seal_report = validate_seal_and_checksums(package, manifest)
    privacy_report = validate_no_leaks(package)

    deterministic_report: dict[str, Any] = {"supplied": False}
    if args.build_a or args.build_b:
        require(args.build_a is not None and args.build_b is not None, "both --build-a and --build-b are required")
        build_a = args.build_a.resolve()
        build_b = args.build_b.resolve()
        require(build_a != build_b, "A/B build roots must be distinct")
        identity_a = tree_identity(build_a)
        identity_b = tree_identity(build_b)
        require(identity_a == identity_b, "full A/B package trees are not byte-identical")
        require(identity_a == tree_identity(package), "validated package differs from supplied A/B builds")
        deterministic_report = {"supplied": True, "tree_sha256": identity_a, "byte_identical": True}

    authority_closure_complete = authority_checked == len(manifest["authorities"])
    return {
        "schema_id": "program-matematika-indonesia/generic-v2.3.1-adapter-validation/1",
        "status": "PASS" if authority_closure_complete else "PARTIAL",
        "package_id": manifest["package_id"],
        "dataset_id": manifest["dataset_id"],
        "extension_id": manifest["extension_id"],
        "extension_version": manifest["extension_version"],
        "manifest": {"bytes": (package / "manifest.json").stat().st_size, "sha256": sha256_file(package / "manifest.json")},
        "manifest_payload": manifest_payload,
        "authorities": {
            "declared": len(manifest["authorities"]),
            "locally_replayed": authority_checked,
            "closure_complete": authority_closure_complete,
        },
        "tables": table_report,
        "sidecars": sidecar_report,
        "seal": seal_report,
        "privacy": privacy_report,
        "deterministic_ab": deterministic_report,
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--repository-root", type=Path)
    parser.add_argument("--owner-package-root", type=Path)
    parser.add_argument("--require-authorities", action="store_true")
    parser.add_argument("--build-a", type=Path)
    parser.add_argument("--build-b", type=Path)
    parser.add_argument("--report", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    if args.report:
        report = args.report.resolve()
        protected = [args.package.resolve()]
        protected.extend(
            path.resolve() for path in (args.build_a, args.build_b) if path is not None
        )
        if any(report == root or report.is_relative_to(root) for root in protected):
            print("FAIL: AdapterError: report path must be outside package and A/B build roots", file=sys.stderr)
            return 1
    try:
        report = validate_package(args)
        if args.report:
            write_json(args.report, report)
        print(compact_json(report))
        return 0 if report["status"] == "PASS" else 2
    except Exception as exc:
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
