#!/usr/bin/env python3
"""Validate the D50-specific closure on top of common adapter-v2.3.1 gates.

The common validator owns the interchange contract.  This wrapper adds only
facts which are specific to the frozen Brenner/O011 authority: the 6,912-row
native closure, the D50 target inventory, rights-assignment count, and the
truthful learner-route limits.  It never invokes the owner generator and it
never writes to an owner or central tree.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Mapping

sys.dont_write_bytecode = True

TOOLS_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS_ROOT))

from v231_adapter_common import (  # noqa: E402
    AdapterError,
    TABLE_ORDER,
    compact_json,
    iter_jsonl,
    read_json,
    require,
    sha256_bytes,
    sha256_file,
    write_json,
)
from validate_lane_adapter_v231 import (  # noqa: E402
    validate_package as validate_generic_package,
)


EXPECTED_NATIVE = 6912
EXPECTED_RIGHTS_ASSIGNMENTS = 2089
EXPECTED_COUNTS = {
    "artifact": 687,
    "asset": 38,
    "concept": 39,
    "correction": 319,
    "course": 1,
    "edition": 1,
    "program": 1,
    "qa_event": 370,
    "relation": 3951,
    "resource": 1,
    "rights": 43,
    "segment": 160,
    "term": 95,
    "unit": 1206,
}
PROSE_KEYS = {
    "description", "source_text", "target_text", "text", "body", "content",
    "statement", "wording", "hint", "answer", "solution", "solution_text",
    "prompt", "question", "explanation", "notes", "source_body", "target_body",
}
LOCAL_PATH_RE = re.compile(r"[A-Za-z]:\\Users\\", re.IGNORECASE)


def _walk_keys(value: Any, *, path: str = "") -> list[str]:
    hits: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            key_path = f"{path}.{key}" if path else str(key)
            if str(key).lower() in PROSE_KEYS:
                hits.append(key_path)
            hits.extend(_walk_keys(child, path=key_path))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            hits.extend(_walk_keys(child, path=f"{path}[{index}]"))
    return hits


def _rows(package: Path, table: str) -> list[dict[str, Any]]:
    return list(iter_jsonl(package / "tables" / f"{table}.jsonl"))


def _check_file_identity(package: Path, fact: Mapping[str, Any]) -> None:
    path = package / str(fact["path"])
    require(path.is_file(), f"D50 required file missing: {fact['path']}")
    require(path.stat().st_size == int(fact["bytes"]), f"D50 byte drift: {fact['path']}")
    require(sha256_file(path) == str(fact["sha256"]), f"D50 hash drift: {fact['path']}")


def _custom_checks(package: Path, contract: Mapping[str, Any], generic: Mapping[str, Any]) -> dict[str, Any]:
    manifest = read_json(package / "manifest.json")
    require(manifest["extension_version"] == "0.1.0", "D50 extension version drift")
    require(manifest["dataset_id"].startswith("urn:uuid:"), "D50 dataset identity is not UUID-based")

    input_authorities = read_json(package / "D50_INPUT_AUTHORITIES.json")
    require(input_authorities["schema_id"] == "interlanguage/d50-input-authorities/1.0.0", "D50 input-authority schema drift")
    require(input_authorities["owner_native_records"] == EXPECTED_NATIVE, "D50 native record count drift")
    require(input_authorities["owner_native_non_mutation"] is True, "D50 owner mutation boundary changed")
    require(input_authorities["authorities"] == contract["local_inputs"], "D50 local input contract drift")
    require(input_authorities["program_inputs"] == contract["program_inputs"], "D50 program input contract drift")

    profile = read_json(package / "D50_NATIVE_PROFILE_SUMMARY.json")
    require(profile["record_count"] == EXPECTED_NATIVE, "D50 profile record count drift")
    require(profile["entity_counts"] == EXPECTED_COUNTS, "D50 native entity census drift")
    require(profile["native_binding_rows"] == EXPECTED_NATIVE, "D50 native-binding closure drift")
    require(profile["rights_assignment_count"] == EXPECTED_RIGHTS_ASSIGNMENTS, "D50 rights assignment count drift")
    require(profile["full_prose_copied"] is False, "D50 full-prose copy policy drift")
    require(
        set(profile["direct_target_classes"])
        == {"program", "course", "resource", "edition", "unit", "relation", "rights", "artifact", "qa_event"},
        "D50 direct-target class contract drift",
    )
    require(set(profile["hash_only_classes"]) == {"asset", "segment"}, "D50 hash-only class contract drift")
    require(set(profile["lineage_only_classes"]) == {"concept", "term", "correction"}, "D50 lineage-only class contract drift")

    target_inventory = read_json(package / "D50_TARGET_IDENTITY_INVENTORY.json")
    require(target_inventory["freeze_before_crosswalk"] is True, "D50 target-first freeze was disabled")
    target_rows: dict[tuple[str, str], dict[str, Any]] = {}
    for item in target_inventory["targets"]:
        key = (str(item["table"]), str(item["id"]))
        require(key not in target_rows, f"duplicate D50 target identity: {key}")
        target_rows[key] = item
    require(target_inventory["target_count"] == len(target_rows), "D50 target inventory count drift")
    for table in TABLE_ORDER:
        for row in _rows(package, table):
            key = (table, str(row["id"]))
            item = target_rows.get(key)
            require(item is not None, f"target inventory omits {table}:{row['id']}")
            observed = sha256_bytes((compact_json(row) + "\n").encode("utf-8"))
            require(observed == item["sha256"], f"target inventory hash drift: {table}:{row['id']}")

    native_bindings = _rows(package, "native_bindings")
    native_keys = {(str(row["payload"].get("native_profile")), str(row["payload"].get("native_id"))) for row in native_bindings}
    require(len(native_bindings) == EXPECTED_NATIVE, "D50 native-binding row count drift")
    require(len(native_keys) == EXPECTED_NATIVE, "D50 duplicate native identity")
    require(all(row["payload"].get("full_prose_copied") is False for row in native_bindings), "D50 native binding copied prose")

    rights_closure = read_json(package / "rights-assignment-closure-v0.1.0.json")
    require(rights_closure["assignment_count"] == EXPECTED_RIGHTS_ASSIGNMENTS, "D50 rights closure count drift")
    require(rights_closure["materialized_assignments"] == EXPECTED_RIGHTS_ASSIGNMENTS, "D50 materialized rights count drift")
    require(rights_closure["profile_rights_remain_distinct"] is True, "D50 rights components were flattened")
    require(rights_closure["format_specific_notices_remain_distinct"] is True, "D50 format-specific rights were flattened")
    require(rights_closure["rights_assignment_resolution_is_legal_transfer_evidence"] is False, "D50 rights resolution overclaims legal transfer")

    loss = read_json(package / "D50_LOSS_ACCOUNTING.json")
    require(loss["native_record_total"] == EXPECTED_NATIVE, "D50 loss ledger native total drift")
    require(loss["classified_once"] is True and loss["unmapped_native_rows_are_not_dropped"] is True, "D50 loss ledger closure flags drift")
    require(sum(int(row["native_records"]) for row in loss["rows"]) == EXPECTED_NATIVE, "D50 loss ledger does not cover native rows")
    require(all(int(row["native_binding_records"]) == int(row["native_records"]) for row in loss["rows"]), "D50 loss ledger binding coverage drift")
    expected_loss_classes = {
        **{key: "direct_target" for key in profile["direct_target_classes"]},
        **{key: "hash_only" for key in profile["hash_only_classes"]},
        **{key: "lineage_only" for key in profile["lineage_only_classes"]},
    }
    loss_by_collection = {str(row["native_collection"]): row for row in loss["rows"]}
    require(set(loss_by_collection) == set(EXPECTED_COUNTS), "D50 loss ledger collection census drift")
    for collection, expected_count in EXPECTED_COUNTS.items():
        row = loss_by_collection[collection]
        require(row["mapping_class"] == expected_loss_classes[collection], f"D50 loss class drift: {collection}")
        require(int(row["native_records"]) == expected_count, f"D50 loss native count drift: {collection}")
        expected_common = expected_count if expected_loss_classes[collection] != "lineage_only" else 0
        require(int(row["common_target_records"]) == expected_common, f"D50 loss common-target count drift: {collection}")

    route_rows = _rows(package, "routes")
    require(len(route_rows) == 5, "D50 route count drift")
    for row in route_rows:
        payload = row["payload"]
        url = str(payload.get("url", ""))
        require("/tree/" not in url and "/blob/" not in url, "D50 route invents an unverified Git tree/blob")
        if payload.get("route_kind") == "offline_portable_html_download":
            require(payload.get("hosted_html") is False, "D50 invented hosted HTML route")
            require(payload.get("adapter_consumption") is False, "D50 HTML route claims adapter consumption")
    readers = _rows(package, "reader_surfaces")
    require(len(readers) == 2, "D50 reader-surface count drift")
    pdf = next((row["payload"] for row in readers if row["payload"].get("format") == "linked_pdf"), None)
    html = next((row["payload"] for row in readers if row["payload"].get("format") == "portable_html_zip"), None)
    require(pdf is not None and pdf.get("primary") is True and pdf.get("pages") == 712, "D50 primary PDF route drift")
    require(html is not None and html.get("offline") is True and html.get("hosted") is False, "D50 offline HTML truthfulness drift")

    # No prose fields may occur in projected payloads.  Titles and labels are
    # intentionally allowed; the adapter is a structural, zero-copy index.
    prose_hits: list[str] = []
    for table in TABLE_ORDER:
        for ordinal, row in enumerate(_rows(package, table), 1):
            prose_hits.extend(f"tables/{table}.jsonl:{ordinal}:{hit}" for hit in _walk_keys(row.get("payload", {})))
    require(not prose_hits, f"D50 projected prose fields present: {prose_hits[:3]}")

    # The package may contain only relative paths; this is stricter than the
    # generic leak check and protects copied research/receipt controls too.
    for path in package.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".json", ".jsonl", ".csv", ".md", ".py", ".txt", ".sha256"}:
            text = path.read_text(encoding="utf-8")
            require(not LOCAL_PATH_RE.search(text), f"D50 absolute user path leaked: {path.relative_to(package).as_posix()}")

    return {
        "native_records": EXPECTED_NATIVE,
        "native_entity_counts": EXPECTED_COUNTS,
        "native_bindings": len(native_bindings),
        "target_inventory": len(target_rows),
        "rights_assignments": EXPECTED_RIGHTS_ASSIGNMENTS,
        "routes": len(route_rows),
        "reader_surfaces": len(readers),
        "zero_copy_prose_fields": 0,
        "owner_mutation": False,
        "central_mutation": False,
        "generic_status": generic["status"],
    }


def validate_d50(args: argparse.Namespace) -> dict[str, Any]:
    package = args.package.resolve()
    contract_path = args.input_contract.resolve() if args.input_contract else package.parent / "D50_BUILDER_INPUT_CONTRACT.json"
    contract = read_json(contract_path)
    require(contract["role"] == "D50" and contract["state"] == "frozen_candidate_r1", "D50 input contract is not frozen")
    generic_args = argparse.Namespace(
        package=package,
        repository_root=args.repository_root.resolve() if args.repository_root else None,
        owner_package_root=args.owner_package_root.resolve() if args.owner_package_root else None,
        require_authorities=True,
        build_a=args.build_a.resolve() if args.build_a else None,
        build_b=args.build_b.resolve() if args.build_b else None,
    )
    generic = validate_generic_package(generic_args)
    custom = _custom_checks(package, contract, generic)
    return {
        "schema_id": "interlanguage/d50-smooth-manifolds-v231-validation/1",
        "status": "PASS",
        "package": str(package),
        "package_tree_sha256": read_json(package / "seal.json")["aggregate_sha256"],
        "generic": generic,
        "d50": custom,
        "recorded_at": "2026-09-01T00:00:00Z",
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--input-contract", type=Path)
    parser.add_argument("--repository-root", type=Path)
    parser.add_argument("--owner-package-root", type=Path)
    parser.add_argument("--build-a", type=Path)
    parser.add_argument("--build-b", type=Path)
    parser.add_argument("--report", type=Path)
    return parser.parse_args(sys.argv[1:] if argv is None else argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        report = validate_d50(args)
        if args.report:
            write_json(args.report.resolve(), report)
        print(compact_json(report))
        return 0
    except Exception as exc:
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
