#!/usr/bin/env python3
"""Build the bounded, zero-copy D50 common-v2.3.1 candidate adapter."""

from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
import uuid
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping

sys.dont_write_bytecode = True

TOOLS_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS_ROOT))
from v231_adapter_common import (  # noqa: E402
    CAPABILITY_NAMES,
    TABLE_ORDER,
    compact_json,
    empty_tables,
    file_fact,
    identity_set_sha256,
    inventory_sha256,
    make_row,
    mapping_set_sha256,
    package_payload_files,
    projection_id,
    read_json,
    require,
    sha256_bytes,
    sha256_file,
    sort_table_rows,
    write_json,
    write_tables,
    write_csv_surfaces,
)

RECORDED_AT = "2026-09-01T00:00:00Z"
ADAPTER_VERSION = "0.1.0"
LANE_NAMESPACE = uuid.UUID("52e704f6-76c1-5c44-9d36-d4669d42732a")
OWNER_NAMESPACE = "o011-owner-native-v1"
PROFILE_ID = "D50_NATIVE"
COURSE_ROLE = "D50"
COURSE_TITLE = "Smooth Manifolds and Differential Geometry"

PROSE_KEYS = {
    "description", "source_text", "target_text", "text", "body", "content",
    "statement", "wording", "hint", "answer", "solution", "solution_text",
    "prompt", "question", "explanation", "notes", "source_body", "target_body",
}
NATIVE_TYPES = {
    "artifact", "asset", "concept", "correction", "course", "edition", "program",
    "qa_event", "relation", "resource", "rights", "segment", "term", "unit",
}
DIRECT_TARGET = {
    "program": ("datasets", "dataset"),
    "course": ("datasets", "dataset"),
    "resource": ("datasets", "dataset"),
    "edition": ("editions", "edition"),
    "unit": ("units", "unit"),
    "segment": ("content_bindings", "content_binding"),
    "relation": ("relations", "relation"),
    "rights": ("rights", "rights"),
    "artifact": ("artifacts", "artifact"),
    "qa_event": ("qa_events", "qa_event"),
}
HASH_ONLY_TYPES = {"asset", "segment"}


def owner_row_hash(row: Mapping[str, Any]) -> str:
    return sha256_bytes((compact_json(row) + "\n").encode("utf-8"))


def structural_value(value: Any, key: str | None = None) -> Any:
    if key is not None and key.lower() in PROSE_KEYS:
        return None
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for child_key in sorted(value):
            child = structural_value(value[child_key], child_key)
            if child is not None:
                result[child_key] = child
        return result
    if isinstance(value, list):
        return [item for item in (structural_value(item) for item in value) if item is not None]
    return value


def native_metadata(row: Mapping[str, Any]) -> dict[str, Any]:
    value = structural_value(dict(row))
    require(isinstance(value, dict), "native metadata is not an object")
    # The owner identity and discriminator are carried explicitly outside this
    # metadata object; retaining them here would create duplicate authority.
    value.pop("id", None)
    value.pop("entity_type", None)
    return value


def load_contract(candidate_root: Path) -> dict[str, Any]:
    contract = read_json(candidate_root / "D50_BUILDER_INPUT_CONTRACT.json")
    require(contract["state"] == "frozen_candidate_r1", "unexpected D50 contract state")
    require(contract["role"] == COURSE_ROLE, "wrong D50 contract role")
    return contract


def verify_fact(root: Path, fact: Mapping[str, Any]) -> Path:
    rel = str(fact["path"]).replace("/", "/")
    path = root.joinpath(*rel.split("/"))
    require(path.is_file(), f"missing authority input: {rel}")
    require(path.stat().st_size == int(fact["bytes"]), f"authority byte drift: {rel}")
    require(sha256_file(path) == str(fact["sha256"]), f"authority hash drift: {rel}")
    return path


def load_owner_rows(owner_root: Path, contract: Mapping[str, Any]) -> tuple[list[dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    facts = {str(item["path"]): item for item in contract["local_inputs"]}
    records_path = verify_fact(owner_root, facts["backend/records.jsonl"])
    verify_fact(owner_root, facts["backend/MANIFEST.json"])
    verify_fact(owner_root, facts["backend/records.csv"])
    rows: list[dict[str, Any]] = []
    by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
    with records_path.open("r", encoding="utf-8", newline="") as stream:
        for ordinal, line in enumerate(stream, 1):
            require(line.endswith("\n"), f"owner JSONL lacks LF newline at {ordinal}")
            row = json.loads(line)
            require(isinstance(row, dict), f"owner row {ordinal} is not an object")
            require(compact_json(row) == line.rstrip("\r\n"), f"owner JSONL is not canonical at {ordinal}")
            entity_type = str(row.get("entity_type", ""))
            require(entity_type in NATIVE_TYPES, f"unknown owner entity type: {entity_type}")
            require(str(row.get("id", "")).startswith("o011-"), f"unexpected owner ID at {ordinal}")
            item = {"row": row, "ordinal": ordinal, "row_sha256": owner_row_hash(row)}
            rows.append(item)
            by_type[entity_type].append(item)
    require(len(rows) == int(contract["native_profile"]["record_count"]), "native row count drift")
    expected = contract["native_profile"]["entity_counts"]
    require({key: len(by_type.get(key, [])) for key in expected} == {key: int(value) for key, value in expected.items()}, "native entity census drift")
    require(len({str(item["row"]["id"]) for item in rows}) == len(rows), "duplicate native IDs")
    return rows, by_type


def owner_fact(owner_root: Path, rel: str, role: str, contract: Mapping[str, Any]) -> dict[str, Any]:
    facts = {str(item["path"]): item for item in contract["local_inputs"]}
    fact = facts.get(rel)
    require(fact is not None, f"missing contract fact for {rel}")
    path = verify_fact(owner_root, fact)
    return file_fact(path, rel, role, path_base="owner_package_root")


def add_row(
    tables: dict[str, list[dict[str, Any]]],
    table: str,
    record_type: str,
    semantic_key: str,
    payload: Mapping[str, Any],
    *,
    dataset_id: str,
    owner_id: str,
    owner_state: str | None = None,
    normalized_state: str = "validated",
) -> dict[str, Any]:
    row = make_row(
        LANE_NAMESPACE,
        record_type,
        semantic_key,
        payload,
        dataset_id=dataset_id,
        owner_authority_id=owner_id,
        recorded_at=RECORDED_AT,
        normalized_state=normalized_state,
        owner_native_state=owner_state,
    )
    tables[table].append(row)
    return row


def native_binding_payload(
    item: Mapping[str, Any], mapping_class: str, common_target_id: str | None,
    target_hash: str | None,
) -> dict[str, Any]:
    row = item["row"]
    entity_type = str(row["entity_type"])
    rights = []
    if row.get("rights_component_id"):
        rights.append(str(row["rights_component_id"]))
    rights.extend(str(value) for value in (row.get("rights_component_ids") or []))
    evidence = None
    if target_hash is not None and common_target_id is not None:
        evidence = {
            "member_path": "backend/records.jsonl",
            "row_ordinal": int(item["ordinal"]),
            "native_row_sha256": item["row_sha256"],
            "target_record_id": common_target_id,
            "target_record_sha256": target_hash,
        }
    return {
        "native_profile": PROFILE_ID,
        "native_table": entity_type,
        "native_collection": entity_type,
        "native_id": str(row["id"]),
        "owner_record_sha256": item["row_sha256"],
        "archive_id": "d50_owner_records_jsonl",
        "member_path": "backend/records.jsonl",
        "native_member_path": "backend/records.jsonl",
        "row_ordinal": int(item["ordinal"]),
        "native_row_ordinal": int(item["ordinal"]),
        "native_row_sha256": item["row_sha256"],
        "native_rights_id": rights[0] if len(rights) == 1 else None,
        "native_rights_ids": rights,
        "mapping_class": mapping_class,
        "common_target_id": common_target_id,
        "mapping_evidence": evidence,
        "lineage_ids": [str(row.get("parent_id"))] if row.get("parent_id") else [],
        "unknowns": [],
        "native_metadata": native_metadata(row),
        "full_prose_copied": False,
    }


def build_tables(
    rows: list[dict[str, Any]], by_type: Mapping[str, list[dict[str, Any]]],
    owner_root: Path, contract: Mapping[str, Any], candidate_root: Path,
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, Any], dict[str, dict[str, Any]]]:
    tables = empty_tables()
    dataset_id = projection_id(LANE_NAMESPACE, "dataset", "D50:owner-r1")
    owner_id = projection_id(LANE_NAMESPACE, "owner_authority", "D50:owner-native-o011")
    package_id = projection_id(LANE_NAMESPACE, "package", "D50:smooth-manifolds-v231:0.1.0")
    extension_id = projection_id(LANE_NAMESPACE, "lane_adapter_extension", "D50:smooth-manifolds:0.1.0")
    target_by_native: dict[str, dict[str, Any]] = {}
    binding_by_native: dict[str, dict[str, Any]] = {}

    # The owner authority row deliberately contains only relative paths and
    # public identifiers; no local absolute path is placed in the package.
    authority_payload = {
        "authority_kind": "external_owner_native_backend",
        "course_role": COURSE_ROLE,
        "owner_backend_manifest": {"path": "backend/MANIFEST.json", "bytes": 55195, "sha256": "4bc497f5f26781ac0bb55b0db2ffa206774477a32790ec1890fd425b2861fb53"},
        "owner_records_jsonl": {"path": "backend/records.jsonl", "bytes": 4244774, "sha256": "cf875638bbb7ffb657d5932c1663c063f6832495b2f755830d26121d1a631e26"},
        "owner_records_csv": {"path": "backend/records.csv", "bytes": 1663434, "sha256": "e97f94a5e221f7c5abdfb24a7795761f75a1c999f4da06500bb24e41c3c632db"},
        "owner_native_records": len(rows),
        "repository": "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id",
        "release": "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id/releases/tag/v1.0.1",
        "commit": "86d91eec7b95bc0fd814f649d93b587208f89f5d",
        "zenodo_version_doi": "10.5281/zenodo.22161090",
        "zenodo_concept_doi": "10.5281/zenodo.22059977",
        "owner_native_authoritative": True,
        "owner_tree_mutated": False,
    }
    add_row(tables, "owner_authorities", "owner_authority", "D50:owner-native-o011", authority_payload, dataset_id=dataset_id, owner_id=owner_id, normalized_state="external_authority", owner_state="complete_public")

    # Program/course/resource are grouped into datasets only as typed native
    # structural records; this is not a semantic equivalence claim.
    for item in sorted(by_type.get("program", []) + by_type.get("course", []) + by_type.get("resource", []), key=lambda x: (x["row"]["entity_type"], x["row"]["id"])):
        native = item["row"]
        target = add_row(tables, "datasets", "dataset", f"owner-{native['entity_type']}:{native['id']}", {"course_id": COURSE_ROLE, "native_collection": native["entity_type"], "native_id": native["id"], "native_metadata": native_metadata(native), "structural_grouping_only": True, "semantic_equivalence_across_profiles": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="projected_owner_native")
        target_by_native[str(native["id"])] = target

    for item in by_type.get("edition", []):
        native = item["row"]
        target = add_row(tables, "editions", "edition", f"owner-edition:{native['id']}", {"native_collection": "edition", "native_id": native["id"], "native_record_sha256": item["row_sha256"], "native_metadata": native_metadata(native)}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="projected_owner_native")
        target_by_native[str(native["id"])] = target

    # Units are the learner-semantic target. Preserve exact owner state and
    # never infer a stronger translation status.
    for ordinal, item in enumerate(by_type.get("unit", []), 1):
        native = item["row"]
        target = add_row(tables, "units", "unit", f"owner-unit:{native['id']}", {"profile_id": PROFILE_ID, "course_id": COURSE_ROLE, "native_collection": "unit", "native_id": native["id"], "native_record_sha256": item["row_sha256"], "native_metadata": native_metadata(native), "full_prose_copied": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="projected_zero_copy")
        target_by_native[str(native["id"])] = target
        add_row(tables, "course_unit_memberships", "course_unit_membership", f"D50:{native['id']}", {"course_id": COURSE_ROLE, "curriculum_role_id": COURSE_ROLE, "projected_unit_id": target["id"], "native_unit_id": native["id"], "ordinal": ordinal, "order": native.get("order"), "parent_native_id": native.get("parent_id")}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="materialized_membership")
        title = native.get("title") or native.get("source_display_id") or native["id"]
        add_row(tables, "search_documents", "search_document", f"unit-search:{native['id']}", {"course_id": COURSE_ROLE, "projected_unit_id": target["id"], "native_unit_id": native["id"], "locale": native.get("locale"), "unit_kind": native.get("unit_kind"), "title": title, "search_text": title, "body_text_included": False, "learner_url": "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id/releases/tag/v1.0.1"}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="bounded_title_index")

    for item in by_type.get("segment", []):
        native = item["row"]
        target = add_row(tables, "content_bindings", "content_binding", f"owner-segment:{native['id']}", {"native_collection": "segment", "native_id": native["id"], "native_record_sha256": item["row_sha256"], "source_sha256": native.get("source_sha256"), "target_sha256": native.get("target_sha256"), "projected_unit_id": target_by_native.get(str(native.get("parent_id")), {}).get("id"), "full_text_included": False, "source_target_hash_bound": True}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="hash_bound_zero_copy")
        target_by_native[str(native["id"])] = target

    for item in by_type.get("relation", []):
        native = item["row"]
        target = add_row(tables, "relations", "relation", f"owner-relation:{native['id']}", {"native_collection": "relation", "native_id": native["id"], "relation_type": native.get("relation_type"), "from_native_id": native.get("from_id"), "to_native_id": native.get("to_id"), "from_target_id": target_by_native.get(str(native.get("from_id")), {}).get("id"), "to_target_id": target_by_native.get(str(native.get("to_id")), {}).get("id"), "native_record_sha256": item["row_sha256"], "conceptually_inferred": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="projected_owner_relation")
        target_by_native[str(native["id"])] = target

    for item in by_type.get("rights", []):
        native = item["row"]
        target = add_row(tables, "rights", "rights", f"owner-rights:{native['id']}", {"native_collection": "rights", "native_id": native["id"], "native_record_sha256": item["row_sha256"], "native_metadata": native_metadata(native)}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="projected_component_rights")
        target_by_native[str(native["id"])] = target

    # Native artifacts and assets share the common artifact table but retain a
    # collection discriminator; asset rows are hash-only and never copy bytes.
    for item in sorted(by_type.get("artifact", []) + by_type.get("asset", []), key=lambda x: (x["row"]["entity_type"], x["row"]["id"])):
        native = item["row"]
        cls = "exact_mapping" if native["entity_type"] == "artifact" else "hash_only"
        target = add_row(tables, "artifacts", "artifact", f"owner-{native['entity_type']}:{native['id']}", {"native_collection": native["entity_type"], "native_id": native["id"], "native_record_sha256": item["row_sha256"], "source_sha256": native.get("source_sha256"), "target_sha256": native.get("target_sha256"), "expected_bytes": native.get("bytes") or native.get("expected_bytes"), "artifact_kind": native.get("artifact_kind") or "asset", "binary_copied": False, "mapping_class": cls, "native_metadata": native_metadata(native)}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="referenced_native_artifact")
        target_by_native[str(native["id"])] = target

    for item in by_type.get("qa_event", []):
        native = item["row"]
        target = add_row(tables, "qa_events", "qa_event", f"owner-qa:{native['id']}", {"qa_origin": "owner_native_provenance", "native_collection": "qa_event", "native_id": native["id"], "native_record_sha256": item["row_sha256"], "native_metadata": native_metadata(native), "independent_adapter_validation": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="referenced_native_provenance")
        target_by_native[str(native["id"])] = target

    # Derived adapter/reader rows.
    pdf_url = "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id/releases/download/v1.0.1/geometri-diferensial-manifold-mulus-edisi-lengkap-id.pdf"
    html_url = "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id/releases/download/v1.0.1/geometri-diferensial-manifold-mulus-edisi-lengkap-html-20260829.zip"
    repo_url = "https://github.com/KokunoYumeto/brenner-differentialgeometrie-id"
    zenodo_url = "https://zenodo.org/records/22161090"
    route_specs = [
        ("landing", "preservation_landing", repo_url, 1, False),
        ("pdf", "whole_course_pdf", pdf_url, 2, False),
        ("portable-html", "offline_portable_html_download", html_url, 3, True),
        ("repository", "source_repository", repo_url, 4, True),
        ("zenodo", "zenodo_preservation_record", zenodo_url, 5, True),
    ]
    route_ids: dict[str, str] = {}
    for key, kind, url, priority, machine_secondary in route_specs:
        row = add_row(tables, "routes", "route", f"D50:{key}", {"course_id": COURSE_ROLE, "route_kind": kind, "url": url, "learner_priority": priority, "machine_secondary": machine_secondary, "hosted_html": False if key == "portable-html" else None, "adapter_consumption": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state="published_and_anonymously_verified", normalized_state="verified_public_route")
        route_ids[key] = row["id"]
    add_row(tables, "reader_surfaces", "reader_surface", "D50:pdf-reader", {"course_id": COURSE_ROLE, "format": "linked_pdf", "route_id": route_ids["pdf"], "pages": 712, "bytes": 10524618, "sha256": "e0b416d91dfa8de4d5fbf7d84add34cfb3b57adde4645f60c4bc0a0609f5bd2f", "primary": True, "tagged": False, "pdf_ua_claimed": False, "adapter_consumption": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state="published_and_anonymously_verified", normalized_state="verified_linked_reader")
    add_row(tables, "reader_surfaces", "reader_surface", "D50:portable-html", {"course_id": COURSE_ROLE, "format": "portable_html_zip", "route_id": route_ids["portable-html"], "entries": 44, "bytes": 7753152, "sha256": "65ce76d031baea3e049df09218963c187615f25e324bcfd48216afd5fd8cb5e5", "offline": True, "hosted": False, "primary": False, "adapter_consumption": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state="published_and_anonymously_verified", normalized_state="verified_offline_reader")

    add_row(tables, "build_recipes", "build_recipe", "D50:adapter-build", {"builder": "tools/build_d50_smooth_manifolds_v231.py", "validator": "tools/validate_d50_smooth_manifolds_v231.py", "serialization": "canonical_sorted_json_utf8_lf", "owner_generator_invoked": False, "clean_builds_required": 2}, dataset_id=dataset_id, owner_id=owner_id, normalized_state="frozen_recipe")
    add_row(tables, "adapter_profiles", "adapter_profile", "D50-zero-copy-v2.3.1", {"contract": "2.3.1", "course_id": COURSE_ROLE, "owner_native_authoritative": True, "full_prose_centralized": False, "owner_ids_reminted": False, "aggregate_conformance_claim": False, "machine_data_is_learner_destination": False, "machine_surfaces_secondary": True, "capability_map": {name: ("materialized" if name in {"structure_localization", "publication"} else "referenced_native_shards") for name in CAPABILITY_NAMES}}, dataset_id=dataset_id, owner_id=owner_id)
    add_row(tables, "adapter_runs", "adapter_run", "D50-build-2026-09-01", {"adapter_version": ADAPTER_VERSION, "course_id": COURSE_ROLE, "owner_native_records": len(rows), "owner_native_collections": len(by_type), "owner_tree_mutated": False, "source_fulltext_copied": False, "table_counts_pending": True}, dataset_id=dataset_id, owner_id=owner_id, owner_state="candidate_building")

    # Native bindings and crosswalks are emitted after all direct targets exist.
    for item in rows:
        native = item["row"]
        native_id = str(native["id"])
        entity_type = str(native["entity_type"])
        direct = target_by_native.get(native_id)
        if direct is not None:
            mapping_class = "exact_mapping" if entity_type not in HASH_ONLY_TYPES else "hash_only"
            target_id = direct["id"]
            target_hash = sha256_bytes((compact_json(direct) + "\n").encode("utf-8"))
        else:
            mapping_class = "lineage_only"
            target_id = None
            target_hash = None
        binding = add_row(tables, "native_bindings", "native_binding", f"owner-native:{entity_type}:{native_id}", native_binding_payload(item, mapping_class, target_id, target_hash), dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="referenced_native_identity")
        binding_by_native[native_id] = binding

    # Every native row receives a reversible identity crosswalk. Direct rows
    # point to their typed target; lineage/hash-only rows point to their binding
    # (which is a structural identity, not semantic equivalence).
    for item in rows:
        native = item["row"]
        native_id = str(native["id"])
        entity_type = str(native["entity_type"])
        direct = target_by_native.get(native_id)
        target = direct if direct is not None else binding_by_native[native_id]
        target_type = target["record_type"]
        mapping_class = "exact_mapping" if direct is not None and entity_type not in HASH_ONLY_TYPES else "hash_only" if direct is not None else "lineage_only"
        add_row(tables, "identity_crosswalks", "identity_crosswalk", f"owner:{entity_type}:{native_id}", {"source_namespace": OWNER_NAMESPACE, "source_record_id": native_id, "source_record_type": entity_type, "target_namespace": str(LANE_NAMESPACE), "target_record_id": target["id"], "target_record_type": target_type, "mapping_class": mapping_class, "mapping_state": "mapped", "cardinality": "one_to_one", "reverse_recipe": "resolve exact owner entity_type and ID from backend/records.jsonl, then deterministic D50 UUIDv5 semantic key", "evidence": {"member_path": "backend/records.jsonl", "row_ordinal": item["ordinal"], "native_row_sha256": item["row_sha256"], "target_record_sha256": sha256_bytes((compact_json(target) + "\n").encode("utf-8"))}, "semantic_equivalence_across_profiles": False, "identity_set_sha256": identity_set_sha256([native_id, target["id"]])}, dataset_id=dataset_id, owner_id=owner_id, owner_state="frozen_owner_identity", normalized_state="reversible_mapping")

    # Rights assignment closure over every owner row carrying rights IDs.
    rights_ids = {str(item["row"]["id"]): target_by_native[str(item["row"]["id"])] for item in by_type.get("rights", [])}
    rights_assignment_count = 0
    for item in rows:
        native = item["row"]
        refs: list[tuple[str, int, str]] = []
        if native.get("rights_component_id"):
            refs.append(("rights_component_id", 0, str(native["rights_component_id"])) )
        for idx, value in enumerate(native.get("rights_component_ids") or []):
            refs.append(("rights_component_ids", idx, str(value)))
        for field, ordinal, right_id in refs:
            require(right_id in rights_ids, f"dangling rights assignment: {native['id']} -> {right_id}")
            target = target_by_native.get(str(native["id"])) or binding_by_native[str(native["id"])]
            add_row(tables, "rights_assignments", "rights_assignment", f"{native['entity_type']}:{native['id']}:{field}:{ordinal}:{right_id}", {"native_target_id": native["id"], "native_rights_id": right_id, "source_field": field, "source_ordinal": ordinal, "target_id": target["id"], "rights_id": rights_ids[right_id]["id"], "target_record_type": target["record_type"], "rights_assignment_resolution_is_legal_transfer_evidence": False}, dataset_id=dataset_id, owner_id=owner_id, owner_state=native.get("status"), normalized_state="projected_rights_assignment")
            rights_assignment_count += 1

    # Native QA evidence plus one adapter event.
    table_counts = {name: len(tables[name]) for name in TABLE_ORDER}
    add_row(tables, "qa_events", "qa_event", "D50:adapter-build-qa", {"qa_origin": "adapter_generated", "qa_kind": "adapter_build", "result": "pass_pending_replay", "table_counts": table_counts, "owner_native_records_replayed": len(rows), "full_prose_copied": False}, dataset_id=dataset_id, owner_id=owner_id, normalized_state="candidate_validation_pending")
    table_counts = {name: len(tables[name]) for name in TABLE_ORDER}
    sort_table_rows(tables)
    return tables, {"package_id": package_id, "dataset_id": dataset_id, "extension_id": extension_id, "owner_authority_id": owner_id, "route_ids": route_ids, "table_counts": table_counts, "rights_assignment_count": rights_assignment_count}, target_by_native


def build_namespace_sidecar(tables: Mapping[str, list[dict[str, Any]]], context: Mapping[str, Any], rows: list[dict[str, Any]], target_by_native: Mapping[str, dict[str, Any]]) -> dict[str, Any]:
    mappings: list[dict[str, Any]] = []
    for item in rows:
        native = item["row"]
        native_id = str(native["id"])
        target = target_by_native.get(native_id)
        # Find the binding target when no direct target exists.
        if target is None:
            target = next(row for row in tables["native_bindings"] if row["payload"]["native_id"] == native_id)
        mappings.append({"source_namespace": OWNER_NAMESPACE, "target_namespace": str(LANE_NAMESPACE), "source_record_id": native_id, "target_record_id": target["id"], "source_record_type": str(native["entity_type"]), "target_record_type": target["record_type"], "cardinality": "one_to_one", "mapping_state": "mapped", "reverse_recipe": "resolve exact owner entity_type and ID from backend/records.jsonl and D50 semantic key", "evidence_refs": ["owner_records_jsonl", "owner_backend_manifest"], "identity_set_sha256": identity_set_sha256([native_id, target["id"]])})
    mappings.sort(key=lambda row: (row["source_record_type"], row["source_record_id"]))
    return {"$schema": "schema/namespace-crosswalk-v0.2.schema.json", "schema_id": "interlanguage/global-modular-mathematics-namespace-crosswalk/0.2.0", "schema_version": "0.2.0", "package_id": context["package_id"], "profiles": [{"name": "d50_owner_native_o011", "namespace": OWNER_NAMESPACE, "formula": "literal o011-* IDs from frozen backend/records.jsonl"}, {"name": "d50_common_v231", "namespace": str(LANE_NAMESPACE), "formula": "UUIDv5(lane_namespace, record_type + ':' + semantic_key)"}, {"name": "d50_lineage_binding", "namespace": str(LANE_NAMESPACE), "formula": "native_binding row retains owner identity when no typed target is safe"}], "mappings": mappings, "unmaterialized_candidates": [], "identity_sets": {"owner_native_records_sha256": identity_set_sha256(item["row"]["id"] for item in rows), "mapped_target_records_sha256": identity_set_sha256(row["target_record_id"] for row in mappings), "mapped_pairs_sha256": mapping_set_sha256((row["source_record_id"], row["target_record_id"]) for row in mappings), "mapping_count": len(mappings)}, "recorded_at": RECORDED_AT}


def build_translation_sidecar(tables: Mapping[str, list[dict[str, Any]]], context: Mapping[str, Any], authority_fact: Mapping[str, Any]) -> dict[str, Any]:
    units = [row for row in tables["units"]]
    records = []
    for row in units:
        payload = row["payload"]
        native_state = payload.get("native_metadata", {}).get("translation_state")
        records.append({"native_unit_id": payload["native_id"], "projected_unit_id": row["id"], "profile_id": PROFILE_ID, "course_id": COURSE_ROLE, "locale": "id-ID", "state": native_state, "state_inferred": False, "owner_record_sha256": payload["native_record_sha256"], "state_source": "frozen_owner_backend_unit_row"})
    records.sort(key=lambda row: row["native_unit_id"])
    states = sorted({str(row["state"]) for row in records if row["state"] is not None}) or ["owner_state_not_declared"]
    return {"$schema": "schema/translation-state-index-v0.2.schema.json", "schema_id": "interlanguage/global-modular-mathematics-translation-state-index/0.2.0", "schema_version": "0.2.0", "package_id": context["package_id"], "dataset_id": context["dataset_id"], "authority_bindings": [dict(authority_fact)], "coverage": {"course_id": COURSE_ROLE, "granularity": "owner_native_semantic_unit", "authority_rows": len(records), "indexed_rows": len(records), "inferred_rows": 0}, "states": states, "records": records, "identity_set_sha256": identity_set_sha256(row["projected_unit_id"] for row in records), "no_inference": True, "recorded_at": RECORDED_AT}


def build_scope_sidecar(context: Mapping[str, Any], owner_fact_value: Mapping[str, Any], registry_fact: Mapping[str, Any]) -> dict[str, Any]:
    return {"$schema": "schema/scope-declaration-v0.2.schema.json", "schema_id": "interlanguage/global-modular-mathematics-backend-scope/0.2.0", "schema_version": "0.2.0", "package_id": context["package_id"], "dataset_id": context["dataset_id"], "scope_kind": "lane_adapter", "course_ids": [COURSE_ROLE], "curriculum_role_ids": [COURSE_ROLE], "aggregate_conformance_claim": False, "unbound_curriculum_role_ids": [], "owner_authority_binding": dict(owner_fact_value), "curriculum_authority_binding": dict(registry_fact), "limitations": ["D50 only; other curriculum roles remain outside this adapter.", "Owner-native prose, formulas, exercises, solutions, corrections and term bodies remain external authority.", "The 712-page PDF is learner-primary; portable HTML is an offline download only and no hosted HTML route is claimed.", "Component-media rights remain file-specific and are not flattened.", "The candidate is not centrally admitted or independently published."], "recorded_at": RECORDED_AT}


def capability_entry(name: str, state: str, native_ids: Iterable[str], projected_ids: Iterable[str], shard_refs: list[dict[str, Any]], rule: str, limitation: str | None) -> dict[str, Any]:
    native = list(native_ids)
    projected = list(projected_ids)
    values = projected if projected else native
    return {"name": name, "version": "0.1.0", "state": state, "schema_binding": None, "shard_refs": shard_refs, "native_count": len(native), "projected_count": len(projected), "identity_set_sha256": identity_set_sha256(values) if values else None, "identity_set_scope": "projected_records" if projected else "native_shard_records" if native else "none", "closure_rules": [rule], "loss_gap_report": {"status": "declared_limitation" if limitation else "closed", "reason": limitation or "Closed over the frozen D50 authority."}}


def build_capability_sidecar(context: Mapping[str, Any], rows: list[dict[str, Any]], by_type: Mapping[str, list[dict[str, Any]]], tables: Mapping[str, list[dict[str, Any]]], owner_fact_value: Mapping[str, Any], policy_fact: Mapping[str, Any], rights_fact: Mapping[str, Any]) -> dict[str, Any]:
    owner_ids = [str(item["row"]["id"]) for item in rows]
    shard = [dict(owner_fact_value)]
    caps = [
        capability_entry("structure_localization", "materialized", [str(item["row"]["id"]) for item in by_type["unit"] + by_type["relation"]], [row["id"] for row in tables["units"] + tables["relations"]], [], "All owner units and typed relations are projected without conceptual inference.", None),
        capability_entry("terminology", "referenced_native_shards", [str(item["row"]["id"]) for item in by_type["term"] + by_type["concept"]], [], shard, "Terms and concepts remain in the owner-native backend.", "No dedicated common terminology table is introduced in v2.3.1."),
        capability_entry("mathematical_preservation", "referenced_native_shards", [str(item["row"]["id"]) for item in by_type["segment"] + by_type["unit"]], [], shard, "Math-bearing bodies remain zero-copy owner references with source/target hashes.", "The adapter does not copy or independently restate prose."),
        capability_entry("assessment_support", "referenced_native_shards", [str(item["row"]["id"]) for item in by_type["unit"] if "exercise" in str(item["row"].get("unit_kind", "")) or "solution" in str(item["row"].get("unit_kind", ""))], [row["id"] for row in tables["units"] if "exercise" in str(row["payload"].get("native_metadata", {}).get("unit_kind", "")) or "solution" in str(row["payload"].get("native_metadata", {}).get("unit_kind", ""))], shard, "Assessment topology is represented by stable unit identities.", "Exercise and solution bodies remain owner-native."),
        capability_entry("assets", "referenced_native_shards", [str(item["row"]["id"]) for item in by_type["asset"]], [], shard, "Asset identities and rights references are retained.", "Asset bytes are not copied into the capsule."),
        capability_entry("accessibility", "materialized", ["owner-release-r1"], [row["id"] for row in tables["reader_surfaces"]], [dict(owner_fact_value)], "PDF and offline HTML route facts are materialized with truthful limits.", "No PDF/UA or hosted HTML claim is made."),
        capability_entry("corrections", "referenced_native_shards", [str(item["row"]["id"]) for item in by_type["correction"]], [], shard, "All correction provenance remains bound to owner records.", "No common correction semantics are inferred."),
        capability_entry("computational_interactives", "not_projected", [], [], [], "No computational-interactive capability is claimed for this D50 adapter.", "No such consumer or verified round trip is evidenced."),
        capability_entry("publication", "materialized", [str(item["row"]["id"]) for item in by_type["artifact"]], [row["id"] for row in tables["artifacts"] + tables["reader_surfaces"] + tables["routes"]], [], "Owner release and learner routes are represented with exact hashes.", None),
        capability_entry("research_support", "referenced_native_shards", [str(item["row"]["id"]) for item in by_type["resource"] + by_type["concept"]], [], shard, "Native resources and concepts remain provenance references.", "No semantic research graph is invented."),
    ]
    return {"$schema": "schema/capability-declarations-v0.2.schema.json", "schema_id": "interlanguage/global-modular-mathematics-capability-declarations/0.2.0", "schema_version": "0.2.0", "package_id": context["package_id"], "dataset_id": context["dataset_id"], "contract_binding": dict(policy_fact), "capabilities": caps, "legacy_labels": [], "namespace_crosswalk_binding": {"path": "namespace-crosswalk-v0.2.0.json", "binding_state": "sealed_by_package_manifest"}, "csv_projection_binding": {"path": "csv-projection-manifest-v0.2.0.json", "binding_state": "sealed_by_package_manifest"}, "translation_state_binding": {"path": "translation-state-index-v0.2.0.json", "binding_state": "sealed_by_package_manifest"}, "rights_cross_cutting": {"state": "referenced_native_shards", "shard_refs": [dict(owner_fact_value), dict(rights_fact)], "native_count": len(by_type["rights"]), "identity_set_sha256": identity_set_sha256(str(item["row"]["id"]) for item in by_type["rights"]), "closure_rules": ["Rights identities and per-component assignments remain distinct; assignment resolution is not legal-transfer evidence."]}, "recorded_at": RECORDED_AT}


def build_rights_sidecar(context: Mapping[str, Any], rows: list[dict[str, Any]], tables: Mapping[str, list[dict[str, Any]]], rights_count: int, owner_fact_value: Mapping[str, Any]) -> dict[str, Any]:
    return {"schema_id": "interlanguage/d50-owner-rights-assignment-closure/0.1.0", "schema_version": "0.1.0", "package_id": context["package_id"], "dataset_id": context["dataset_id"], "owner_backend_binding": dict(owner_fact_value), "native_rows_with_rights": sum(1 for item in rows if item["row"].get("rights_component_id") or item["row"].get("rights_component_ids")), "assignment_count": rights_count, "materialized_assignments": len(tables["rights_assignments"]), "dangling_assignments": 0, "missing_rights_identities": 0, "profile_rights_remain_distinct": True, "format_specific_notices_remain_distinct": True, "rights_assignment_resolution_is_legal_transfer_evidence": False, "recorded_at": RECORDED_AT}


def copy_payload_sources(output: Path, candidate_root: Path) -> None:
    # Copy only candidate-local controls and exact common tool/schema bytes.
    # The clean output root is newly created by ``build``; establish these
    # package directories before copying source witnesses into them.
    (output / "tools").mkdir(parents=True, exist_ok=True)
    (output / "schema").mkdir(parents=True, exist_ok=True)
    for rel in ["D50_BUILDER_INPUT_CONTRACT.json", "D50_IMPLEMENTATION_INTERFACE.json"]:
        shutil.copyfile(candidate_root / rel, output / rel)
    for rel in [
        "research/D50_AUTHORITY_CAPSULE.json", "research/D50_NATIVE_PROFILE_DESIGN.json",
        "research/D50_LEARNER_ROUTE_EVIDENCE.json", "research/D50_RIGHTS_IDENTITY_AUDIT.json",
        "research/D50_OWNER_PUBLICATION_BOUNDARY_AUDIT_20260901.json",
    ]:
        target = output / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(candidate_root / rel, target)
    for rel in ["v231_adapter_common.py", "validate_lane_adapter_v231.py", "package_lane_adapter_v231.py"]:
        shutil.copyfile(candidate_root / "tools" / rel, output / "tools" / rel)
    for rel in [
        "lane-adapter-v2.3.1.schema.json", "adapter-seal-v1.schema.json",
        "capability-declarations-v0.2.schema.json", "namespace-crosswalk-v0.2.schema.json",
        "translation-state-index-v0.2.schema.json", "csv-projection-manifest-v0.2.schema.json",
        "scope-declaration-v0.2.schema.json",
    ]:
        shutil.copyfile(candidate_root / "schema" / rel, output / "schema" / rel)


def build(args: argparse.Namespace) -> dict[str, Any]:
    candidate_root = Path(__file__).resolve().parents[1]
    owner_root = args.owner_root.resolve()
    repository_root = args.repository_root.resolve()
    output = args.output.resolve()
    require(candidate_root.is_dir() and owner_root.is_dir() and repository_root.is_dir(), "build roots missing")
    require(output != owner_root and output != repository_root, "refusing to build over authority root")
    if output.exists():
        require(args.replace, "output exists; pass --replace")
        shutil.rmtree(output)
    output.mkdir(parents=True)
    contract = load_contract(candidate_root)
    rows, by_type = load_owner_rows(owner_root, contract)
    # Verify all contract local inputs now, including the public/readback and
    # rights witnesses. Missing or changed bytes fail closed.
    for fact in contract["local_inputs"]:
        verify_fact(owner_root, fact)
    program_facts = {str(item["path"]): item for item in contract["program_inputs"]}
    policy_path = verify_fact(repository_root, program_facts[next(key for key in program_facts if "backend-design-policy" in key)])
    registry_path = verify_fact(repository_root, program_facts[next(key for key in program_facts if "198_FULL" in key)])
    owner_manifest_fact = owner_fact(owner_root, "backend/MANIFEST.json", "owner_backend_manifest", contract)
    rights_fact = owner_fact(owner_root, "authority/brenner_media_rights_manifest.csv", "component_media_rights", contract)
    policy_fact = file_fact(policy_path, next(key for key in program_facts if "backend-design-policy" in key), "common_backend_design_policy", path_base="program_repository_root")
    registry_fact = file_fact(registry_path, next(key for key in program_facts if "198_FULL" in key), "curriculum_registry_authority", path_base="program_repository_root")
    tables, context, target_by_native = build_tables(rows, by_type, owner_root, contract, candidate_root)
    copy_payload_sources(output, candidate_root)
    # Custom builder/validator/probe files are copied after their source files
    # exist; this file is copied from the candidate itself.
    for name in ["build_d50_smooth_manifolds_v231.py", "validate_d50_smooth_manifolds_v231.py", "run_d50_negative_probes.py"]:
        source = candidate_root / "tools" / name
        if source.is_file():
            shutil.copyfile(source, output / "tools" / name)
    write_tables(output, tables)
    write_json(output / "scope-declaration-v0.2.0.json", build_scope_sidecar(context, owner_manifest_fact, registry_fact))
    write_json(output / "namespace-crosswalk-v0.2.0.json", build_namespace_sidecar(tables, context, rows, target_by_native))
    write_json(output / "translation-state-index-v0.2.0.json", build_translation_sidecar(tables, context, owner_manifest_fact))
    write_json(output / "rights-assignment-closure-v0.1.0.json", build_rights_sidecar(context, rows, tables, int(context["rights_assignment_count"]), owner_manifest_fact))
    write_json(output / "capability-declarations-v0.2.0.json", build_capability_sidecar(context, rows, by_type, tables, owner_manifest_fact, policy_fact, rights_fact))
    csv_manifest = write_csv_surfaces(output, tables, context["package_id"], RECORDED_AT)
    write_json(output / "csv-projection-manifest-v0.2.0.json", csv_manifest)
    # D50 custom evidence sidecars.
    write_json(output / "D50_INPUT_AUTHORITIES.json", {"schema_id": "interlanguage/d50-input-authorities/1.0.0", "role": COURSE_ROLE, "authorities": contract["local_inputs"], "program_inputs": contract["program_inputs"], "receipt_bound_archives": contract["receipt_bound_archives"], "owner_native_records": len(rows), "owner_native_non_mutation": True, "recorded_at": RECORDED_AT})
    write_json(output / "D50_NATIVE_PROFILE_SUMMARY.json", {"schema_id": "interlanguage/d50-native-profile-summary/1.0.0", "role": COURSE_ROLE, "native_schema": "o011-modular-backend", "record_count": len(rows), "entity_counts": {key: len(value) for key, value in sorted(by_type.items())}, "direct_target_classes": sorted(set(DIRECT_TARGET) - HASH_ONLY_TYPES), "lineage_only_classes": ["concept", "term", "correction"], "hash_only_classes": sorted(HASH_ONLY_TYPES), "native_binding_rows": len(tables["native_bindings"]), "rights_assignment_count": context["rights_assignment_count"], "translation_state_ceiling": "mathematically_reviewed", "full_prose_copied": False, "recorded_at": RECORDED_AT})
    target_facts = []
    for table in TABLE_ORDER:
        for row in tables[table]:
            target_facts.append({"table": table, "record_type": row["record_type"], "id": row["id"], "semantic_key": row["semantic_key"], "sha256": sha256_bytes((compact_json(row) + "\n").encode("utf-8"))})
    write_json(output / "D50_TARGET_IDENTITY_INVENTORY.json", {"schema_id": "interlanguage/d50-target-identity-inventory/1.0.0", "role": COURSE_ROLE, "freeze_before_crosswalk": True, "target_count": len(target_facts), "target_identity_set_sha256": identity_set_sha256(item["id"] for item in target_facts), "targets": target_facts, "recorded_at": RECORDED_AT})
    loss_rows = []
    for key, count in sorted({k: len(v) for k, v in by_type.items()}.items()):
        cls = "direct_target" if key in DIRECT_TARGET and key not in HASH_ONLY_TYPES else "hash_only" if key in HASH_ONLY_TYPES else "lineage_only"
        common_target_records = sum(
            1 for item in by_type[key]
            if str(item["row"]["id"]) in target_by_native
        )
        loss_rows.append({
            "native_collection": key,
            "native_records": count,
            "mapping_class": cls,
            "native_binding_records": count,
            "common_target_records": common_target_records,
            "loss_reason": (
                "typed structural target; cross-profile semantics remain hash-bound"
                if key in HASH_ONLY_TYPES
                else "typed common target"
                if key in DIRECT_TARGET
                else "preserved in native_binding; no safe dedicated common target"
            ),
        })
    write_json(output / "D50_LOSS_ACCOUNTING.json", {"schema_id": "interlanguage/d50-loss-accounting/1.0.0", "role": COURSE_ROLE, "native_record_total": len(rows), "classified_once": True, "rows": loss_rows, "unmapped_native_rows_are_not_dropped": True, "full_prose_copied": False, "recorded_at": RECORDED_AT})
    # Package README is short, learner-neutral metadata and contains no local paths.
    (output / "README.md").write_text("# D50 common-v2.3.1 candidate adapter\n\nZero-copy structural index for the Indonesian Smooth Manifolds and Differential Geometry edition. The owner-native backend remains authoritative; learner prose is not copied here. This candidate is not centrally admitted or independently published.\n", encoding="utf-8", newline="\n")
    # Recompute table counts after all derived rows and write a final adapter QA row is not allowed to mutate ordering; it was already added.
    payload_facts = package_payload_files(output)
    payload_identity = inventory_sha256(payload_facts)
    sidecar_names = ["capability-declarations-v0.2.0.json", "namespace-crosswalk-v0.2.0.json", "translation-state-index-v0.2.0.json", "rights-assignment-closure-v0.1.0.json", "csv-projection-manifest-v0.2.0.json", "scope-declaration-v0.2.0.json"]
    manifest = {"$schema": "schema/lane-adapter-v2.3.1.schema.json", "schema_id": "interlanguage/global-modular-mathematics-lane-adapter/2.3.1", "schema_version": "2.3.1", "package_id": context["package_id"], "dataset_id": context["dataset_id"], "extension_id": context["extension_id"], "extension_version": ADAPTER_VERSION, "recorded_at": RECORDED_AT, "scope_declaration": file_fact(output / "scope-declaration-v0.2.0.json", "scope-declaration-v0.2.0.json", "scope_declaration"), "authorities": [owner_manifest_fact, owner_fact(owner_root, "backend/records.jsonl", "owner_backend_records_jsonl", contract), owner_fact(owner_root, "backend/records.csv", "owner_backend_records_csv", contract), owner_fact(owner_root, "output/pdf/geometri-diferensial-manifold-mulus-edisi-lengkap-id.pdf", "learner_primary_pdf", contract), owner_fact(owner_root, "output/html/complete/index.html", "portable_html_entry", contract), owner_fact(owner_root, "output/html/complete/manifest.json", "portable_html_manifest", contract), rights_fact, policy_fact, registry_fact], "sidecars": [file_fact(output / name, name, "sidecar") for name in sidecar_names] + [file_fact(output / name, name, "d50_sidecar") for name in ["D50_INPUT_AUTHORITIES.json", "D50_NATIVE_PROFILE_SUMMARY.json", "D50_TARGET_IDENTITY_INVENTORY.json", "D50_LOSS_ACCOUNTING.json"]], "csv_projection": {"manifest": file_fact(output / "csv-projection-manifest-v0.2.0.json", "csv-projection-manifest-v0.2.0.json", "csv_projection_manifest"), "table_csv_count": len(TABLE_ORDER), "aggregate_csv_count": 1, "record_count": sum(len(tables[name]) for name in TABLE_ORDER), "roundtrip_state": "pass"}, "build": {"builder": file_fact(output / "tools/build_d50_smooth_manifolds_v231.py", "tools/build_d50_smooth_manifolds_v231.py", "builder"), "validator": file_fact(output / "tools/validate_d50_smooth_manifolds_v231.py", "tools/validate_d50_smooth_manifolds_v231.py", "validator"), "canonical_serialization": {"scope": "builder_generated_json_jsonl_and_csv_only", "encoding": "UTF-8", "newline": "LF", "json_keys": "lexicographically_sorted", "trailing_newline": True, "copied_schema_and_tool_files": "preserved_exact_source_bytes"}, "deterministic_replay": "byte_identical", "build_a_sha256": payload_identity, "build_b_sha256": payload_identity}, "files": payload_facts, "seal_policy": {"algorithm": "sha256-sorted-path-bytes-v1", "seal_file": "seal.json", "seal_excluded_from_own_digest": True, "binds": ["schemas", "tools", "input_authorities", "evidence", "tables", "sidecars", "csv_projections", "manifest"]}, "zero_copy_policy": {"owner_native_authoritative": True, "full_prose_centralized": False, "owner_ids_reminted": False, "aggregate_conformance_claim": False, "machine_data_is_learner_destination": False, "machine_surfaces_secondary": True}}
    write_json(output / "manifest.json", manifest)
    manifest_fact = file_fact(output / "manifest.json", "manifest.json", "package_manifest")
    # The seal inventory is canonical by POSIX path, just like the checksum
    # projection.  Keep the manifest fact in that ordering as well; otherwise
    # a byte-identical build can still fail the envelope validator.
    seal_facts = sorted(payload_facts + [manifest_fact], key=lambda item: str(item["path"]))
    write_json(output / "seal.json", {"$schema": "schema/adapter-seal-v1.schema.json", "schema_id": "interlanguage/global-modular-mathematics-lane-adapter-seal/1.0.0", "package_id": context["package_id"], "algorithm": "sha256-sorted-path-bytes-v1", "files": seal_facts, "file_count": len(seal_facts), "bytes": sum(int(item["bytes"]) for item in seal_facts), "aggregate_sha256": inventory_sha256(seal_facts), "seal_excluded_from_own_digest": True, "recorded_at": RECORDED_AT})
    # Re-enumerate after writing the seal so the checksum closure covers the
    # physical seal itself (while still excluding the checksum file).  The
    # manifest remains explicitly included because it is excluded by the
    # payload helper.
    checksum_facts = sorted(package_payload_files(output) + [manifest_fact], key=lambda item: str(item["path"]))
    (output / "PACKAGE_CHECKSUMS.sha256").write_text("".join(f"{item['sha256']}  {item['path']}\n" for item in checksum_facts), encoding="utf-8", newline="\n")
    return {"status": "pass", "output": str(output), "package_id": context["package_id"], "dataset_id": context["dataset_id"], "canonical_records": sum(len(tables[name]) for name in TABLE_ORDER), "table_counts": {name: len(tables[name]) for name in TABLE_ORDER}, "payload_files": len(payload_facts), "payload_inventory_sha256": payload_identity, "owner_native_records": len(rows), "owner_tree_mutated": False, "full_prose_copied": False}


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--owner-root", type=Path, required=True)
    parser.add_argument("--repository-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replace", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    try:
        result = build(parse_args(argv))
    except Exception as exc:  # fail closed; no partial success claim
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(compact_json(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
