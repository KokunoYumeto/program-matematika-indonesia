import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve, dirname } from 'node:path';
import { render } from './build.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const registry = JSON.parse(await readFile(resolve(root, 'registry.json'), 'utf8'));
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const template = await readFile(resolve(root, 'index.template.html'), 'utf8');
assert.equal(html, render(registry, template), 'Generated HTML is stale; run scripts/build.mjs');
const escapeAttribute = value => value.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll("'", '&#39;');
assert.equal(registry.schema_version, 1);
const identifiers = new Set();
const addId = id => {
  assert.match(id, /^[a-z0-9]+(?:-[a-z0-9]+)*$/);
  assert(!identifiers.has(id), `Duplicate registry ID: ${id}`);
  identifiers.add(id);
};
const checkUrl = url => {
  const parsed = new URL(url);
  assert.equal(parsed.protocol, 'https:', `Public route must use HTTPS: ${url}`);
  assert(!parsed.username && !parsed.password, 'Public routes must not contain credentials');
  assert(!/localhost|127\.0\.0\.1/.test(parsed.hostname), 'Public routes must not point to localhost');
  assert(!url.startsWith('https://kokunoyumeto.github.io/unofficial-stacks-project-ai-drafts'), 'Unverified draft HTML route is forbidden');
};
const collectionIds = new Set(registry.collections.map(c => c.id));
registry.collections.forEach(c => addId(c.id));
let routes = 0;
for (const item of registry.items) {
  addId(item.id);
  assert(collectionIds.has(item.collection), `Unknown collection: ${item.collection}`);
  assert(['published','source-available','download','development','awaiting-route'].includes(item.status));
  assert(item.title && item.provenance_label && item.note);
  assert(html.includes(`id="${item.id}"`), `Missing static item: ${item.id}`);
  const publicEditions = item.editions.filter(e => e.url);
  if (['published', 'download'].includes(item.status)) assert(publicEditions.length, `Published entry needs a route: ${item.id}`);
  if (item.status === 'source-available') assert(publicEditions.length || item.source_url, `Source entry needs a repository route: ${item.id}`);
  if (['development', 'awaiting-route'].includes(item.status)) assert.equal(publicEditions.length, 0, `Pending entry has an unexplained public route: ${item.id}`);
  for (const edition of item.editions) {
    addId(edition.id);
    assert(['en','id','fr','zh-Hans','ja','ko'].includes(edition.language), `Unregistered language: ${edition.language}`);
    assert.equal(edition.language, edition.content_language ?? edition.interface_language, `Filter language must match the declared content or interface language: ${edition.id}`);
    assert(Boolean(edition.content_language) !== Boolean(edition.interface_language), `Declare exactly one language scope: ${edition.id}`);
    assert(edition.language_label && edition.format);
    if (edition.url) {
      checkUrl(edition.url);
      assert(edition.link_label);
      assert(html.includes(`href="${escapeAttribute(edition.url)}"`), `Missing no-JS edition link: ${edition.id}`);
      routes++;
    } else assert.equal(edition.link_label, null);
  }
  if (item.source_url) checkUrl(item.source_url);
}
const htmlIds = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
assert.equal(new Set(htmlIds).size, htmlIds.length, 'Duplicate HTML IDs');
for (const [, anchor] of html.matchAll(/href="#([^"]+)"/g)) assert(htmlIds.includes(anchor), `Broken local anchor: #${anchor}`);
assert(!html.includes('<!-- CATALOGUE -->'), 'Build placeholders remain');
assert(!/href="(?:#|javascript:|file:|\/)/.test(html.replaceAll(/href="#[^"]+"/g, '')), 'Empty, unsafe or root-absolute link');
assert(html.includes('href="./styles.css"') && html.includes('src="./library.js"'), 'Assets must work under a GitHub Pages subdirectory');
assert(!html.includes('C:\\'), 'Local machine path in public HTML');
assert(!html.includes('href="./"'), 'Library home must open the index file rather than a local directory');
assert.equal([...html.matchAll(/href="\.\/index\.html"/g)].length, 3, 'All three Library home links must work locally and under a hosted subdirectory');
for (const placement of ['top', 'bottom']) {
  const landmark = html.match(new RegExp(`<nav[^>]+data-library-navigation="${placement}"[^>]*>([\\s\\S]*?)<\\/nav>`, 'g')) || [];
  assert.equal(landmark.length, 1, `Need exactly one ${placement} program navigation landmark`);
  assert(landmark[0].includes('aria-label='));
  for (const locale of ['en', 'id']) assert(landmark[0].includes(`https://kokunoyumeto.github.io/program-matematika-indonesia/${locale}/`));
}
console.log(`PASS: ${registry.items.length} entries; ${registry.collections.length} collections; ${routes} public edition routes; unique registry/HTML IDs; anchors; progressive-enhancement links; portable asset paths.`);
