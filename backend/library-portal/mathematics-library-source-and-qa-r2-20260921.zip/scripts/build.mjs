import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve, dirname } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const editionName = e => [e.language_label, e.register_label, e.variant_label].filter(Boolean).join(' · ');

function card(item) {
  const available = item.editions.filter(e => e.url);
  const picker = available.length > 1;
  const languages = [...new Set(item.editions.map(e => e.language))].join(' ') || 'unspecified';
  const editionLabel = item.editions.length ? item.editions.map(e => `${esc(editionName(e))} <span>· ${esc(e.format)}</span>`).join('<br>') : (item.source_url ? 'Languages and edition details are listed by work in the collection' : 'Edition languages to be confirmed');
  return `
          <article class="library-card${picker ? ' has-edition-picker' : ''}" id="${esc(item.id)}" data-collection="${esc(item.collection)}" data-languages="${esc(languages)}" data-status="${esc(item.status)}" aria-labelledby="${esc(item.id)}-title">
            <div class="card-topline"><span class="work-code">${esc(item.code)}</span><span class="status status-${esc(item.status)}">${esc(item.status_label)}</span></div>
            <h4 id="${esc(item.id)}-title">${esc(item.title)}</h4>
            <p class="card-summary">${esc(item.summary)}</p>
            <p class="provenance">${esc(item.provenance_label)}</p>
            <div class="edition-area">
              <p class="edition-label${picker ? ' static-edition-label' : ''}">${editionLabel}</p>
              ${picker ? `<div class="edition-select-block"><label for="${esc(item.id)}-edition">${available.every(e => e.interface_language) ? 'Program interface language' : 'Choose this work’s edition'}</label><select class="edition-select" id="${esc(item.id)}-edition">${available.map(e => `<option value="${esc(e.id)}">${esc(editionName(e))}</option>`).join('')}</select></div>` : ''}
              ${available.length ? `<div class="edition-links">${available.map(e => `<a class="edition-link" href="${esc(e.url)}" data-edition="${esc(e.id)}" data-language="${esc(e.language)}"><span>${esc(e.link_label)}</span><span aria-hidden="true">↗</span></a>`).join('')}</div>` : ''}
              <p class="card-note">${esc(item.note)}</p>
            </div>
            ${item.source_url ? `<a class="source-link" href="${esc(item.source_url)}">${esc(item.source_link_label || 'Source repository')} ↗</a>` : ''}
            <a class="card-permalink" href="#${esc(item.id)}" aria-label="Link to ${esc(item.title)}">#</a>
          </article>`;
}

export function render(registry, template) {
const catalogue = registry.collections.map(collection => {
  const items = registry.items.filter(item => item.collection === collection.id);
  return `
        <section class="catalogue-section" id="${esc(collection.id)}" data-collection="${esc(collection.id)}" aria-labelledby="${esc(collection.id)}-title">
          <div class="section-heading"><span class="section-number" aria-hidden="true">${esc(collection.number)}</span><div><div class="section-title-row"><h3 id="${esc(collection.id)}-title">${esc(collection.title)}</h3><span class="section-count">${items.length} ${items.length === 1 ? 'entry' : 'entries'}</span></div><p>${esc(collection.description)}</p></div></div>
          <div class="card-grid">${items.map(card).join('')}
          </div>
        </section>`;
}).join('');
const options = registry.collections.map(c => `<option value="${esc(c.id)}">${esc(c.title)}</option>`).join('');
return template.replace('<!-- COLLECTION_OPTIONS -->', options).replace('<!-- CATALOGUE -->', catalogue);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const registry = JSON.parse(await readFile(resolve(root, 'registry.json'), 'utf8'));
  const template = await readFile(resolve(root, 'index.template.html'), 'utf8');
  await writeFile(resolve(root, 'index.html'), render(registry, template), 'utf8');
  console.log(`Built index.html: ${registry.items.length} catalogue entries, ${registry.collections.length} collections.`);
}
