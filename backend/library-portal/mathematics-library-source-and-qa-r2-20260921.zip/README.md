# Mathematics Library front door

A portable static library directory for the existing English and Indonesian mathematics programs, advanced research-course drafts, future collected works, EGA/FGA/SGA editions, and a separately labeled unofficial AI draft source collection.

## Hosting boundary

The intended deployment is an **additive subdirectory** of the existing GitHub Pages program site, such as `/program-matematika-indonesia/library/`. There is no confirmed account-root website. The site uses relative asset and home links so it works under any static subdirectory without a configured domain, build service, framework, external fonts or network requests for rendering.

This folder is a local, unpublished handoff. Do not replace the program landing page, `/en/`, `/id/`, D80, D100, or their existing navigation and publication tools. The central program owner controls those routes. The receiving owner should review the package and copy only `index.html`, `styles.css`, `library.js` and `registry.json` into an agreed new directory, then add the agreed link into the existing site. Deploy through the existing repository workflow. No publication has been performed by this package.

`./index.html` is the library-home route, supporting both a direct local-file view and static hosting. Item links use stable local fragment IDs. Published editions keep their verified existing absolute URLs; the library never hosts a duplicate copy of the books. Existing readers can link back to the agreed library URL once that deployment is confirmed. Do not introduce a fictional root-site URL or link to an unverified Pages route for the draft repository.

## Content and edition ownership

`registry.json` is the public registry for this front door. `index.html` is generated from that registry and `index.template.html`; the generated page includes every entry and published edition link so the site remains usable without JavaScript. `library.js` adds search, collection/language/status filters, and a native work-specific edition selector. There is no universal language switch: an edition is offered only for the work to which it belongs. Program choices explicitly select the **interface** language, never the content language of every linked work. `content_language` and `interface_language` record this distinction; the generic `language` field is used only by the catalogue filter.

The top and bottom program navigation landmarks are marked `data-library-navigation="top"` and `data-library-navigation="bottom"`. Both carry visible absolute HTTPS routes to the central `/en/` and `/id/` program interfaces, including when the library is opened from a local file. These are library-level breadcrumbs, not invented course-anchor bindings. Existing edition routes and known source links remain attached to their own works.

This registry describes navigation and public availability. It does **not** supersede the central program's course or capability manifests, constitute a new source canon, or claim course completeness. When an owner supplies a verified new edition, record its stable work ID, edition ID, source identity, language, register where applicable, editorial provenance and exact reading URL. Do not relabel a translation as the original work. Preserve explicit human author/editor/translator credits only when supplied by their owners; never infer an attribution from filesystem or account names. Clearly label AI-generated, unofficial and draft material.

Initial public routes were supplied as confirmed on 2026-09-19. The library record was assembled on 2026-09-21. The two 40-course language maps and the D80 and D100 readers are linked. The D100 entry is **Algebraic Geometry Bridge**, an existing three-book English reader. Published routes are not claims of mathematical completeness.

The four advanced course entries (AN-03, SH-02, OA-MOD, OA-FLOW) identify a frozen R5B snapshot with 155 English draft reading units **in total**: 29, 55, 40 and 31 respectively. The last count includes two separately authored operator-algebra bridges. This is a count of draft lessons, not a percentage of mathematical scope covered. These unofficial AI-written drafts remain in development, contain open proof obligations, and have no confirmed public reader route. The sealed R5B reader ZIP has SHA-256 `DECBF7C9062B1180D98CF4DA7D285DBB0234585DE29F79172B3AE8C77D69553C`; its metadata must not be mistaken for a live reading URL. SGA still awaits owner-confirmed public edition routes and languages; this does not imply that local work is absent. Do not add speculative or disabled placeholder links.

The coordinating owner confirmed six source repositories on 2026-09-21: EGA French source / English discovery edition, FGA French source, and separate Stacks Project AI translation drafts in Simplified Chinese, Japanese and Korean. These are explicitly source-repository routes, not verified full HTML readers or claims of complete editions. The Stacks translations are not a claim that the unofficial AI extension collection is translated. Native coverage, review, provenance and rights records remain authoritative. `route_verified_date` records the later evidence on each of these route records.

The collected-works entry links the working **Modern LaTeX Editions of Mathematics Manuscripts** repository, whose README was checked on 2026-09-21. It provides a collection entry point and per-work edition/coverage/provenance records; the library does not invent collection-wide language, authorship or completion claims.

The R48 release is a separate unofficial AI-generated collection. Its 36 chapters / 3,444 pages describe that release, not course coverage. Its release page provides PDF/source access. A direct `.tex` companion is not a monolithic build target; the source ZIP includes dependencies. No draft-repository GitHub Pages URL is assumed.

## Build and validate

Requires only Node.js; no installation or package dependencies are needed.

```text
node scripts/build.mjs
node scripts/validate.mjs
```

Open `index.html` directly or serve this directory through a static HTTP server. The JavaScript does not fetch the registry at runtime, so direct-file viewing works. Rebuild after registry or template changes and include the generated `index.html` in the handoff. Validation checks stable IDs, collection references, public URL schemes, known forbidden unverified routes, static edition links, local anchors, and portable asset paths. It does not prove that remote servers are live or that their content is complete.

## Accessibility and visual checks

The page uses semantic headings, native selects, associated labels, visible keyboard focus, a skip link, text status labels, an announced result count, and a reduced-motion preference. All published language routes are visible when JavaScript is disabled. No custom widgets or external assets are required.

Before deployment, check the agreed subdirectory in a browser at desktop and mobile widths, exercise filters and the work-specific language selector, verify the no-JavaScript page, and confirm the remote edition routes with their owners. Local automated browser QA, when available, is recorded separately from publication verification.

Local headless Edge QA uses `scripts/browser-qa.mjs` with Playwright from the bundled runtime. It checks the `/library/` subdirectory, 13 visible entries, top/bottom program navigation, interface and translation selectors, language/collection/status filters, accent-insensitive search, empty-state recovery, navigation after filtering, keyboard skip-link focus, no-JavaScript links, and absence of horizontal overflow at 1366, 390 and 320 pixels. R2 also checks that the Library home link reopens the actual index in both hosted and direct-file views. The current receipt is `qa/r2/browser-qa.json`; four desktop/mobile viewport screenshots are in `qa/r2/`. The previous `qa/` results and first sealed deployment ZIP are retained. QA artifacts, templates, scripts and this README are development material, outside the four-file deployment allowlist above.
