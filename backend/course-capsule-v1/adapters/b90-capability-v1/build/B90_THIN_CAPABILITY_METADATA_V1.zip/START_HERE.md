# B90 thin capability packet

This packet contains only B90 adapter metadata, identity indexes, generated learner and educator views, validation evidence, negative fixtures, and standard-library Python scripts. It does not contain the native backend dataset, textbook bodies, TeX source, PDF, answer supplement, or other course payloads.

Deterministic replay requires a separate checkout of https://github.com/KokunoYumeto/introduction-to-probability-id at commit `5d1cfc55eecb678b0b4074160bc4f2d8bb2da5b6` (tree `21df3b2c0fab6827a21854bdcc41667a93edf749`). Then run:

    python -B scripts/build_b90_capability_v1.py --native-root PATH_TO_PINNED_NATIVE
    python -B scripts/validate_b90_capability_v1.py --native-root PATH_TO_PINNED_NATIVE

The adapter preserves the explicit exclusion of the answer supplement and does not claim semantic HTML, WCAG conformance, solutions, or reversible exchange.
