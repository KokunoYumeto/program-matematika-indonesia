# C60 thin capability packet

This packet contains only C60 adapter metadata, two Indonesian adapter views, validation evidence, negative fixtures, and four Python scripts. It contains no native textbook body, PDF, TeX, image, release archive, credential, cache, or learner data.

Rebuild requires the separate public source checkout at commit `66df945d1e5281bfc4758b733c13ac9254f00410` (tree `5132900227e1b1a06cdc3facac691e18a7bdb10f`), whose native backend tree `a5a8a7a3e010e6372c2c22051d1f922327f2f763` is unchanged from release commit `11e27180632af3b90202ad38c063807c0d057766`. Run:

    python -B scripts/build_c60_capability_v1.py --native-root PATH_TO_PINNED_PUBLIC_CLONE
    python -B scripts/validate_c60_capability_v1.py --native-root PATH_TO_PINNED_PUBLIC_CLONE
    python -B scripts/package_c60_capability_v1.py --native-root PATH_TO_PINNED_PUBLIC_CLONE

The common map carries 101 native exercise identities with hint/check/solution explicitly marked `not_present` and `source_has_none`; it supplies no assessment or execution service.
