# B95 thin capability packet

This packet contains only B95/R011-B039 metadata, stable identity indexes, generated learner and educator views, validation evidence, negative fixtures, and standard-library Python scripts. It does not contain the native backend dataset, textbook or exercise bodies, answers, solutions, TeX, PDFs, credentials, caches, or logs.

Deterministic replay requires the separately preserved native checkout and the exact hash-pinned source inputs recorded in the adapter's input/source-lock.json. Then run:

    python -B scripts/build_b95_capability_v1.py --native-root PATH_TO_PINNED_NATIVE
    python -B scripts/validate_b95_capability_v1.py --native-root PATH_TO_PINNED_NATIVE

The adapter preserves native identifiers, structure, terminology, rights, and public release evidence while making no semantic-HTML, WCAG, EPUB, offline, answer-key, or reversible-exchange claim.
