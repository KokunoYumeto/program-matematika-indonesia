# D30 thin capability packet

Metadata and evidence only. Native prose, formulas, code, HTML, PDF, notebooks, and archives are excluded. Supply the pinned native checkout with `--native` to rebuild or validate.
