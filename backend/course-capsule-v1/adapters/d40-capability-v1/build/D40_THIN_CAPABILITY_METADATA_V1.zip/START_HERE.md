# D40 thin capability validation packet

This packet contains only the D40 adapter, its four standard-library scripts,
and hash-locked metadata/evidence inputs. It excludes the public PDF and ZIP,
the book/reader payload, source prose, TeX, notebooks, native course code
bodies, and runtime artifacts. The four included Python files are only the D40
adapter model, builder, validator, and thin packager.

From this extracted directory run:

    python -B scripts/build_d40_capability_v1.py --native-root native --allow-identity-only-public-artifacts
    python -B scripts/validate_d40_capability_v1.py --native-root native --allow-identity-only-public-artifacts

The identity-only flag applies only to the absent public PDF/ZIP. Their exact
byte identities are cross-checked against the included publication and
anonymous-readback receipts. It is not a full native roundtrip.
