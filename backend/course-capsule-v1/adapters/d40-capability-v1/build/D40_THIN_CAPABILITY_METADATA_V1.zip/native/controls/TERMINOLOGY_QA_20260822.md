# QA terminologi Indonesia — saksi arXiv 2001.05854v1

Tanggal pemeriksaan: 2026-08-22  
Putusan: **lulus; tidak ada perubahan istilah atau propagasi yang diperlukan**

## Otoritas yang diperiksa

Pencarian dibatasi pada sumber arXiv resmi dan menemukan satu karya yang
benar-benar memuat sumber TeX berbahasa Indonesia dalam bidang PDP:

- Natanael Karjanto, *A theoretical study on a two-dimensional flap-type
  wavemaker*, arXiv:2001.05854v1, diajukan 11 Januari 2020;
- judul karya Indonesia di dalam sumber: *Teori Pembangkit Gelombang
  Dua-Dimensi Tipe Flap*;
- rekaman resmi: <https://arxiv.org/abs/2001.05854>;
- paket sumber resmi: <https://arxiv.org/src/2001.05854v1>;
- lisensi yang ditautkan rekaman arXiv: CC BY-SA 4.0;
- paket sumber: 144.585 byte, SHA-256
  `520cd160b47664dda32e57df87a6eb028348154e4d7a7494d230e8e517891d53`,
  20 berkas (dua TeX dan 18 PNG);
- TeX Indonesia `2001arXivTA-Indonesian.tex`: 91.655 byte, 2.076 baris,
  SHA-256
  `03f7e68801badc84255df3323078ae00eee7ecff8a9f118cba064ce5d46ff2f2`.

Arsip dan hasil ekstraksi disimpan di
`composite/authority/terminology-witness/arxiv-2001.05854v1`. Ini adalah
saksi terminologi saja dan bukan komponen edisi Dionne.

## Perbandingan istilah dari TeX nyata

Pencacahan menormalkan spasi/baris TeX. Sumber memakai `persamaan
diferensial parsial` dua kali, `syarat batas` 37 kali, `masalah nilai batas`
dan `persoalan nilai batas` masing-masing sekali, `permukaan bebas` 18 kali,
`gradien` sekali, `vektor normal satuan` dua kali, `solusi` enam kali,
`penyelesaian` empat kali, `persamaan Laplace` lima kali, `daerah` tujuh kali,
dan kata pinjaman `domain` sekali.

Penggunaan ini secara langsung menguatkan pilihan glosarium Dionne
`persamaan diferensial parsial`, `masalah nilai batas`, `permukaan`,
`gradien`, `vektor normal`, `solusi`, dan penggunaan `daerah` dalam Unit 03.
Variasi `persoalan nilai batas` dan `penyelesaian` menunjukkan sinonim yang
sah, tetapi tidak memberi alasan untuk mengganti istilah utama yang sudah
konsisten.

Karya ini tidak memakai istilah teknis `karakteristik`, `selubung`, `keluarga
permukaan`, `Teorema Fungsi Implisit`, `kurva kontak`, `submersi`, `kurva
level`, `solusi lemah`, `Sobolev`, `Lax-Milgram`, `eliptik`, `parabolik`, atau
`hiperbolik`. Ketidakhadiran itu dicatat sebagai tidak ada bukti, bukan bukti
yang menolak pilihan Dionne.

## Keputusan

Tidak ada perbedaan bermakna yang membenarkan perubahan. Karena itu
`controls/TERMINOLOGY.csv` dan Unit 01–03 tidak diubah oleh pemeriksaan ini.
Saksi memiliki cakupan klasik/terapan (Laplace dan syarat batas), sehingga ia
representatif untuk istilah dasar bidang tetapi tidak dipakai untuk mengklaim
konvensi analisis fungsional modern.

Metadata edisi/rilis berikutnya harus mencantumkan provenans model secara
eksplisit sebagai: **OpenAI Codex gpt-5.6-sol, Ultra**. Semua kredit Benoit
Dionne, Natanael Karjanto sebagai penulis saksi, dan kontributor manusia tetap
terpisah dan dipertahankan.
