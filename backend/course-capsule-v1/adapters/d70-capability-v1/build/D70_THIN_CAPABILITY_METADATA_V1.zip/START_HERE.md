# D70 thin capability validation packet

This packet contains the D70 adapter, its four standard-library scripts, the
shared capability schema, and the 57 exact hash-locked native metadata/evidence
inputs needed for deterministic replay. It excludes PDFs, TeX, images, source
archives, reader/book body files, credentials, caches, and runtime artifacts.

From this extracted directory run:

    python -B scripts/build_d70_capability_v1.py --native native --output backend/course-capsule-v1/adapters/d70-capability-v1 --lock backend/course-capsule-v1/adapters/d70-capability-v1/input/source-lock.json
    python -B scripts/validate_d70_capability_v1.py --native native --output backend/course-capsule-v1/adapters/d70-capability-v1 --lock backend/course-capsule-v1/adapters/d70-capability-v1/input/source-lock.json

This is a metadata/evidence projection, not a complete native-book roundtrip.
