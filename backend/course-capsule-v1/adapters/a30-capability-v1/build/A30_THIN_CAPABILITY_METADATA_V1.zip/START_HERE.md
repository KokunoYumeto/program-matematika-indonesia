# A30 thin capability packet

This packet contains only A30 adapter metadata, stable-identity indexes, generated learner and educator views, validation evidence, negative fixtures, and Python standard-library scripts. It does not contain the native backend dataset, source text, target text, textbook bodies, segment text, exercise/problem/solution bodies, TeX, PDFs, EPUBs, images, credentials, caches, or logs.

Deterministic replay requires the separately preserved final public backend-core ZIP, the pinned producer QA evidence listed in `input/source-lock.json`, and the source companion required by the producer for full replay. The canonical JSONL member SHA-256 is `4f2f51457adde0516c17b1633327a3bfbbf273a67925514bbb6c390f5e58a054`. Then run:

    python -B scripts/build_a30_capability_v1.py --native-root PATH_TO_PINNED_NATIVE
    python -B scripts/validate_a30_capability_v1.py --native-root PATH_TO_PINNED_NATIVE

A20 is a central curriculum overlay only. The packet preserves the exact 4,183/3,067 solution-supported/unsupported boundary and segment-state asymmetry. It does not claim a final derivative Git commit/tree, semantic HTML, MathML, EPUB, portable HTML, PDF/UA, WCAG conformance, labs, a runtime, an official teacher manual, per-exercise PDF destinations, standalone raw replay, or reversible exchange.
