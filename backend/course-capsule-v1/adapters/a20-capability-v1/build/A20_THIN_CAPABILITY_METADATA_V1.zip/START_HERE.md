# A20 thin capability packet

This packet contains only A20 adapter metadata, stable-identity indexes, generated learner and educator views, validation evidence, negative fixtures, and standard-library Python scripts. It does not contain the native backend dataset, textbook bodies, TeX source, PDFs, EPUBs, images, credentials, caches, or logs.

Deterministic replay requires the separately preserved A20 interoperability export identified by SHA-256 `f8536e60b6e6fde9855da51e9d1d9037e5772190a1fd2e6ee4189c1f024172d3` and the exact public-release evidence in `input/public-native-readback.json`. Then run:

    python -B scripts/build_a20_capability_v1.py --native-root PATH_TO_PINNED_NATIVE
    python -B scripts/validate_a20_capability_v1.py --native-root PATH_TO_PINNED_NATIVE

The adapter preserves the exact solved/unsolved identity boundary and does not claim semantic Indonesian HTML, MathML, PDF/UA, WCAG conformance, complete solutions, or reversible exchange.
