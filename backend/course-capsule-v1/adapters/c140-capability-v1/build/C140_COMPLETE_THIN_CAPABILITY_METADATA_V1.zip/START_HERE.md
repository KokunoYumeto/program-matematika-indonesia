# C140 complete thin capability packet

This packet contains only the complete C140/C5 metadata projection, stable identity indexes, component-aware rights, public route evidence, learner and educator views, negative fixtures, and standard-library Python scripts. It does not contain Penn, Random, companion, problem, answer, solution, PDF, EPUB, TeX, image, or dataset bodies.

Deterministic replay needs the separately preserved, hash-pinned native checkout. Run:

    python -B scripts/build_c140_capability_v1.py --native-root PATH_TO_PINNED_NATIVE
    python -B scripts/validate_c140_capability_v1.py --native-root PATH_TO_PINNED_NATIVE

The boundary is fourteen Penn documents, one Random completeness donor, and thirty-nine original companion documents. Rights for Penn, both Random witnesses, MathJax, the companion, and both capstone datasets remain separate.
