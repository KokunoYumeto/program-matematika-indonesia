# D100 thin capability validation packet

This packet contains the D100 common-backend adapter, its four standard-library
Python scripts, public readback evidence, negative fixtures, and the 19 exact
hash-locked native inputs required for deterministic adapter replay. Those
inputs include structured JSON/JSONL records with mathematical Markdown; this
is not a metadata-only package. It excludes PDFs, TeX, images, source archives,
rendered reader/book files, credentials, caches, and runtime artifacts.

From this extracted directory run:

    python -B scripts/build_d100_capability_v1.py --native-root native --output-root backend/course-capsule-v1/adapters/d100-capability-v1 --source-lock backend/course-capsule-v1/adapters/d100-capability-v1/input/source-lock.json
    python -B scripts/validate_d100_capability_v1.py --native-root native --output-root backend/course-capsule-v1/adapters/d100-capability-v1 --source-lock backend/course-capsule-v1/adapters/d100-capability-v1/input/source-lock.json --receipt backend/course-capsule-v1/adapters/d100-capability-v1/validation.json

This is a metadata/evidence projection, not a complete native-book roundtrip.
The native build and strict source-profile replay remain available but unverified.
