Bangun ulang / Rebuild: python -B scripts/a00-native-ledger-v1.py
Uji / Test: python -B scripts/test-a00-native-ledger-v1.py
Python 3 dan Node.js diperlukan / Python 3 and Node.js required.
Paket berisi metadata dan sumber antarmuka, bukan isi buku.
Metadata and interface sources only, not book bodies.
MIT: kode antarmuka / interface code. Catatan hak bahan asli / native material rights:
backend/course-capsule-v1/adapters/a00-native-ledger-v1/input/native-LICENSE.txt
backend/course-capsule-v1/adapters/a00-native-ledger-v1/input/rights.jsonl
