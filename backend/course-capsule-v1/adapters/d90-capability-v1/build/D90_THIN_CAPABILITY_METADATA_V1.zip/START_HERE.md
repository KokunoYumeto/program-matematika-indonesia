# D90 thin capability packet

This packet contains only the D90 zero-copy adapter metadata, generated views, validation evidence, negative fixtures, and four standard-library Python scripts. It does not contain the native JSONL/CSV dataset, course prose, solution bodies, TeX, HTML, PDF, or EPUB.

Deterministic rebuild and validation require a separate checkout of https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id at commit `eb6b25cb6d2c84d32c5b0a30b0feea9e97efefab` (tree `f3cd6fb20a1dc8f157c6072ff398d0fc03167e84`). Then run:

    python -B scripts/build_d90_capability_v1.py --native-root PATH_TO_PINNED_NATIVE
    python -B scripts/validate_d90_capability_v1.py --native-root PATH_TO_PINNED_NATIVE

The adapter preserves identity/state/evidence and stable public anchors; it does not claim reversible exchange with the native representation.
