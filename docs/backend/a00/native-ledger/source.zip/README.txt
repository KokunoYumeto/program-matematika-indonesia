Bangun ulang / Rebuild: python -B scripts/a00-native-ledger-v1.py
Uji / Test: python -B scripts/test-a00-native-ledger-v1.py
Python 3 dan Node.js diperlukan / Python 3 and Node.js required.
Paket berisi metadata, cuplikan konkordansi terbatas dan sumber antarmuka, bukan buku lengkap.
Metadata, bounded concordance excerpts and interface sources, not whole books.
MIT: kode antarmuka / interface code. Catatan hak bahan asli / native material rights:
backend/course-capsule-v1/adapters/a00-native-ledger-v1/input/native-LICENSE.txt
backend/course-capsule-v1/adapters/a00-native-ledger-v1/input/rights.jsonl
