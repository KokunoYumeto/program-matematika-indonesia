Bangun ulang / Rebuild: python -B scripts/build-clp1-term-view-v1.py
Uji / Test: python -B scripts/test-clp1-term-view-v1.py --skip-replay
Uji pencarian / Test search: node scripts/test-clp1-term-ui-v1.mjs
Buka / Open: docs/backend/clp/B20.terms.html or B20.terms.en.html
Paket metadata dan antarmuka; tidak memuat buku atau perencana tugas.
Metadata and interface package; books and assignment planners are not included.
Kode antarmuka / interface code: MIT. Bahan CLP / CLP material: CC BY-NC-SA 4.0, see docs/backend/clp/clp1-terms-data.
