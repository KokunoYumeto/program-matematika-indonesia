[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$candidateRoot = Join-Path $projectRoot 'build\cring-selected-candidate'
$sourceRoot = Join-Path $candidateRoot 'repaired-source-en'
$targetRoot = Join-Path $candidateRoot 'translated-id'
$receiptPath = Join-Path $PSScriptRoot 'cring-selected-aggregate-validation.json'

$fileSpecs = @(
    [pscustomobject]@{ File='01-nakayama.tex'; Records=209; Bytes=9054; Sha256='690bd9a088d4a2dcb5f0b52ac1940568cc0765a47a82975a77247af9c51b2978'; Bridges=0; Repairs=1 },
    [pscustomobject]@{ File='02-spec-zariski.tex'; Records=903; Bytes=31316; Sha256='96e17c84fa1176f0f3a7cfb5ea7307b7ca707b86f8dd7dc226b04ff615855e3b'; Bridges=1; Repairs=3 },
    [pscustomobject]@{ File='03-associated-primary.tex'; Records=881; Bytes=38770; Sha256='2f13f8b3aeb1ddbf922f7a985de796975d74a025a468124c361f1b9fa805aeaa'; Bridges=3; Repairs=3 },
    [pscustomobject]@{ File='04-lying-over-going-up.tex'; Records=238; Bytes=11335; Sha256='a3c2ff0828374c11aecabe1c6d2566039bf375ec2071f7f22c26834214b2677b'; Bridges=0; Repairs=1 },
    [pscustomobject]@{ File='05-nullstellensatz-normalization.tex'; Records=330; Bytes=16325; Sha256='16c406d87354f7ff451313858dbb25b83a39d7d103788996295a607ecfe4752c'; Bridges=0; Repairs=0 },
    [pscustomobject]@{ File='06-krull-dimension.tex'; Records=1028; Bytes=46085; Sha256='4d986cca14cf2f9396b8b340d660b4acae5fa106468cb4cfc4f5cdd936c4eef4'; Bridges=0; Repairs=1 }
)

$repairSpecs = @(
    [pscustomobject]@{ Id='CRING-R01-empty-projective-reference'; File='01-nakayama.tex'; Source='projective-module discussion in Li, Chapter 6'; Target='pembahasan modul proyektif dalam Li, Bab 6' },
    [pscustomobject]@{ Id='CRING-R02-empty-ufd-reference'; File='02-spec-zariski.tex'; Source='polynomial-ring UFD result developed in Li, Chapter 5'; Target='hasil UFD bagi gelanggang polinomial yang dikembangkan dalam Li, Bab 5' },
    [pscustomobject]@{ Id='CRING-R03-missing-semilocal-proof'; File='02-spec-zariski.tex'; Source='surjective, so choose $x_1,\ldots,x_d\in M$'; Target='surjektif, jadi pilih $x_1,\ldots,x_d\in M$' },
    [pscustomobject]@{ Id='CRING-R03A-malformed-mu-max'; File='02-spec-zariski.tex'; Source='\mu_R(M) = \max_i \{\dim_{k_i} M/\mathfrak{m}_i M\}'; Target='\mu_R(M) = \max_i \{\dim_{k_i} M/\mathfrak{m}_i M\}' },
    [pscustomobject]@{ Id='CRING-R04-undefined-annihilator-notation'; File='03-associated-primary.tex'; Source='\ann_R(x)=\{r\in R:rx=0\}'; Target='\ann_R(x)=\{r\in R:rx=0\}' },
    [pscustomobject]@{ Id='CRING-R05-irreducibility-definition'; File='03-associated-primary.tex'; Source='A nonempty closed subset is irreducible'; Target='Suatu himpunan bagian tertutup tak kosong disebut tak tereduksi' },
    [pscustomobject]@{ Id='CRING-R06-embedded-prime-example'; File='03-associated-primary.tex'; Source='ideal $(x,y)$ is embedded.'; Target='maksimal $(x,y)$ tertanam.' },
    [pscustomobject]@{ Id='CRING-R07-constructibility-placeholder'; File='04-lying-over-going-up.tex'; Source="Chevalley's constructibility theorem; its proof lies outside this selected supplement"; Target='teorema konstruktibilitas Chevalley; buktinya berada di luar suplemen pilihan ini' },
    [pscustomobject]@{ Id='CRING-R08-two-empty-dvr-references'; File='06-krull-dimension.tex'; Source="DVR characterization proved in the full source's Dedekind-ring chapter"; Target='karakterisasi DVR dibuktikan dalam bab mengenai gelanggang Dedekind pada sumber lengkap' }
)

function Get-Sha256Bytes([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return ([Convert]::ToHexString($sha.ComputeHash($Bytes))).ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-Sha256Text([string]$Text) {
    return Get-Sha256Bytes ([Text.Encoding]::UTF8.GetBytes($Text))
}

function Read-StrictUtf8Lf([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Missing required file: $Path"
    }
    $bytes = [IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        throw "UTF-8 BOM is not permitted: $Path"
    }
    $utf8 = New-Object Text.UTF8Encoding($false, $true)
    $text = $utf8.GetString($bytes)
    if ($text.Contains("`r")) {
        throw "Non-LF newline found: $Path"
    }
    return [pscustomobject]@{
        Path = $Path
        Bytes = $bytes
        ByteCount = $bytes.Length
        Text = $text
        Sha256 = Get-Sha256Bytes $bytes
    }
}

function Get-Records([string]$Text) {
    if ($Text.Length -eq 0) { return ,@() }
    $records = [regex]::Split($Text, "`n")
    if ($Text.EndsWith("`n")) {
        if ($records.Count -eq 1) { return ,@() }
        $records = $records[0..($records.Count - 2)]
    }
    return ,$records
}

function Get-BlankMap([string[]]$Records) {
    $blank = [Collections.Generic.List[int]]::new()
    for ($i = 0; $i -lt $Records.Count; $i++) {
        if ([string]::IsNullOrWhiteSpace($Records[$i])) { $blank.Add($i + 1) }
    }
    return ,$blank.ToArray()
}

function Get-Signature([string]$Text, [string]$Pattern) {
    $values = [regex]::Matches($Text, $Pattern, [Text.RegularExpressions.RegexOptions]::Singleline) |
        ForEach-Object { $_.Value }
    return [string]::Join("`n", $values)
}

function Get-NormalizedMath([string]$Text) {
    $mathPattern = '(?s)\\\[(.*?)\\\]|\\\((.*?)\\\)|(?<!\\)\$\$(.*?)\$\$|(?<!\\)\$(?!\$)(.*?)(?<!\\)\$'
    $values = [Collections.Generic.List[string]]::new()
    foreach ($match in [regex]::Matches($Text, $mathPattern)) {
        $value = $match.Value
        $textualPattern = '\\(?:text|textrm|mathrm|mbox)\{(?:[^{}]|\{[^{}]*\})*\}'
        $value = [regex]::Replace($value, $textualPattern, '\TEXT{}')
        $value = [regex]::Replace($value, '\s+', '')
        $values.Add($value)
    }
    return [string]::Join("`n", ($values | Sort-Object))
}

function Get-DisallowedResidue([string]$Text) {
    $mathPattern = '(?s)\\\[(.*?)\\\]|\\\((.*?)\\\)|(?<!\\)\$\$(.*?)\$\$|(?<!\\)\$(?!\$)(.*?)(?<!\\)\$'
    $prose = [regex]::Replace($Text, $mathPattern, ' ')
    $prose = [regex]::Replace($prose, '(?m)(?<!\\)%.*$', ' ')
    $prose = [regex]::Replace($prose, '\\(?:label|ref|rref|eqref|pageref|autoref|cref|Cref|cite|citep|citet)\s*(?:\[[^\]]*\]\s*)*\{[^{}]*\}', ' ')
    $prose = [regex]::Replace($prose, '\\(?:begin|end)\{[^{}]*\}', ' ')
    $prose = [regex]::Replace($prose, '\\[A-Za-z@]+\*?', ' ')
    $prose = [regex]::Replace($prose, '\\.', ' ')

    $englishPattern = '(?i)\b(?:the|and|where|then|we|is|are|was|were|be|being|of|to|for|with|from|this|that|which|every|there|otherwise|let|suppose|assume|show|follows|proof|exercise|definition|theorem|proposition|corollary|remark|example|chapter)\b'
    $placeholderPattern = '(?i)\b(?:TODO|TBD|PLACEHOLDER|UNTRANSLATED|TRANSLATION\s+MISSING)\b|\[MASK\]|<\s*(?:translate|translation|placeholder)[^>]*>'
    $cjkPattern = '[\p{IsCJKUnifiedIdeographs}\p{IsHiragana}\p{IsKatakana}\p{IsHangulSyllables}]'

    return [pscustomobject]@{
        English = @([regex]::Matches($prose, $englishPattern) | ForEach-Object { $_.Value.ToLowerInvariant() })
        Placeholders = @([regex]::Matches($Text, $placeholderPattern) | ForEach-Object { $_.Value })
        Cjk = @([regex]::Matches($Text, $cjkPattern) | ForEach-Object { $_.Value })
    }
}

$commandPattern = '\\(?:[A-Za-z@]+|.)'
$environmentPattern = '\\(?:begin|end)\{[^{}]+\}'
$xrefPattern = '\\(?:label|ref|rref|eqref|pageref|autoref|cref|Cref|cite|citep|citet)\s*(?:\[[^\]]*\]\s*)*\{[^{}]*\}'
$pairResults = [Collections.Generic.List[object]]::new()
$loadedPairs = @{}

foreach ($spec in $fileSpecs) {
    $source = Read-StrictUtf8Lf (Join-Path $sourceRoot $spec.File)
    $target = Read-StrictUtf8Lf (Join-Path $targetRoot $spec.File)
    $loadedPairs[$spec.File] = [pscustomobject]@{ Source=$source; Target=$target }

    $sourceRecords = Get-Records $source.Text
    $targetRecords = Get-Records $target.Text
    $sourceBlank = Get-BlankMap $sourceRecords
    $targetBlank = Get-BlankMap $targetRecords
    $residue = Get-DisallowedResidue $target.Text
    $sourceBridges = [regex]::Matches($source.Text, 'Edition bridge \(original\)\.').Count
    $targetBridges = [regex]::Matches($target.Text, 'Jembatan edisi \(asli\)\.').Count

    $checks = [ordered]@{
        source_pin = ($sourceRecords.Count -eq $spec.Records -and $source.ByteCount -eq $spec.Bytes -and $source.Sha256 -ceq $spec.Sha256)
        record_count = ($sourceRecords.Count -eq $targetRecords.Count)
        blank_map = ([string]::Join(',', $sourceBlank) -ceq [string]::Join(',', $targetBlank))
        command_topology = ((Get-Signature $source.Text $commandPattern) -ceq (Get-Signature $target.Text $commandPattern))
        environment_topology = ((Get-Signature $source.Text $environmentPattern) -ceq (Get-Signature $target.Text $environmentPattern))
        xref_topology = ((Get-Signature $source.Text $xrefPattern) -ceq (Get-Signature $target.Text $xrefPattern))
        normalized_math = ((Get-NormalizedMath $source.Text) -ceq (Get-NormalizedMath $target.Text))
        utf8_lf = $true
        repair_bridge_markers = ($sourceBridges -eq $spec.Bridges -and $targetBridges -eq $spec.Bridges)
        residue = ($residue.English.Count -eq 0 -and $residue.Placeholders.Count -eq 0 -and $residue.Cjk.Count -eq 0)
    }
    $pairPass = @($checks.Values | Where-Object { -not $_ }).Count -eq 0
    $pairResults.Add([pscustomobject][ordered]@{
        file = $spec.File
        records = $targetRecords.Count
        blank_records = $targetBlank.Count
        source_bytes = $source.ByteCount
        source_sha256 = $source.Sha256
        target_bytes = $target.ByteCount
        target_sha256 = $target.Sha256
        repairs = $spec.Repairs
        checks = $checks
        result = $(if ($pairPass) { 'PASS' } else { 'FAIL' })
    })
}

$repairResults = [Collections.Generic.List[object]]::new()
foreach ($repair in $repairSpecs) {
    $pair = $loadedPairs[$repair.File]
    $sourceOk = $pair.Source.Text.Contains($repair.Source)
    $targetOk = $pair.Target.Text.Contains($repair.Target)
    $repairResults.Add([pscustomobject][ordered]@{
        id = $repair.Id
        file = $repair.File
        source_marker = $sourceOk
        target_marker = $targetOk
        result = $(if ($sourceOk -and $targetOk) { 'PASS' } else { 'FAIL' })
    })
}

$sourceRecordsTotal = ($pairResults | Measure-Object -Property records -Sum).Sum
$sourceBytesTotal = ($pairResults | Measure-Object -Property source_bytes -Sum).Sum
$targetBytesTotal = ($pairResults | Measure-Object -Property target_bytes -Sum).Sum
$blankTotal = ($pairResults | Measure-Object -Property blank_records -Sum).Sum
$repairCount = ($fileSpecs | Measure-Object -Property Repairs -Sum).Sum
$pairsPass = @($pairResults | Where-Object { $_.result -ne 'PASS' }).Count -eq 0
$repairsPass = @($repairResults | Where-Object { $_.result -ne 'PASS' }).Count -eq 0
$allPass = $pairsPass -and $repairsPass -and $repairCount -eq 9
$manifest = [string]::Join("`n", ($pairResults | ForEach-Object { "$($_.file)|$($_.source_sha256)|$($_.target_sha256)" }))

$receipt = [ordered]@{
    schema = 'cring-selected.aggregate-validation.v1'
    generated_utc = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    validator = 'qa/cring-selected-evidence/validate-cring-selected.ps1'
    validator_sha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    source_root = 'build/cring-selected-candidate/repaired-source-en'
    target_root = 'build/cring-selected-candidate/translated-id'
    license_boundary = 'GFDL-1.2-or-later; edition-original bridges and edition-correction remain explicitly tracked'
    math_normalization = 'formula multiset with multiplicity preserved; whitespace and textual TeX arguments normalized'
    pair_count = $pairResults.Count
    repair_count = $repairCount
    totals = [ordered]@{
        records_each_side = $sourceRecordsTotal
        blank_records_each_side = $blankTotal
        source_bytes = $sourceBytesTotal
        target_bytes = $targetBytesTotal
    }
    pair_manifest_sha256 = Get-Sha256Text $manifest
    pairs = $pairResults
    repair_markers = $repairResults
    result = $(if ($allPass) { 'PASS' } else { 'FAIL' })
}

$json = $receipt | ConvertTo-Json -Depth 8 -Compress
[IO.File]::WriteAllText($receiptPath, $json + "`n", (New-Object Text.UTF8Encoding($false)))

if (-not $allPass) {
    throw "CRing aggregate validation failed; see $receiptPath"
}

Write-Output $receiptPath
