# Sources and authorship

This course is distributed under the GNU Free Documentation License, version 1.2 or any later version, with no Invariant Sections, Front-Cover Texts or Back-Cover Texts. Permission is granted to copy, distribute and modify this document under those terms. The full licence is included in [COPYING](COPYING).

The Stacks project authors are the authors of the statements and proofs adapted from the AI Integrated Stacks Project. The source edition is commit `565b10e987aba5969b21145a0833f42d69f96790`, with upstream Stacks commit `a04446e57ec1fbc252a871afcec7752fb2807b14`. These passages are GFDL-1.2-or-later. AI Integrated Stacks Project is an unofficial edition, not affiliated with, approved by or reviewed by the Stacks project's maintainers.

The edition records corrections by GPT-5.6 Sol (OpenAI), Ultra, integrated by GPT-6 Astra (OpenAI), Ultra, and additions principally by GPT-6 Astra, with some GPT-5.6 Sol contributions checked by GPT-6 Astra. The course's module-sheaf exposition includes Claude Opus 5.5 (Anthropic) contributions. Resolution and derived-functor proof contributions include GPT-6 Astra (OpenAI), Ultra. The model identity for one part of the K-flat construction is unverified. Course exposition, proof expansions and mathematical self-checking are by GPT-6.1 Sol (OpenAI), Ultra, October 2026. Independent AI review, human review and formal verification are not claimed.

Independently authored programme explanations, examples, exercises and proofs dedicated under CC0 remain available under CC0 1.0. That dedication does not change the terms of the Stacks-derived passages. The combined course uses GFDL-1.2-or-later.

## Mathematical sources and contributions

- **Sheaves of modules.** *Sheaves on Spaces* and *Sheaves of Modules* supply the sheaf and module constructions. The course develops germ-family sheafification, stalk bijections, associative-ring module structures and their full universal-property proofs.
- **Complexes and localization.** *Derived Categories* supplies cone and triangulation arguments; the course develops roofs, common refinements and localization checks. The diagram and elementary cohomology prerequisites are in Wen-Wei Li's *Methods of Algebra, Volume 2*, in the programme's English edition.
- **Injective and K-injective resolutions.** *Injectives*, *Derived Categories* and *Cohomology of Sheaves* supply the resolution methods. The course includes flasque-section arguments, large-cofinality and transfinite constructions. The Stacks chapter credits Christian Serpé and Nicolas Spaltenstein for the unbounded-resolution theory; *Sets* credits the large-cofinality method to Grothendieck.
- **Flat and K-flat resolutions.** *Modules on Ringed Spaces* and *Cohomology of Sheaves* supply flat-module and compatible-resolution methods. The course develops cycle attachments, complete flatness calculations and compatible resolutions.
- **Tensor, pullback and pushforward.** *Cohomology of Sheaves* supplies tensor, Tor, pullback and local-cohomology arguments. The course includes fibre-product comparisons, coherence, the general derived adjunction, coefficient comparisons and Leray exact-couple details.
- **Derived Hom and supports.** *Cohomology of Sheaves* and *Sheaves of Modules* supply Hom and closed-support arguments. The course includes sign calculations, functoriality, composition and dinaturality, locally closed supports, and singular-cochain comparison on Euclidean opens.
- **Perfect complexes, projection and base change.** *Cohomology of Sheaves* supplies finite-model, pseudo-coherence, Tor-amplitude, duality, projection and base-change methods. The course develops the finite-cell retract argument, local and pasting checks, coefficient-model comparisons, examples and exercises.

The lesson texts identify individual sources and mathematical conditions. Adaptations and proof expansions dated 1–3 October 2026 are by GPT-6.1 Sol (OpenAI), Ultra, with the contributions credited above. Stacks-derived constructions remain GFDL-1.2-or-later.

[AI Integrated Stacks Project source edition](https://github.com/KokunoYumeto/unofficial-stacks-project-ai-drafts/tree/565b10e987aba5969b21145a0833f42d69f96790) · [Stacks project](https://stacks.math.columbia.edu/) · [Methods of Algebra, Volume 2](https://kokunoyumeto.github.io/methods-of-algebra-volume-2-en/) · [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)
