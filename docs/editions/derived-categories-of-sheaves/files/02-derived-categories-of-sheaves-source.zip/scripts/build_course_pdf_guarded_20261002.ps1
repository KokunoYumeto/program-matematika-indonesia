param([int]$Passes=3,[string]$Work='',[string]$XeLaTex='')
$ErrorActionPreference='Stop'
$taskDefault=if(Test-Path -LiteralPath (Join-Path $PSScriptRoot '..\SOURCE_MANIFEST.json')){Join-Path $PSScriptRoot '..'}else{Join-Path $PSScriptRoot '..\programme-format-pilot\RT-FIN-20261002'}
$taskWork=[IO.Path]::GetFullPath($(if($Work){$Work}else{$taskDefault}))
$taskEngine=if($XeLaTex){$XeLaTex}else{(Get-Command xelatex -ErrorAction Stop).Source}
$taskOutput=Join-Path $taskWork 'output'
$taskManifest=Get-Content -LiteralPath (Join-Path $taskWork 'SOURCE_MANIFEST.json') -Raw|ConvertFrom-Json
$taskSlug=if($taskManifest.export.slug){$taskManifest.export.slug}else{'representations-of-finite-groups'}
$taskEpoch=if($taskManifest.export.epoch){[string]$taskManifest.export.epoch}else{'1790899200'}
if($taskSlug -notmatch '^[a-z0-9-]+$'){throw 'Unsafe export slug'}
$taskTex=Join-Path $taskOutput "01-$taskSlug.tex"
if(-not(Test-Path -LiteralPath $taskTex)){throw 'Exact course source missing'}
$taskMutex=[Threading.Mutex]::new($false,'Global\InterlanguageTeXSlotV1')
$taskAcquired=$false;$taskAbandoned=$false;$taskRuns=@()
try {
  try{$taskAcquired=$taskMutex.WaitOne(1000)}catch [Threading.AbandonedMutexException]{$taskAcquired=$true;$taskAbandoned=$true}
  if(-not $taskAcquired){
    [pscustomobject]@{state='tex_slot_unavailable';action='Continue EPUB and source validation; no wait or translation hold'}|ConvertTo-Json -Compress
    exit 75
  }
  for($taskPass=1;$taskPass -le $Passes;$taskPass++){
    $taskStart=[Diagnostics.ProcessStartInfo]::new()
    $taskStart.FileName=$taskEngine
    $taskStart.WorkingDirectory=$taskOutput
    $taskStart.UseShellExecute=$false;$taskStart.CreateNoWindow=$true
    $taskStart.RedirectStandardOutput=$true;$taskStart.RedirectStandardError=$true
    foreach($taskArgument in @('-disable-installer','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error',"-jobname=00-$taskSlug",[IO.Path]::GetFileName($taskTex))){[void]$taskStart.ArgumentList.Add($taskArgument)}
    $taskStart.Environment['SOURCE_DATE_EPOCH']=$taskEpoch
    $taskStart.Environment['FORCE_SOURCE_DATE']='1'
    $taskProcess=[Diagnostics.Process]::new();$taskProcess.StartInfo=$taskStart
    [void]$taskProcess.Start();$taskStdout=$taskProcess.StandardOutput.ReadToEndAsync();$taskStderr=$taskProcess.StandardError.ReadToEndAsync()
    if(-not $taskProcess.WaitForExit(300000)){
      $taskProcess.Kill($true);$taskProcess.WaitForExit();throw 'Captured TeX tree exceeded five-minute bound and was stopped'
    }
    $taskOutText=$taskStdout.GetAwaiter().GetResult();$taskErrText=$taskStderr.GetAwaiter().GetResult()
    [IO.File]::WriteAllText((Join-Path $taskWork "qa\tex-pass-$taskPass.log"),$taskOutText+"`n"+$taskErrText,[Text.UTF8Encoding]::new($false))
    $taskRuns += [pscustomobject]@{pass=$taskPass;pid=$taskProcess.Id;exit_code=$taskProcess.ExitCode;log="qa/tex-pass-$taskPass.log"}
    if($taskProcess.ExitCode -ne 0){throw "TeX pass $taskPass failed; see captured log"}
  }
  $taskPdf=Join-Path $taskOutput "00-$taskSlug.pdf"
  $taskReceipt=[pscustomobject]@{schema='serialized-course-pdf-build/1';state='compiled_pending_render_validation';mutex='Global\InterlanguageTeXSlotV1';abandoned_mutex_recovered=$taskAbandoned;source_sha256=(Get-FileHash -LiteralPath $taskTex -Algorithm SHA256).Hash.ToLowerInvariant();runs=$taskRuns;pdf=[pscustomobject]@{path="output/00-$taskSlug.pdf";bytes=(Get-Item -LiteralPath $taskPdf).Length;sha256=(Get-FileHash -LiteralPath $taskPdf -Algorithm SHA256).Hash.ToLowerInvariant()}}
  $taskReceiptJson=$taskReceipt|ConvertTo-Json -Depth 6
  [IO.File]::WriteAllText((Join-Path $taskWork 'PDF_BUILD_RECEIPT.json'),$taskReceiptJson+"`n",[Text.UTF8Encoding]::new($false))
  $taskReceiptJson
}finally{if($taskAcquired){$taskMutex.ReleaseMutex()};$taskMutex.Dispose()}
