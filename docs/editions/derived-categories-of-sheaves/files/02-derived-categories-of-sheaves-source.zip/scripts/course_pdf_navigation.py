"""Preserve native alias destinations and readable mathematical bookmarks."""
import re

def balanced(text, start, opening='{', closing='}'):
    assert text[start] == opening
    depth=1;i=start+1
    while i<len(text):
        if text[i]=='\\':i+=2;continue
        if text[i]==opening:depth+=1
        elif text[i]==closing:
            depth-=1
            if depth==0:return text[start+1:i],i+1
        i+=1
    raise ValueError('Unclosed generated TeX group')

def apply(tex):
    text=tex.decode('utf-8');targets=set(re.findall(r'\\hypertarget\{([^{}]+)\}',text))
    labels=set(re.findall(r'\\label\{([^{}]+)\}',text));changed=[]
    def link(match):
        key=match.group(1)
        if key in labels:return match.group(0)
        if key not in targets:raise ValueError('Missing generated PDF destination: '+key)
        changed.append(key);return '\\hyperlink{'+key+'}'
    text=re.sub(r'\\hyperref\[([^\[\]]+)\]',link,text)
    # Pandoc omits native empty aliases from its optional TOC title, but that
    # short title also needs the existing plain-text bookmark alternative.
    replacements=[]
    for match in re.finditer(r'\\(?:sub)*section\[',text):
        short,end=balanced(text,match.end()-1,'[',']')
        if not text.startswith('{\\texorpdfstring{',end):continue
        outer,outer_end=balanced(text,end)
        visual,first_end=balanced(outer,len('\\texorpdfstring'))
        plain,second_end=balanced(outer,first_end)
        assert second_end==len(outer)
        if '\\(' not in short and '$' not in short:continue
        replacements.append((match.end(),end-1,'\\texorpdfstring{'+short+'}{'+plain+'}'))
    for start,end,replacement in reversed(replacements):text=text[:start]+replacement+text[end:]
    return text.encode('utf-8'),{'alias_hyperlinks':len(changed),'alias_targets':sorted(set(changed)),
        'math_short_titles_with_existing_plain_bookmark':len(replacements)}
