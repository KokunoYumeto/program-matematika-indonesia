"""Preserve explicitly bound editable SVG download links across exports."""
from pathlib import Path, PurePosixPath
import hashlib, json, posixpath, re
from urllib.parse import urlsplit
from lxml import etree as E

def require(test,message):
    if not test:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def svg_check(raw):
    require(b'<!ENTITY' not in raw.upper(),'SVG entity not supported')
    declarations=re.findall(rb'<!DOCTYPE[^>]*>',raw)
    allowed=b'<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'
    require(len(declarations)<=1 and all(re.sub(rb'\s+',b' ',d)==allowed for d in declarations),'Nonstandard SVG DTD')
    root=E.fromstring(raw,E.XMLParser(resolve_entities=False,no_network=True,load_dtd=False))
    require(root.tag=='{http://www.w3.org/2000/svg}svg','Not SVG')
    for node in root.iter():
        if not isinstance(node.tag,str):continue
        require(E.QName(node).localname not in ('script','foreignObject','animate','animateMotion','animateTransform','set'),'Active SVG not supported')
        if E.QName(node).localname=='style':
            css=''.join(node.itertext())
            require(not re.search(r'@import|expression\s*\(',css,re.I),'Active SVG stylesheet')
            require(all(x.strip().startswith('#') for x in re.findall(r'url\(([^)]*)\)',css)),'External SVG stylesheet reference')
        for key,value in node.attrib.items():
            name=E.QName(key).localname.lower()
            require(not name.startswith('on'),'SVG event handler')
            if name=='href':require(value.startswith('#'),'External SVG reference')
            if 'url(' in value:require(all(x.strip().startswith('#') for x in re.findall(r'url\(([^)]*)\)',value)),'External SVG style reference')
    return root

def prepare_unit(work,unit,local):
    links=dict(local);rows=[]
    for item in unit.get('linked_files',[]):
        require(item['media_type']=='image/svg+xml','Unsupported linked-file type')
        rel=PurePosixPath(item['source']); require(not rel.is_absolute() and '..' not in rel.parts and ':' not in item['source'],'Unsafe linked source')
        p=(work/'frozen_inputs'/rel).resolve();require(p.is_relative_to((work/'frozen_inputs').resolve()),'Escaping linked source')
        raw=p.read_bytes();require(len(raw)==item['bytes'] and sha(raw)==item['source_sha256'].lower(),'Linked source binding mismatch')
        svg_check(raw)
        target='source-files/'+sha(raw)+'.svg';dest=work/'output'/target;dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():require(dest.read_bytes()==raw,'Linked-file collision')
        else:dest.write_bytes(raw)
        require(item['path'] not in links or links[item['path']]==target,'Ambiguous unit link')
        links[item['path']]=target
        rows.append({'lesson_id':unit['id'],'source':item['source'],'original_link':item['path'],'path':target,'bytes':len(raw),'sha256':sha(raw),'media_type':item['media_type']})
    return links,rows

def embed_epub(work,data,opf_name):
    index=work/'output/LINKED_FILE_INDEX.json'
    if not index.exists():return []
    rows=json.loads(index.read_bytes());by_path={r['path']:r for r in rows}
    opf=E.fromstring(data[opf_name]);ns={'o':'http://www.idpf.org/2007/opf','h':'http://www.w3.org/1999/xhtml'}
    manifest=opf.find('o:manifest',ns);spine=opf.find('o:spine',ns);base=posixpath.dirname(opf_name);used={p:0 for p in by_path}
    for name,raw in list(data.items()):
        if not name.endswith('.xhtml'):continue
        root=E.fromstring(raw,E.XMLParser(resolve_entities=False,no_network=True));changed=False
        for a in root.xpath('.//h:a[@href]',namespaces=ns):
            url=urlsplit(a.get('href'))
            if url.scheme or url.netloc:continue
            key=url.path.removeprefix('../')
            if key not in by_path:continue
            require(not url.query and not url.fragment,'Unexpected linked-SVG query/fragment')
            destination=posixpath.join(base,key)
            a.set('href',posixpath.relpath(destination,posixpath.dirname(name)));used[key]+=1;changed=True
        if changed:data[name]=E.tostring(root,encoding='utf-8',xml_declaration=True)
    for key,row in by_path.items():
        raw=(work/'output'/key).read_bytes();require(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'Linked output changed');svg_check(raw)
        name=posixpath.join(base,key);require(name not in data or data[name]==raw,'EPUB resource collision');data[name]=raw
        E.SubElement(manifest,'{'+ns['o']+'}item',id='editable-'+row['sha256'],href=key,**{'media-type':row['media_type']})
        if used[key]:E.SubElement(spine,'{'+ns['o']+'}itemref',idref='editable-'+row['sha256'],linear='no')
    data[opf_name]=E.tostring(opf,encoding='utf-8',xml_declaration=True)
    return [dict(row,epub_member=posixpath.join(base,key),link_occurrences=used[key]) for key,row in by_path.items()]

def internalize_course_urls(root,manifest):
    """Only exact URLs for lessons actually present in this source selection."""
    routes={};changes=[]
    for prefix in manifest.get('included_course_reader_prefixes',[]):
        parsed=urlsplit(prefix)
        require(parsed.scheme=='https' and parsed.netloc and prefix.endswith('/') and not parsed.query and not parsed.fragment,'Unsafe course URL prefix')
        for unit in manifest['units']:routes[prefix+unit['id']+'.html']=unit['id']
    retired=set(manifest.get('retired_download_urls',[]))
    for link in retired:
        require(any(link.startswith(p+'downloads/') for p in manifest.get('included_course_reader_prefixes',[])) and urlsplit(link).path.endswith(('.pdf','.tex','.zip')) and not urlsplit(link).query and not urlsplit(link).fragment,'Unsafe retired download URL')
    external_notes={r['original_href']:r['destination'] for r in manifest.get('external_course_route_notes',[])}
    require(all(v in {'#'+a['id'] for a in manifest.get('reading_appendices',[])} for v in external_notes.values()),'Missing external route appendix')
    for a in root.xpath('.//a[@href]'):
        before=a.get('href');parsed=urlsplit(before);key=before.split('#',1)[0]
        if before in external_notes:
            a.set('href',external_notes[before]);changes.append({'from':before,'to':external_notes[before],'reason':'Unverified replacement prerequisite route; exact source identity and limitation retained in appendix'})
            continue
        if before in retired:
            a.set('href','#about-edition');changes.append({'from':before,'to':'#about-edition','reason':'Retired source-edition download route; current file inventory explained in edition front matter'})
            continue
        if key not in routes:continue
        after='#'+routes[key]+(('#'+parsed.fragment) if parsed.fragment else '')
        a.set('href',after);changes.append({'from':before,'to':after})
    return changes
