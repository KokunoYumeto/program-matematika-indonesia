"""Export-local fix: display math must interrupt a Markdown paragraph.

Without this CommonMark rule declaration, a bare '=' inside a $$ display may
be parsed as a setext H1 and split the rest of a lesson into another EPUB chapter.
The original reader module and every source byte remain unchanged on disk.
"""
import re

TABLE_HEADER=r'| $T$ | $\int_0^T|\zeta(1/2+it)|^2dt$ | Ratio to $T\log T$ |'
TABLE_HEADER_ESCAPED=r'| $T$ | $\int_0^T\|\zeta(1/2+it)\|^2dt$ | Ratio to $T\log T$ |'

def protect_observed_table(source):
    lines=source.splitlines(keepends=True);fence=None
    for n,line in enumerate(lines):
        match=re.match(r'^ {0,3}(`{3,}|~{3,})',line)
        if match:
            run=match.group(1)
            if fence is None:fence=(run[0],len(run))
            elif run[0]==fence[0] and len(run)>=fence[1] and not line[match.end():].strip():fence=None
            continue
        if fence is not None:continue
        if line.rstrip('\r\n')==TABLE_HEADER and n+1<len(lines) and lines[n+1].strip()=='|---:|---:|---:|':
            lines[n]=line.replace(TABLE_HEADER,TABLE_HEADER_ESCAPED,1)
    return ''.join(lines)
def install(reader):
    if getattr(reader,'_export_display_interrupt_adapter',False):return
    original=reader.MarkdownIt
    def factory(*args,**kwargs):
        md=original(*args,**kwargs)
        after=md.block.ruler.after
        def add_rule(after_name,rule_name,rule,options=None):
            if rule_name=='course_math':
                options=dict(options or {})
                options['alt']=list(dict.fromkeys([*options.get('alt',[]),'paragraph','reference','blockquote','list']))
            return after(after_name,rule_name,rule,options)
        md.block.ruler.after=add_rule
        parse=md.parse
        def parse_source(source,*parse_args,**parse_kwargs):
            # One exact observed table header contains absolute-value pipes.
            # Markdown's table lexer consumes these escapes and restores the
            # original math bytes before inline tokenization. No source edit.
            source=protect_observed_table(source)
            return parse(source,*parse_args,**parse_kwargs)
        md.parse=parse_source
        return md
    reader.MarkdownIt=factory
    reader._export_display_interrupt_adapter=True
