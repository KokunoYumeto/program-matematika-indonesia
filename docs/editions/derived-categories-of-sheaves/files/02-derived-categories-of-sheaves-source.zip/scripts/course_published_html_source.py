"""Project a hash-bound published lesson while checking its editable Markdown.

No scripts from the public page execute. Only its complete lesson article is
used. Stable native anchors and exact formula/text content are preserved.
"""
from pathlib import Path
from urllib.parse import urlsplit,unquote
import hashlib,posixpath,json,difflib
from lxml import html as H
from markdown_it import MarkdownIt

def require(value,message):
    if not value:raise ValueError(message)
def math_layout_key(pair):
    """Ignore only line endings and source-line indentation, not inner spaces.

    Exact native Markdown formula bytes are exported after this comparison.
    Space-sensitive verbatim constructs are never indentation-normalized.
    """
    kind,body=pair;body=body.replace('\r\n','\n').replace('\r','\n')
    if any(token in body for token in (r'\verb',r'\obeyspaces',r'\begin{verbatim}')):
        return kind,body
    return kind,'\n'.join(line.lstrip(' \t') for line in body.split('\n'))
def prose_with_list_labels(markup,nonmath_text):
    """Count rendered ordered-list labels, not just DOM text nodes.

    Native parser versions differ on whether an unindented display interrupts
    a list. A literal '4.' must compare against the browser-rendered fourth
    item, never be discarded as formatting noise.
    """
    root=H.fragment_fromstring(markup,create_parent='div')
    for ol in root.xpath('.//ol'):
        require(ol.get('type','1')=='1' and ol.get('reversed') is None,'Unvalidated ordered-list numbering')
        number=int(ol.get('start','1'))
        for li in ol.xpath('./li'):
            number=int(li.get('value',str(number)))
            li.text=str(number)+'.'+(li.text or '')
            number+=1
    return nonmath_text(H.tostring(root,encoding='unicode'))
def render(work,manifest,unit,renderer):
    from build_course_format_pilot_20261002 import nonmath_text,unwrap
    binding=unit['published_html'];p=(work/binding['path']).resolve()
    require(p.is_relative_to(work.resolve()),'Escaping published lesson')
    raw=p.read_bytes();require(len(raw)==binding['bytes'] and hashlib.sha256(raw).hexdigest()==binding['sha256'],'Published lesson changed')
    page=H.document_fromstring(raw)
    if binding.get('container')=='main.lesson':
        articles=page.xpath('//main[contains(concat(" ",normalize-space(@class)," ")," lesson ")]')
        require(len(articles)==1,'Require one bound main lesson')
        shell=articles[0]
        require(len(shell.xpath('./nav'))==1 and len(shell.xpath('./footer'))==1,'Unexpected lesson shell')
        require(shell[0].tag=='nav' and shell[-1].tag=='footer','Navigation must surround, not interrupt, lesson')
        for e in list(shell.xpath('./nav|./footer')):
            require(not e.xpath('.//*[@data-tex]'),'Math in navigation cannot be discarded')
            shell.remove(e)
    else:
        articles=page.xpath('//article[contains(concat(" ",normalize-space(@class)," ")," lesson ")]')
    require(len(articles)==1,'Require one complete lesson article')
    article=articles[0]
    require(not article.xpath('.//script|.//iframe|.//object|.//embed|.//form|.//img|.//svg|.//canvas'),'Unsupported embedded/active lesson material')
    require(len(article.xpath('./h1'))==1,'Ambiguous title')
    # Independent source comparison. Link destinations alone may differ
    # between the native bundle and the portable cumulative edition.
    text=(work/unit['source']).read_text(encoding='utf-8');links={}
    for token in MarkdownIt('commonmark').parse(text):
        for child in token.children or []:
            if child.type!='link_open':continue
            href=child.attrGet('href');parsed=urlsplit(href)
            if parsed.scheme in ('http','https','mailto') or href.startswith('#'):continue
            key='course:'+parsed.path if parsed.scheme=='course' else parsed.path
            links[key]='https://source-identity.invalid/'+str(len(links))
    expected=renderer(text,local_links=links,heading_anchors=unit.get('heading_anchors'))
    native=H.fragment_fromstring(expected,create_parent='div')
    actual=[unwrap(e.get('data-tex')) for e in article.xpath('.//*[@data-tex]')]
    wanted=[unwrap(e.get('data-tex')) for e in native.xpath('.//*[@data-tex]')]
    if [math_layout_key(x) for x in actual]!=[math_layout_key(x) for x in wanted]:
        changes=[]
        for op,a,b,c,d in difflib.SequenceMatcher(a=actual,b=wanted,autojunk=False).get_opcodes():
            if op!='equal':changes.append({'op':op,'published_range':[a,b],'source_range':[c,d],'published':actual[a:min(b,a+3)],'source':wanted[c:min(d,c+3)]})
        (work/'PUBLISHED_SOURCE_COMPARISON_FAILURE.json').write_text(json.dumps({'unit':unit['id'],'published_count':len(actual),'source_count':len(wanted),'changes':changes},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        raise ValueError('Published/editable ordered formula mismatch: '+unit['id'])
    layout_changes=[]
    for index,(public_node,source_node,a,b) in enumerate(zip(article.xpath('.//*[@data-tex]'),native.xpath('.//*[@data-tex]'),actual,wanted),1):
        if a!=b:
            layout_changes.append({'formula_ordinal':index,'published_tex_sha256':hashlib.sha256(a[1].encode()).hexdigest(),'source_tex_sha256':hashlib.sha256(b[1].encode()).hexdigest(),'change':'line endings/source-line indentation only; export exact native-parser formula'})
        public_node.set('data-tex',source_node.get('data-tex'))
        public_node.text=source_node.get('data-tex')
        for child in list(public_node):public_node.remove(child)
    public_fragment=H.tostring(article,encoding='unicode')
    expected_text=prose_with_list_labels(expected,nonmath_text);published_text=prose_with_list_labels(public_fragment,nonmath_text)
    if expected_text!=published_text:
        first=next((i for i,(a,b) in enumerate(zip(published_text,expected_text)) if a!=b),min(len(published_text),len(expected_text)))
        diffs=[{'first_difference':first,'published_length':len(published_text),'source_length':len(expected_text),'published':published_text[max(0,first-100):first+500],'source':expected_text[max(0,first-100):first+500]}]
        (work/'PUBLISHED_PROSE_COMPARISON_FAILURE.json').write_text(json.dumps({'unit':unit['id'],'changes':diffs},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        raise ValueError('Published/editable prose mismatch: '+unit['id'])
    ids=[e.get('id') for e in article.xpath('.//*[@id]')]
    require(len(ids)==len(set(ids)),'Duplicate native lesson anchors')
    routes={u['published_html']['reader_path']:u for u in manifest['units']}
    prefixes=manifest['published_collection'];projection=[]
    for link in article.xpath('.//a[@href]'):
        before=link.get('href');parsed=urlsplit(before)
        if parsed.scheme or parsed.netloc:continue
        require(not parsed.query,'Unexpected query in local published link')
        destination=posixpath.normpath(posixpath.join(posixpath.dirname(binding['reader_path']),unquote(parsed.path))) if parsed.path else binding['reader_path']
        require(not destination.startswith('../') and not destination.startswith('/'),'Escaping native link')
        if destination in routes:
            target=routes[destination];fragment=unquote(parsed.fragment)
            after='#'+target['id']
            if fragment and fragment!=target['published_html']['native_h1_id']:after+='#'+fragment
        elif destination in prefixes.get('appendix_routes',{}):after='#'+prefixes['appendix_routes'][destination]
        elif destination==prefixes['reader_root']+'index.html':after='#about-edition'
        elif destination==prefixes['reader_root']+'licenses/design-science-license.txt':after='#design-science-licence'
        else:
            require(destination in prefixes['published_files'],'Unknown local public destination: '+destination)
            after=prefixes['site']+destination.removeprefix('docs/')
            if parsed.fragment:after+='#'+parsed.fragment
        link.set('href',after);projection.append({'from':before,'to':after})
    # Export the article's complete children, not an outer page/navigation shell.
    result=''.join(H.tostring(child,encoding='unicode') for child in article)
    return result,{'unit_id':unit['id'],'published_html_sha256':binding['sha256'],'editable_source_sha256':unit['source_sha256'],'source_prose_parity':'PASS including rendered ordered-list labels','ordered_formulas':len(wanted),'math_layout_projection':layout_changes,'navigation':projection,'native_ids':ids}
