"""Replace unsupported TeX displays by verified MathML; bind all source math."""
from pathlib import Path
import argparse,collections,hashlib,json,posixpath,re,zipfile
from urllib.parse import urlsplit,unquote
from lxml import etree as E

LOG=Path(__file__).resolve().parent
WORK=LOG.parent if (LOG.parent/'SOURCE_MANIFEST.json').is_file() else LOG.parent/'programme-format-pilot'/'RT-FIN-20261002'
NS={'h':'http://www.w3.org/1999/xhtml','m':'http://www.w3.org/1998/Math/MathML','o':'http://www.idpf.org/2007/opf'}
def load(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def parsed(raw):return E.fromstring(raw,E.XMLParser(resolve_entities=False,no_network=True))
def unwrap(s):
    for a,b in [(r'\[',r'\]'),(r'\(',r'\)'),('$$','$$'),('$','$')]:
        if s.startswith(a) and s.endswith(b):return s[len(a):-len(b)].strip(),a in (r'\[','$$')
    return s.strip(),None
def find_fallbacks(root):
    return [e for e in root.xpath('.//h:span[contains(concat(" ",normalize-space(@class)," ")," math ")]',namespaces=NS) if not e.xpath('.//m:math',namespaces=NS)]
def canonical(s):return re.sub(r'\s+','',s)

def main():
    global WORK
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--work',type=Path,default=WORK);args=ap.parse_args();WORK=args.work
    export=load(WORK/'SOURCE_MANIFEST.json').get('export',{});slug=export.get('slug','representations-of-finite-groups');date=export.get('date_iso','2026-10-02')
    epub=WORK/f'output/03-{slug}.epub'
    formulas=load(WORK/'output/FORMULA_INDEX.json')
    source={canonical(r['tex']):r for r in formulas}
    with zipfile.ZipFile(epub) as z:
        assert z.testzip() is None
        data={n:z.read(n) for n in z.namelist()}
    # Pandoc splits a top-level provenance Div into an unnamed chapter. Keep
    # this marked export paratext with the immediately preceding lesson.
    opf_name=next(n for n in data if n.endswith('.opf'));opf=parsed(data[opf_name])
    items={e.get('id'):e for e in opf.xpath('./o:manifest/o:item',namespaces=NS)}
    previous=None;merged_credits=[]
    for entry in list(opf.xpath('./o:spine/o:itemref',namespaces=NS)):
        item=items[entry.get('idref')];member=(Path(opf_name).parent/item.get('href')).as_posix()
        if not member.endswith('.xhtml'):continue
        tree=parsed(data[member]);body=tree.find('h:body',NS)
        credit_nodes=body.xpath('./h:div[contains(concat(" ",normalize-space(@class)," ")," export-figure-credits ")]',namespaces=NS)
        if len(body)==1 and len(credit_nodes)==1:
            assert previous is not None
            target=parsed(data[previous]);sections=target.xpath('./h:body/h:section',namespaces=NS);assert len(sections)==1
            assert not any(item.get('href').encode() in raw for name,raw in data.items() if name.endswith('.xhtml') and name!=member),'Unexpected link to standalone credits; remap explicitly'
            sections[0].append(credit_nodes[0]);data[previous]=E.tostring(target,encoding='utf-8',xml_declaration=True)
            entry.getparent().remove(entry);item.getparent().remove(item);del data[member]
            merged_credits.append({'removed_unnamed_member':member,'lesson_member':previous})
        else:previous=member
    data[opf_name]=E.tostring(opf,encoding='utf-8',xml_declaration=True)
    referenced_fragments=set()
    for member,raw in data.items():
        if not member.endswith('.xhtml'):continue
        for link in parsed(raw).xpath('.//*[@href]'):
            url=urlsplit(link.get('href'))
            if url.scheme or url.netloc or not url.fragment:continue
            destination=posixpath.normpath(posixpath.join(posixpath.dirname(member),unquote(url.path))) if url.path else member
            referenced_fragments.add((destination,unquote(url.fragment)))
    request=[]
    for name,raw in data.items():
        if name.endswith('.xhtml'):
            root=parsed(raw)
            for n,e in enumerate(find_fallbacks(root)):
                tex,display=unwrap(''.join(e.itertext()))
                assert canonical(tex) in source,('unbound fallback',name,tex)
                row=source[canonical(tex)]
                if display is None:display='display' in e.get('class','').split()
                request.append({'id':row['id'],'member':name,'index':n,'tex':row['tex'],'display':display})
    if args.prepare:
        save(WORK/'qa/MATHML_FALLBACK_REQUEST.json',{'schema':'course-epub-fallback-request/1','epub_sha256':sha(epub.read_bytes()),'formulas':request})
        print(json.dumps({'state':'prepared','unsupported_formulas':len(request)}));return
    prior=load(WORK/'qa/MATHML_FALLBACK_REQUEST.json');assert prior['epub_sha256']==sha(epub.read_bytes())
    rendered=load(WORK/'qa/MATHML_FALLBACK_RESULT.json')
    assert len(rendered['formulas'])==len(request)
    results={(r['member'],r['index']):r for r in rendered['formulas']}
    math_members=set();preserved=[];replaced=0;inline_scroll=[]
    # These exact source expressions overflow a 390px reading column. Keep
    # them inline in meaning and source, with a local scroll box in layout.
    wide_inline={canonical(s) for s in [
        r'\sum_{k\ge1}1/(2k(2k-1))=\sum_{k\ge1}(1/(2k-1)-1/(2k))=\log2',
        r'[K_{2it}(ix)-K_{2it}(-ix)]/x=-i\pi(J_{2it}+J_{-2it})/(2x\cosh\pi t)',
        r'(AUV)^2[(UV/E)(A+E)(A+hE)(V+hE^2)+hAU^2(A+E)]',
    ]}
    manifest=load(WORK/'SOURCE_MANIFEST.json')
    if manifest.get('epub_inline_layout'):
        binding=manifest['epub_inline_layout'];p=(WORK/binding['path']).resolve()
        assert p.is_relative_to(WORK.resolve())
        raw=p.read_bytes();assert len(raw)==binding['bytes'] and sha(raw)==binding['sha256']
        contract=json.loads(raw)
        inline_source={canonical(r['tex']) for r in formulas if r['kind']=='InlineMath'}
        assert all(canonical(s) in inline_source for s in contract['expressions'])
        wide_inline.update(canonical(s) for s in contract['expressions'])
    for name,raw in list(data.items()):
        if not name.endswith('.xhtml'):continue
        root=parsed(raw)
        # Heading aliases belong to the actual reading chapter. Pandoc also
        # copies their empty spans into nav labels, where EPUB forbids them.
        for nav in root.xpath('.//h:nav',namespaces=NS):
            before=''.join(nav.itertext())
            for span in list(nav.xpath('.//h:span[not(*)]',namespaces=NS)):
                if (span.text or '').strip():continue
                assert not span.get('id') or (name,span.get('id')) not in referenced_fragments,'Do not remove a referenced navigation target'
                parent=span.getparent();previous=span.getprevious();tail=span.tail or ''
                if previous is None:parent.text=(parent.text or '')+tail
                else:previous.tail=(previous.tail or '')+tail
                parent.remove(span)
            assert ''.join(nav.itertext())==before,'Navigation text changed'
        for n,e in enumerate(find_fallbacks(root)):
            row=results[name,n];tex,_=unwrap(''.join(e.itertext()));assert canonical(tex)==canonical(row['tex'])
            math=parsed(row['mathml'].encode());assert math.tag=='{'+NS['m']+'}math'
            assert not math.xpath('.//m:merror',namespaces=NS)
            # MathML Core does not implement legacy script/double-struck
            # mathvariant attributes. Encode these observed glyph identities
            # directly, otherwise common readers visually collapse F/H/C/Q.
            variants={('script','F'):'ℱ',('script','H'):'ℋ',('script','A'):'𝒜',('script','O'):'𝒪',('double-struck','C'):'ℂ',('double-struck','Q'):'ℚ',('double-struck','R'):'ℝ',('fraktur','c'):'𝔠'}
            variants.update({('script','S'):'𝒮',('script','B'):'ℬ',('script','E'):'ℰ',
                ('script','M'):'ℳ',('script','P'):'𝒫',('script','D'):'𝒟',('script','R'):'ℛ',
                ('script','V'):'𝒱',('script','K'):'𝒦',('script','T'):'𝒯',('script','C'):'𝒞',
                ('script','I'):'ℐ',('script','U'):'𝒰',('double-struck','Z'):'ℤ',
                ('bold','1'):'𝟏',('sans-serif','C'):'𝖢',('sans-serif','M'):'𝖬',
                ('double-struck','F'):'𝔽',('bold','Z'):'𝐙',('fraktur','p'):'𝔭'})
            for token in math.xpath('.//*[@mathvariant]'):
                key=(token.get('mathvariant'),token.text)
                if key[0]=='normal':continue
                assert key in variants,('Unvalidated MathML variant',key)
                token.text=variants[key];del token.attrib['mathvariant']
            # mlabeledtr is valid legacy MathML but not MathML Core. Use an
            # ordinary two-cell row, keeping the exact equation label at right.
            for labeled in math.xpath('.//m:mlabeledtr',namespaces=NS):
                cells=list(labeled);assert len(cells)==2
                labeled.tag='{'+NS['m']+'}mtr';labeled.remove(cells[0]);labeled.append(cells[0])
                labeled.getparent().set('columnalign','center right')
                labeled.getparent().set('columnspacing','1em')
            for cell in math.xpath('.//m:mtd',namespaces=NS):
                content=E.Element('{'+NS['m']+'}mrow')
                for child in list(cell):content.append(child)
                cell.append(content)
            sem=E.Element('{'+NS['m']+'}semantics')
            presentation=E.SubElement(sem,'{'+NS['m']+'}mrow')
            for child in list(math):presentation.append(child)
            annotation=E.SubElement(sem,'{'+NS['m']+'}annotation',encoding='application/x-tex');annotation.text=row['tex']
            math.append(sem);math.tail=e.tail
            e.getparent().replace(e,math);replaced+=1
        # Preserve the original quotient slash as an operator. Pandoc's mi
        # with operator-only sizing attributes is invalid MathML here.
        for token in root.xpath('.//m:mi[@minsize or @maxsize or @stretchy]',namespaces=NS):
            assert token.text=='/' and token.get('minsize')=='120%' and token.get('maxsize')=='120%' and token.get('stretchy')=='true'
            token.tag='{'+NS['m']+'}mo'
        for table in root.xpath('.//m:mtable[@columnspacing=""]',namespaces=NS):
            assert all(len(row.xpath('./m:mtd',namespaces=NS))==1 for row in table if E.QName(row).localname=='mtr')
            del table.attrib['columnspacing'] # One column has no intercolumn gap.
        if root.xpath('.//m:math',namespaces=NS):math_members.add(name)
        # Pandoc's EPUB TOC duplicates some source headings. Bind only reading
        # chapters here; navigation is checked separately by EPUBCheck.
        if '/text/' in name and not name.endswith('title_page.xhtml'):
            for math in root.xpath('.//m:math',namespaces=NS):
                anns=math.xpath('.//m:annotation[@encoding="application/x-tex"]',namespaces=NS)
                assert len(anns)==1,('missing exact TeX annotation',name)
                preserved.append(canonical(anns[0].text or ''))
        # Keep wide displays/tables scrollable inside the reading column.
        # Do not shrink mathematics or hide overflow to make a check pass.
        for math in root.xpath('.//m:math[@display="block"]',namespaces=NS):
            # A display may occur inside a paragraph (notably an exercise).
            # Span is valid phrasing content there; CSS supplies the same
            # block/scroll geometry without introducing invalid p > div.
            wrapper=E.Element('{'+NS['h']+'}span',{'class':'course-equation-scroll'})
            parent=math.getparent();index=parent.index(math);tail=math.tail;math.tail=None
            parent.remove(math);wrapper.append(math);wrapper.tail=tail;parent.insert(index,wrapper)
        for math in root.xpath('.//m:math[@display="inline"]',namespaces=NS):
            annotations=math.xpath('.//m:annotation[@encoding="application/x-tex"]',namespaces=NS)
            if len(annotations)!=1 or canonical(annotations[0].text or '') not in wide_inline:continue
            wrapper=E.Element('{'+NS['h']+'}span',{'class':'course-inline-math-scroll'})
            parent=math.getparent();index=parent.index(math);tail=math.tail;math.tail=None
            parent.remove(math);wrapper.append(math);wrapper.tail=tail;parent.insert(index,wrapper)
            inline_scroll.append({'member':name,'tex':annotations[0].text})
        for table in root.xpath('.//h:table',namespaces=NS):
            wrapper=E.Element('{'+NS['h']+'}div',{'class':'course-table-scroll'})
            parent=table.getparent();index=parent.index(table);tail=table.tail;table.tail=None
            parent.remove(table);wrapper.append(table);wrapper.tail=tail;parent.insert(index,wrapper)
        head=root.find('h:head',NS)
        style=E.SubElement(head,'{'+NS['h']+'}style',type='text/css')
        style.text='body{margin:1em auto;padding:0 1em;max-width:48em;line-height:1.45;overflow-wrap:break-word} .course-equation-scroll,.course-table-scroll{display:block;max-width:100%;overflow-x:auto;padding:.3em 0} .course-inline-math-scroll{display:inline-block;vertical-align:middle;max-width:100%;overflow-x:auto;padding:.15em 0} math[display="block"]{min-width:max-content} table{border-collapse:collapse} td,th{padding:.2em .45em} p{orphans:2;widows:2} img{max-width:100%;height:auto}'
        data[name]=E.tostring(root,encoding='utf-8',xml_declaration=True)
    expected=collections.Counter(canonical(r['tex']) for r in formulas)
    actual=collections.Counter(preserved)
    assert actual==expected,{'missing':list((expected-actual).items())[:4],'extra':list((actual-expected).items())[:4]}
    opf_name=next(n for n in data if n.endswith('.opf'));opf=parsed(data[opf_name])
    for item in opf.xpath('./o:manifest/o:item',namespaces=NS):
        member=(Path(opf_name).parent/item.get('href')).as_posix()
        if member in math_members:
            props=set(item.get('properties','').split());props.add('mathml');item.set('properties',' '.join(sorted(props)))
    for meta in opf.xpath('./o:metadata/o:meta[@property="dcterms:modified"]',namespaces=NS):meta.text=date+'T00:00:00Z'
    data[opf_name]=E.tostring(opf,encoding='utf-8',xml_declaration=True)
    from course_linked_assets import embed_epub
    linked_files=embed_epub(WORK,data,opf_name)
    temporary=epub.with_suffix('.epub.tmp')
    with zipfile.ZipFile(temporary,'w') as z:
        for name in ['mimetype',*sorted(n for n in data if n!='mimetype')]:
            info=zipfile.ZipInfo(name,tuple(map(int,date.split('-')))+(0,0,0));info.compress_type=zipfile.ZIP_STORED if name=='mimetype' else zipfile.ZIP_DEFLATED
            z.writestr(info,data[name])
    temporary.replace(epub)
    receipt={'schema':'course-epub-math-seal/1','state':'source_math_exact_epubcheck_pending','formulas':len(formulas),'source_math_multiset':'PASS','fallbacks_rendered':replaced,'mathml_members':len(math_members),'epub':{'bytes':epub.stat().st_size,'sha256':sha(epub.read_bytes())},'renderer':rendered['renderer'],'notes':['Original source TeX retained exactly in formula ledger and MathML annotations','Table of contents mathml property declared explicitly','ZIP and modification timestamps deterministic','No mathematical source correction or human review claimed']}
    receipt['figure_credits_merged_into_lesson']=merged_credits
    receipt['wide_inline_scroll_projections']=inline_scroll
    receipt['linked_editable_files']=linked_files
    save(WORK/'EPUB_MATH_SEAL.json',receipt);print(json.dumps(receipt))

if __name__=='__main__':main()
