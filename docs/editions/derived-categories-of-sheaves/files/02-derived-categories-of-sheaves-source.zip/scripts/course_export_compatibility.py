"""Exact export-only compatibility decisions; original reader stays unchanged."""
import hashlib,json,re
def install(reader,work,manifest):
    binding=manifest.get('export_compatibility')
    if not binding:return
    p=(work/binding['path']).resolve()
    if not p.is_relative_to(work.resolve()):raise ValueError('Compatibility evidence escapes root')
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=binding['sha256']:raise ValueError('Stale compatibility evidence')
    decisions=json.loads(raw)
    maths={r['sha256'] for r in decisions['exact_formula_false_positives']}
    anchors=set(decisions['unicode_heading_aliases'])
    for anchor in anchors:
        if not re.fullmatch(r'[\w.-]{1,101}',anchor,re.UNICODE):raise ValueError('Unsafe heading alias')
    original_math=reader.math_private_reference
    def classified(value):
        # Each complete formula has been inspected; one byte of difference
        # falls back to the unmodified native privacy classifier.
        if hashlib.sha256(value.encode()).hexdigest() in maths:return False
        return original_math(value)
    original_id=reader.identifier
    def identifier(value,field):
        if field=='heading anchor' and value in anchors:return value
        return original_id(value,field)
    reader.math_private_reference=classified;reader.identifier=identifier
