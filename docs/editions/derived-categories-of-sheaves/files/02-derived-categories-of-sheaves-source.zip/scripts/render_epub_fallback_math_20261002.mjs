import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const playwright=require(process.env.COURSE_PLAYWRIGHT_MODULE||'playwright');
const {chromium}=playwright;
const work=path.resolve(process.argv[2]);
const input=JSON.parse(fs.readFileSync(path.join(work,'qa/MATHML_FALLBACK_REQUEST.json')));
const localVendor=path.join(work,'vendor/mathjax/tex-mml-chtml.js');
const vendor=process.env.COURSE_MATHJAX||localVendor;
const hash=crypto.createHash('sha256').update(fs.readFileSync(vendor)).digest('hex');
if(hash!=='300480069078b5892d2363a2b65e2dfbbf30fe5c80f83edbfecf4610fd093862')throw Error('MathJax source identity differs');
const extensionManifest=path.join(work,'vendor/mathjax/EXTENSIONS.json');
const extensions=fs.existsSync(extensionManifest)?JSON.parse(fs.readFileSync(extensionManifest)).files:[];
const localExtensions=new Map();
for(const row of extensions){
 if(!/^[a-z]+\.js$/.test(row.file))throw Error('Unsafe extension path');
 const raw=fs.readFileSync(path.join(work,'vendor/mathjax',row.file));
 if(crypto.createHash('sha256').update(raw).digest('hex')!==row.sha256)throw Error('Changed MathJax extension');
 localExtensions.set('https://offline.invalid/mathjax/input/tex/extensions/'+row.file,raw);
}
const chrome=process.env.COURSE_CHROMIUM||(fs.existsSync('C:/Program Files/Google/Chrome/Application/chrome.exe')?'C:/Program Files/Google/Chrome/Application/chrome.exe':undefined);
const browser=await chromium.launch({headless:true,executablePath:chrome});
try{
 const page=await browser.newPage();
 await page.route('**/*',route=>localExtensions.has(route.request().url())?
   route.fulfill({status:200,contentType:'application/javascript',body:localExtensions.get(route.request().url())}):route.abort());
 await page.setContent('<!doctype html><html lang="en"><head><meta charset="utf-8"></head><body></body></html>');
 await page.evaluate(()=>{window.MathJax={loader:{paths:{mathjax:'https://offline.invalid/mathjax'}},startup:{typeset:false},tex:{tags:'ams'}};});
 await page.addScriptTag({path:vendor});
 await page.evaluate(()=>MathJax.startup.promise);
 const result=await page.evaluate(async rows=>{
   const out=[];
   for(const row of rows){
     MathJax.texReset();
     const mml=await MathJax.tex2mmlPromise(row.tex,{display:row.display});
     if(mml.includes('<merror')||mml.includes('mathcolor="red"'))throw Error('MathJax rejected '+row.id);
     out.push({...row,mathml:mml});
   }
   return out;
 },input.formulas);
 const receipt={schema:'course-epub-fallback-mathml/1',state:'rendered_pending_xml_validation',renderer:'MathJax 3.2.2',renderer_sha256:hash,extensions,headless:true,network_requests_permitted:false,formulas:result};
 fs.writeFileSync(path.join(work,'qa/MATHML_FALLBACK_RESULT.json'),JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({state:receipt.state,formulas:result.length}));
}finally{await browser.close();}
