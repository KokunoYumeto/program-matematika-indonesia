"""Source-preserving HTML-parser -> Pandoc AST -> EPUB/TeX format adapter."""
from pathlib import Path
from datetime import date
import argparse, collections, copy, hashlib, html, json, os, re, shutil, subprocess, sys
from lxml import html as LH

LOG=Path(__file__).resolve().parent
DEFAULT_WORK=LOG.parent if (LOG.parent/'SOURCE_MANIFEST.json').is_file() else LOG.parent/'programme-format-pilot'/'RT-FIN-20261002'
PANDOC=os.environ.get('COURSE_PANDOC') or shutil.which('pandoc')
if not PANDOC:raise RuntimeError('Install Pandoc 3.9.0.2 or set COURSE_PANDOC')

def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(jb(v))
def run(args,raw):
    p=subprocess.run([PANDOC,*args],input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    if p.returncode:raise RuntimeError(p.stderr.decode('utf-8','replace'))
    return p.stdout,p.stderr.decode('utf-8','replace')
def visit(node,fn):
    if isinstance(node,list):return [visit(x,fn) for x in node]
    if isinstance(node,dict):return fn({k:visit(v,fn) for k,v in node.items()})
    return node
def unwrap(raw):
    for opening,closing in [(r'\[',r'\]'),(r'\(',r'\)'),('$$','$$'),('$','$')]:
        if raw.startswith(opening) and raw.endswith(closing):
            return ('DisplayMath' if opening in (r'\[','$$') else 'InlineMath',raw[len(opening):-len(closing)].strip())
    raise AssertionError('Unsupported native math delimiter')
def maths(node):
    found=[]
    def one(v):
        if v.get('t')=='Math':found.append((v['c'][0]['t'],v['c'][1]))
        return v
    visit(node,one);return found
def nonmath_text(markup):
    root=LH.fragment_fromstring(markup,create_parent='div')
    for e in list(root.xpath('.//*[@data-tex or contains(concat(" ",normalize-space(@class)," ")," math ")]')):
        e.text='';
        for child in list(e):e.remove(child)
    # Ignore whitespace only, never punctuation, digits or word order.
    return re.sub(r'\s+','',''.join(root.itertext()))

def edition_metadata(manifest):
    """No fallback from a different course, language, licence or AI credit."""
    required=('title','content_language','source_author','conversion_author','status',
              'coverage_note','upstream_reader','programme','units','export')
    for key in required:
        if not manifest.get(key):raise ValueError('Missing edition metadata: '+key)
    if manifest['content_language'] not in ('en','en-GB','en-US'):
        raise ValueError('This adapter has English paratext only; supply a localized adapter')
    export=manifest['export']
    for key in ('slug','date_iso','date_label','epoch','rights_summary','rights_notice'):
        if not export.get(key):raise ValueError('Missing explicit export metadata: '+key)
    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',export['slug']):
        raise ValueError('Unsafe export slug')
    date.fromisoformat(export['date_iso'])
    if not isinstance(export['epoch'],int):raise ValueError('Export epoch must be an integer')
    author=manifest['source_author']
    if isinstance(author,dict):
        if not author.get('model') or not author.get('reasoning_effort'):
            raise ValueError('Incomplete source AI provenance')
        author_text=author['model']+'; effort: '+author['reasoning_effort']
    elif isinstance(author,str) and author.strip():author_text=author
    else:raise ValueError('Invalid source attribution')
    for unit in manifest['units']:
        if unit.get('format')!='commonmark-math/v1':
            raise ValueError('Unvalidated native source format: '+str(unit.get('format')))
        if unit.get('documents'):raise ValueError('Document attachment adapter is not validated')
        for asset in [*unit.get('assets',[]),*unit.get('native_images',[])]:
            if asset.get('media_type')=='image/svg+xml':
                if not manifest.get('svg_pdf_adapter'):
                    raise ValueError('Exact SVG vector-PDF adapter evidence is required')
            elif asset.get('media_type')!='image/png':
                raise ValueError('PDF image adapter not yet validated for '+str(asset.get('media_type')))
    count=len(manifest['units'])
    supplements=sum(u.get('selection_kind')=='supplement' for u in manifest['units'])
    selection_label=(f'{count-supplements} lessons and {supplements} editorial supplements'
                     if supplements else f'{count} lessons')
    if export.get('selection_label'):selection_label=export['selection_label']
    reading_links=f"[Return to the mathematics programme]({manifest['programme']})."
    if manifest.get('reader_link_status') in (None,'verified_200','verified_public_archive_and_selected_reader_bytes'):
        reading_links=f"[Read the course online]({manifest['upstream_reader']}) · "+reading_links
    intro=f'''# About this edition {{#about-edition .unnumbered}}

This downloadable edition contains the {selection_label} in the selected reader edition of *{manifest['title']}*. It preserves the included lesson text, mathematics, references, exercises and supplied solutions.

Source status: {manifest['status']}. {manifest['coverage_note']}

Original writing provenance: {author_text}. Source-preserving format conversion and packaging: {manifest['conversion_author']}. The source-specific author, contributor and review statements remain authoritative. Format validation adds no claim of human editing, independent mathematical review or course completion. This is a source-preserving edition, not an everyday-English rewrite.

{reading_links}

{export['rights_notice']}

The PDF and EPUB share the same ordered content selection. Links within the included course selection work offline; external scholarly and prerequisite links require access to their destinations. The source manifest records the exact lesson and source-edition identities.

'''
    if manifest.get('retired_download_urls'):
        slug=export['slug']
        intro+=f'''## Files supplied with this edition

The download links printed in the original lessons belonged to an older website. In this portable edition, those labels lead here instead of to an obsolete destination. The corresponding current files are supplied together in the course download record:

- `00-{slug}.pdf`: the complete selected reader.
- `01-{slug}.tex`: its directly editable cumulative LaTeX.
- `02-{slug}-source.zip`: the complete source and build dependencies.
- `03-{slug}.epub`: the reflowable offline reader.

These are companion downloads, not files hidden inside this EPUB. Use the programme link above to find the course's current reading and download entry.

'''
    meta={'title':{'t':'MetaString','c':manifest['title']},
          'lang':{'t':'MetaString','c':manifest['content_language']},
          'date':{'t':'MetaString','c':export['date_label']},
          'subtitle':{'t':'MetaString','c':f'{selection_label} · {manifest["status"]}'},
          'author':{'t':'MetaList','c':[{'t':'MetaString','c':manifest.get('source_author_display',author_text)}]},
          'rights':{'t':'MetaString','c':export['rights_summary']}}
    return export,intro,meta

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=DEFAULT_WORK);args=ap.parse_args()
    work=args.work.resolve();manifest=json.loads((work/'SOURCE_MANIFEST.json').read_bytes())
    export,intro,meta=edition_metadata(manifest)
    from course_svg_pdf_support import svg_pdf_derivative
    svg_derivatives={}
    for unit in manifest['units']:
        for asset in [*unit.get('assets',[]),*unit.get('native_images',[])]:
            if asset['media_type']=='image/svg+xml':
                svg_derivatives[asset['source_sha256'].lower()]=svg_pdf_derivative(work,manifest,asset)
    for f in manifest['files']:
        raw=(work/f['path']).read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256'],f['path']
    sys.path.insert(0,str(work/'native_reader'))
    import course_reader
    from course_display_math_adapter import install
    published_units=[bool(u.get('published_html')) for u in manifest['units']]
    if any(published_units) and not all(published_units):
        raise ValueError('Mixed published-HTML/native-Markdown parsing needs a separately validated contract')
    # Published witnesses use their exact frozen native parser. Applying a
    # different display-interruption rule can change source list topology.
    if not all(published_units):install(course_reader)
    from course_export_compatibility import install as install_compatibility
    install_compatibility(course_reader,work,manifest)
    render_markdown_math=course_reader.render_markdown_math
    from course_assets import read_unit_assets,asset_output_path,figure_provenance
    output=work/'output';output.mkdir(exist_ok=True)
    audit=work/'qa';audit.mkdir(exist_ok=True)
    units=manifest['units'];cid=manifest['course_id'];all_ids={'about-edition'};unit_records=[];math_records=[];image_records=[];linked_file_records=[];course_link_projections=[];published_checks=[];blocks=[];version=None;latex_images={}
    slug=export['slug']
    local={'index.html':'#about-edition','./index.html':'#about-edition'}
    for row in manifest.get('external_course_route_notes',[]):
        if row['original_href'].startswith('course:'):
            assert row['destination'] in {'#'+a['id'] for a in manifest.get('reading_appendices',[])}
            local[row['original_href']]=row['destination']
    for appendix in manifest.get('reading_appendices',[]):
        for alias in appendix.get('link_aliases',[]):local[alias]='#'+appendix['id']
    for u in units:
        for alias in [u['id']+'.html',Path(u['source']).name,*u.get('link_aliases',[])]:
            local[alias]='#'+u['id'];local['./'+alias]='#'+u['id']
        local['course:'+cid+'/'+u['id']]='#'+u['id']
    # One dedicated article per exact source. Asset types not yet validated
    # for this PDF/EPUB path are rejected before writing any output.
    for u in units:
        text=(work/u['source']).read_text(encoding='utf-8')
        asset_unit=dict(u,source=u.get('source_origin',u['source']))
        if u.get('native_images'):
            from course_native_image_support import bind_native_images
            bound_assets=bind_native_images(work/'frozen_inputs',cid,u)
        else:bound_assets=read_unit_assets(work/'frozen_inputs',cid,asset_unit) if u.get('assets') else None
        unit_links=local
        if u.get('linked_files'):
            from course_linked_assets import prepare_unit
            unit_links,linked_rows=prepare_unit(work,u,local);linked_file_records.extend(linked_rows)
        if u.get('published_html'):
            from course_published_html_source import render as published_render
            native,comparison=published_render(work,manifest,u,render_markdown_math);published_checks.append(comparison)
        else:
            native=render_markdown_math(text,local_links=unit_links,mathematical_ids=u.get('mathematical_item_ids',[]),heading_anchors=u.get('heading_anchors'),assets=bound_assets)
        root=LH.fragment_fromstring(native,create_parent='div')
        if manifest.get('included_course_reader_prefixes'):
            from course_linked_assets import internalize_course_urls
            course_link_projections.extend(internalize_course_urls(root,manifest))
        for img in root.xpath('.//img'):
            row=next(r for r in bound_assets.records if r['id']==img.get('data-asset-id'))
            relative=bound_assets.output_relative(row) if u.get('native_images') else asset_output_path(cid,u['id'],row).split('/',2)[2]
            raw=(work/'frozen_inputs'/row['source']).read_bytes()
            assert sha(raw)==row['source_sha256'].lower()
            image_file=output/relative;image_file.parent.mkdir(parents=True,exist_ok=True);image_file.write_bytes(raw)
            image_records.append({'lesson_id':u['id'],'asset_id':row['id'],'path':relative,'bytes':len(raw),'sha256':sha(raw),'alt':img.get('alt'),'width':row['width'],'height':row['height'],'display_state':row.get('display_state','source_bound_not_independently_reviewed'),'source_receipt_sha256':row.get('admission_receipt_sha256')})
            image_records[-1]['media_type']=row['media_type']
            if row['media_type']=='image/svg+xml':
                derivative=svg_derivatives[sha(raw)];pdf_relative=Path(relative).with_suffix('.pdf').as_posix()
                (output/pdf_relative).write_bytes(derivative['path'].read_bytes())
                image_records[-1]['pdf_derivative']={k:v for k,v in derivative.items() if k!='path'}
                image_records[-1]['pdf_derivative']['path']=pdf_relative
                latex_images[relative]=pdf_relative
            # Pixel dimensions are metadata, not a printed-page size request.
            for attr in ['width','height','style','loading','decoding']:img.attrib.pop(attr,None)
        alias={e.get('id'):u['id']+'--'+e.get('id') for e in root.xpath('.//*[@id]')}
        for e in root.xpath('.//*[@id]'):e.set('id',alias[e.get('id')])
        first=root.find('h1');assert first is not None
        first.set('id',u['id'])
        if alias:
            original_first=next(iter(alias));alias[original_first]=u['id']
        for e in root.xpath('.//a[starts-with(@href,"#")]'):
            target=e.get('href')[1:]
            if '#' in target:
                dest,frag=target.split('#',1);e.set('href','#'+dest+'--'+frag)
            elif target in alias:e.set('href','#'+alias[target])
        expected=[];math_by_id={}
        for n,e in enumerate(root.xpath('.//*[@data-tex]'),1):
            raw=e.get('data-tex');kind,body=unwrap(raw)
            key=u['id']+'--formula-'+str(n)
            math_by_id[key]=(kind,body);expected.append((kind,body))
            e.set('id',key);e.set('class','format-math-placeholder');e.text='FORMULA'
            for child in list(e):e.remove(child)
            math_records.append({'id':key,'lesson_id':u['id'],'kind':kind,'tex':body,'tex_sha256':sha(body.encode())})
        raw_ast,errors=run(['-f','html','-t','json'],LH.tostring(root,encoding='utf-8'))
        assert not errors.strip(),errors
        ast_doc=json.loads(raw_ast);version=ast_doc['pandoc-api-version']
        def replace(v):
            if v.get('t')=='Span' and v['c'][0][0] in math_by_id:
                kind,body=math_by_id[v['c'][0][0]]
                return {'t':'Math','c':[{'t':kind},body]}
            return v
        ast_doc=visit(ast_doc,replace)
        assert maths(ast_doc)==expected,('math source/AST mismatch',u['id'])
        rendered,warnings=run(['-f','json','-t','html5','--mathjax'],jb(ast_doc))
        assert not warnings.strip(),warnings
        assert nonmath_text(native)==nonmath_text(rendered.decode()),('non-math prose mismatch',u['id'])
        docroot=LH.fragment_fromstring(rendered.decode(),create_parent='div')
        ids=[e.get('id') for e in docroot.xpath('.//*[@id]')]
        assert len(ids)==len(set(ids)) and not set(ids)&all_ids
        all_ids.update(ids)
        blocks.extend(ast_doc['blocks'])
        if bound_assets:
            credits=bound_assets.export_credits() if u.get('native_images') else figure_provenance(bound_assets.records)
            credit_ast,credit_warnings=run(['-f','html','-t','json'],credits.encode())
            assert not credit_warnings.strip(),credit_warnings
            blocks.append({'t':'Div','c':[[u['id']+'--export-figure-credits',['export-figure-credits'],[]],json.loads(credit_ast)['blocks']]})
        (audit/(u['id']+'.native.html')).write_text(native,encoding='utf-8')
        unit_records.append({'lesson_id':u['id'],'source_sha256':u['source_sha256'].lower(),'source_bytes':u['bytes'],'math_regions':len(expected),'native_heading_count':len(root.xpath('.//h1|.//h2|.//h3|.//h4|.//h5|.//h6')),'ids':ids,'prose_math_parity':'PASS','blocks':len(ast_doc['blocks'])})
    # Exact legal texts can be part of the reader without pretending they are
    # another course lesson. Preserve characters; only paragraph layout changes.
    for appendix in manifest.get('reading_appendices',[]):
        ap=(work/appendix['path']).resolve()
        assert ap.is_relative_to(work) and appendix['id'] not in all_ids
        text=ap.read_text(encoding='utf-8')
        if appendix['format']=='plain_text':
            markup='<h1 id="'+html.escape(appendix['id'],quote=True)+'">'+html.escape(appendix['title'])+'</h1>'
            markup+=''.join('<p>'+html.escape(p)+'</p>' for p in re.split(r'\n\s*\n',text) if p.strip())
        elif appendix['format']=='commonmark':
            from markdown_it import MarkdownIt
            legal=LH.fragment_fromstring(MarkdownIt('commonmark',{'html':False}).render(text),create_parent='div')
            headings=legal.xpath('.//h1');assert len(headings)==1
            headings[0].set('id',appendix['id'])
            for link in legal.xpath('.//a[@href]'):
                href=link.get('href')
                if href in local:link.set('href',local[href])
            markup=LH.tostring(legal,encoding='unicode')
        elif appendix['format']=='source_code':
            markup='<h1 id="'+html.escape(appendix['id'],quote=True)+'">'+html.escape(appendix['title'])+'</h1>'
            markup+='<p>Exact original figure-generation source; included unchanged for reproducibility.</p><pre><code>'+html.escape(text)+'</code></pre>'
        else:raise ValueError('Unsupported appendix format')
        appendix_ast,warnings=run(['-f','html','-t','json'],markup.encode())
        assert not warnings.strip(),warnings
        blocks.extend(json.loads(appendix_ast)['blocks']);all_ids.add(appendix['id'])
    # Validate every internal route after legal/title/history appendices exist.
    local_links=[]
    def links(v):
        if v.get('t')=='Link':
            href=v['c'][-1][0]
            if href.startswith('#'):
                assert href[1:] in all_ids,('missing local fragment',href)
                local_links.append(href)
        return v
    visit(blocks,links)
    intro_ast,_=run(['-f','markdown','-t','json'],intro.encode())
    combined={'pandoc-api-version':version,'meta':meta,'blocks':json.loads(intro_ast)['blocks']+blocks}
    save(output/'course.ast.json',combined);save(output/'FORMULA_INDEX.json',math_records)
    save(output/'UNIT_INDEX.json',unit_records)
    save(output/'IMAGE_INDEX.json',image_records)
    save(output/'LINKED_FILE_INDEX.json',linked_file_records)
    if published_checks:save(work/'PUBLISHED_SOURCE_COMPARISON.json',{'schema':'published-html-editable-source-comparison/1','pass':True,'units':published_checks})
    (output/'about-edition.md').write_text(intro,encoding='utf-8')
    header=r'''\usepackage{amsmath,amssymb}
\usepackage{mathrsfs}
\usepackage{newunicodechar}
\newunicodechar{₂}{\textsubscript{2}}
\newunicodechar{∎}{\ensuremath{\blacksquare}}
\newunicodechar{□}{\ensuremath{\square}}
\allowdisplaybreaks
\setlength{\emergencystretch}{3em}
\sloppy
\relpenalty=100
\binoppenalty=100
'''
    if manifest.get('pdf_layout'):
        header+=r'''\usepackage{fvextra}
\usepackage{needspace}
\setmainfont{LibertinusSerif-Regular.otf}[BoldFont=LibertinusSerif-Bold.otf,ItalicFont=LibertinusSerif-Italic.otf,BoldItalicFont=LibertinusSerif-BoldItalic.otf]
\setmonofont{DejaVuSansMono.ttf}
\makeatletter\renewcommand{\@pnumwidth}{3em}\renewcommand{\@tocrmarg}{4em}\makeatother
\RecustomVerbatimEnvironment{verbatim}{Verbatim}{breaklines=true,breakanywhere=true,fontsize=\small}
\AtBeginDocument{\pdfstringdefDisableCommands{\def\varepsilon{epsilon}}}
'''
    (output/'layout.tex').write_text(header,encoding='utf-8')
    def wrap_table(v):
        if v.get('t')=='Code' and v['c'][1] in {r['original_href'] for r in manifest.get('external_course_route_notes',[])}:
            # Exact route identifiers are not live hyperlinks. xurl's
            # no-link rendering permits line breaks without losing bytes.
            value=v['c'][1]
            assert not any(ch in value for ch in '{}\\\r\n')
            return {'t':'RawInline','c':['latex',r'\nolinkurl{'+value+'}']}
        if v.get('t')=='Image' and v['c'][-1][0] in latex_images:
            v['c'][-1][0]=latex_images[v['c'][-1][0]]
        if v.get('t')=='Code' and re.fullmatch(r'[0-9A-Fa-f]{64}',v['c'][1]):
            chunks=[v['c'][1][i:i+8] for i in range(0,64,8)]
            return {'t':'RawInline','c':['latex',r'\texttt{'+r'\allowbreak{}'.join(chunks)+'}']}
        if v.get('t')=='Table':
            columns=v['c'][2];count=len(columns)
            # Wide character tables need room for descriptive row labels.
            for index,col in enumerate(columns):
                width=(2 if index==0 else 1)/(count+1) if count>=6 else 1/count
                col[1]={'t':'ColWidth','c':width}
        if v.get('t')=='Str' and '′' in v['c']:
            # U+2032 is made math-active by unicode-math. Keep prose primes
            # visually exact without invoking that active token in text mode.
            parts=v['c'].split('′');inlines=[]
            for index,part in enumerate(parts):
                if index:inlines.append({'t':'RawInline','c':['latex',r'\textsuperscript{\(\prime\)}']})
                if part:inlines.append({'t':'Str','c':part})
            return {'t':'Span','c':[['',[],[]],inlines]}
        return v
    latex_ast=visit(copy.deepcopy(combined),wrap_table)
    assert maths(latex_ast)==maths(combined),'Layout projection changed mathematics'
    tex,warnings=run(['-f','json','-t','latex','-s','--toc','--toc-depth=2','-V','documentclass=article','-V','fontsize=11pt','-V','papersize=a4','-V','geometry:margin=20mm','-V','colorlinks=true','-H',str(output/'layout.tex')],jb(latex_ast))
    assert not warnings.strip(),warnings
    # A leading Lie bracket in gathered/aligned can be mistaken for an
    # optional vertical-position argument. The no-op prevents that parse;
    # original formula bytes remain unchanged in the AST and EPUB annotations.
    tex,bracket_guards=re.subn(rb'(\\begin\{(?:aligned|gathered)\})(\s*)(?=\[)',rb'\1\2\\relax ',tex)
    # unicode-math requires explicit grouping when a math alphabet command
    # supplies one script token. Braces preserve that existing token's scope;
    # the source AST and EPUB annotation retain the original formula bytes.
    tex,alphabet_guards=re.subn(rb'([_^])(\\math(?:bb|cal|frak|scr))\s+([A-Za-z])',rb'\1{\2 \3}',tex)
    if manifest.get('pdf_layout'):
        from course_pdf_layout_projection import apply
        tex=apply(work,manifest,tex)
    # A title-only theorem paragraph otherwise may be stranded at a page foot.
    # Reserve space for its first lines, without boxing the complete proof.
    statement_title_guards=0
    if manifest.get('pdf_layout'):
        tex,statement_title_guards=re.subn(rb'(?m)^(\\textbf\{(?:Theorem|Proposition|Lemma|Corollary) [0-9.]+\})$',rb'\\Needspace{5\\baselineskip}\n\1',tex)
        # When the title immediately follows a section, reserve before both;
        # otherwise the title's own guard could strand the section heading.
        tex=re.sub(rb'(?m)^(\\(?:sub)*section[^\n]*(?:\n[^\n]+)*\n\n)\\Needspace\{5\\baselineskip\}\n',rb'\\Needspace{9\\baselineskip}\n\1',tex)
    from course_pdf_navigation import apply as project_navigation
    tex,navigation_projection=project_navigation(tex)
    (output/f'01-{slug}.tex').write_bytes(tex)
    epub,warnings=run(['-f','json','-t','epub3','-o','-','--toc','--toc-depth=3','--split-level=1','--mathml','--resource-path',str(output),f'--metadata=identifier:urn:open-courses:{cid}:{export["date_iso"]}:source-selection'],jb(combined))
    (output/f'03-{slug}.epub').write_bytes(epub)
    (audit/'EPUB_WARNINGS.txt').write_text(warnings,encoding='utf-8')
    check_html,htmlwarn=run(['-f','json','-t','html5','-s','--toc','--mathml'],jb(combined))
    (output/'course.html').write_bytes(check_html)
    (audit/'HTML_WARNINGS.txt').write_text(htmlwarn,encoding='utf-8')
    receipt={'schema':'course-format-build/1','state':'epub_tex_html_built_not_yet_final_qa','course_id':cid,'source_manifest_sha256':sha((work/'SOURCE_MANIFEST.json').read_bytes()),'lessons':len(units),'math_regions':len(math_records),'images':len(image_records),'headers':sum(r['native_heading_count'] for r in unit_records),'local_links_checked':len(local_links),'source_prose_math_parity':'PASS','epub_warnings':warnings,'html_warnings':htmlwarn,'files':[{ 'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [output/f'01-{slug}.tex',output/f'03-{slug}.epub',output/'course.html']], 'pdf':'not_built','limits':['No mathematical review added','Image source closure checked; final rendering validation separate','Not yet publication ready']}
    receipt['layout_projections']={'leading_lie_bracket_noop_guards':bracket_guards,'explicit_single_math_alphabet_script_groups':alphabet_guards,'prose_square_glyphs':'Mapped to corresponding math glyphs without changing source','long_hex_hashes':'Optional line breaks only; all characters retained','figure_credits':'Added marked export paratext; original lesson prose checked separately'}
    receipt['pdf_navigation_projection']=navigation_projection
    receipt['layout_projections']['statement_titles_keep_with_first_lines']=statement_title_guards
    receipt['included_course_links_made_offline']=course_link_projections
    save(work/'BUILD_RECEIPT.json',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['files','epub_warnings','html_warnings']}))

if __name__=='__main__':main()
