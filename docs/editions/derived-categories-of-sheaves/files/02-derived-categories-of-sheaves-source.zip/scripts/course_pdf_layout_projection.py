"""Exact display-only line breaking; no mathematical token is removed."""
import hashlib,json,re
def apply(work,manifest,tex):
    binding=manifest['pdf_layout'];p=(work/binding['path']).resolve()
    if not p.is_relative_to(work.resolve()):raise ValueError('Escaping layout contract')
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=binding['sha256']:raise ValueError('Changed layout contract')
    layout=json.loads(raw);return apply_rows(layout['displays'],tex)
def apply_rows(rows,tex):
    text=tex.decode('utf-8').replace('\r\n','\n')
    for row in rows:
        if row.get('replacement'):
            def content(s):
                s=re.sub(r'\\hspace\{[0-9.]+mm\}','',s)
                return re.sub(r'\s+','',s.replace('\\\\','').replace('&',''))
            assert content(row['original'])==content(row['replacement']),'Math token change'
            exact=r'\['+row['original']+r'\]'
            if text.count(exact)!=1:raise ValueError('Projection source mismatch for '+row['id'])
            replacement=re.sub(r'\n[ \t]*\n','\n',row['replacement'])
            text=text.replace(exact,r'\['+replacement+r'\]',1)
            continue
        before=row['original'];body=before;tag=''
        match=re.search(r'\s*(\\tag\{[^{}]+\})\s*$',body)
        if match:body,tag=body[:match.start()],body[match.start():]
        # Positions denote insertion only. Joining the untouched segments
        # exactly recreates the original body, including all math tokens.
        positions=row['insert_after'];assert positions==sorted(set(positions)) and all(0<i<len(body) for i in positions)
        starts=[0,*positions];ends=[*positions,len(body)]
        parts=[body[a:b] for a,b in zip(starts,ends)]
        assert ''.join(parts)+tag==before
        # Line-boundary whitespace has no mathematical content; blank lines
        # inside a TeX math environment would start an invalid paragraph.
        after=r'\begin{gathered}'+ '\n'+('\\\\\n'.join(p.strip() for p in parts))+'\n'+r'\end{gathered}'+tag
        exact=r'\['+before+r'\]'
        if text.count(exact)!=1:raise ValueError('Layout source mismatch for '+row['id'])
        text=text.replace(exact,r'\['+after+r'\]',1)
    return text.encode('utf-8')
