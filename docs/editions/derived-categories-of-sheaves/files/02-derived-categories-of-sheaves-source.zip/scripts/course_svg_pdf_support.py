"""Consume only exact, reviewed SVG-to-vector-PDF derivative bindings."""
from pathlib import Path
import hashlib, json
import fitz

def sha(raw):return hashlib.sha256(raw).hexdigest()

def read_local(root, relative, expected):
    if not isinstance(relative,str) or '\\' in relative or ':' in relative:
        raise ValueError('Invalid portable derivative path')
    parts=Path(relative)
    target=(root/parts).resolve()
    if parts.is_absolute() or '..' in parts.parts or not target.is_relative_to(root.resolve()):
        raise ValueError('Derivative path escapes the source package')
    raw=target.read_bytes()
    if sha(raw)!=expected.lower():raise ValueError('Changed SVG adapter evidence: '+relative)
    return target,raw

def svg_pdf_derivative(work, manifest, asset):
    binding=manifest.get('svg_pdf_adapter')
    if not binding:raise ValueError('SVG PDF adapter evidence is required')
    if not isinstance(binding.get('root'),str) or '\\' in binding['root'] or ':' in binding['root'] or Path(binding['root']).is_absolute() or '..' in Path(binding['root']).parts:
        raise ValueError('SVG adapter root must be portable and contained')
    root=(work/binding['root']).resolve()
    if not root.is_relative_to(work.resolve()):raise ValueError('Adapter root escapes source package')
    _,comparison_raw=read_local(root,'SVG_PDF_COMPARISON.json',binding['comparison_sha256'])
    comparison=json.loads(comparison_raw)
    _,visual_raw=read_local(root,'VISUAL_REVIEW.json',binding['visual_review_sha256'])
    visual=json.loads(visual_raw)
    if comparison['result']!='PASS' or visual['result']!='PASS':
        raise ValueError('SVG adapter checks have not passed')
    if visual['comparison']['sha256']!=sha(comparison_raw):
        raise ValueError('SVG visual review is stale')
    expected=asset['source_sha256'].lower()
    rows=[r for r in comparison['figures'] if r['asset_id']==asset['id'] and r['source_sha256']==expected]
    if len(rows)!=1:raise ValueError('SVG identity has no exact tested conversion')
    row=rows[0]
    if row['pixel_comparison']['result']!='PASS' or not row['same_as_previous_normalized_output']:
        raise ValueError('SVG conversion has no successful deterministic replay')
    reviews=[r for r in visual['figures'] if r['asset_id']==asset['id']
             and r['source_sha256']==expected and r['pdf_sha256']==row['pdf_sha256'] and r['result']=='PASS']
    if len(reviews)!=1:raise ValueError('SVG conversion has no exact visual comparison')
    target,raw=read_local(root,row['pdf'],row['pdf_sha256'])
    if len(raw)!=row['pdf_bytes']:raise ValueError('SVG derivative byte count mismatch')
    with fitz.open(stream=raw,filetype='pdf') as doc:
        if len(doc)!=1 or doc[0].get_images() or not doc[0].get_drawings():
            raise ValueError('SVG derivative is not a single vector page')
        for actual,wanted in zip((doc[0].rect.width,doc[0].rect.height),row['size_pt']):
            if abs(actual-wanted)>0.02:raise ValueError('SVG derivative dimensions changed')
    return {'path':target,'bytes':len(raw),'sha256':sha(raw),'source_svg_sha256':expected,
            'comparison_sha256':sha(comparison_raw),'visual_review_sha256':sha(visual_raw),
            'size_pt':row['size_pt']}

def vector_form_sources(rows,output):
    expected=[]
    for row in rows:
        derivative=row['pdf_derivative']
        raw=(output/derivative['path']).read_bytes()
        if len(raw)!=derivative['bytes'] or sha(raw)!=derivative['sha256']:
            raise ValueError('Stale packaged SVG derivative')
        with fitz.open(stream=raw,filetype='pdf') as source:
            expected.append((row,source[0].read_contents(),
                             {sha(source.extract_font(f[0])[3]) for f in source[0].get_fonts()}))
    return expected

def match_vector_forms(document,page,rows,output,prepared=None):
    """XeLaTeX retains included PDF drawing streams; require exact identities."""
    expected=vector_form_sources(rows,output) if prepared is None else prepared
    if not expected:return []
    result=[]
    page_fonts={sha(document.extract_font(f[0])[3]) for f in page.get_fonts()}
    for xref,name,parent,bbox in page.get_xobjects():
        if parent!=0:continue
        raw=document.xref_stream(xref)
        found=[(row,fonts) for row,stream,fonts in expected if raw==stream]
        if not found:continue
        if len(found)!=1:raise ValueError('Ambiguous SVG PDF form identity')
        row,fonts=found[0]
        if not fonts.issubset(page_fonts):raise ValueError('SVG embedded-font identity changed')
        result.append({'asset_id':row['asset_id'],'page':page.number+1,'kind':'vector_svg',
                       'form_xref':xref,'drawing_stream_sha256':sha(raw),'exact_drawing_stream':'PASS',
                       'embedded_font_identity':'PASS','source_svg_sha256':row['sha256']})
    return result
