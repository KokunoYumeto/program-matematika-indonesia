"""Explicit, frozen original PNG and static SVG figures for course units.

This module does not discover, generate, admit mathematics, or publish assets.
The catalog owner supplies an exact per-unit allowlist. A separate frozen
figure-admission receipt is optional in this vendored copy (see README.md):
when a row names one, it is still checked exactly as before. Existing
text-only unit identities stay unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import zlib

from output_safety import isolated_path
from course_svg import MAX_SVG_BYTES, dimensions as svg_dimensions, validate_svg


MAX_ASSETS = 32
MAX_PNG_BYTES = 16 * 1024 * 1024
MAX_DIMENSION = 16384
MAX_PIXELS = 40_000_000
MAX_RECEIPT_BYTES = 64 * 1024
PNG_SIGNATURE = b'\x89PNG\r\n\x1a\n'
HASH = re.compile(r'[A-F0-9]{64}\Z')
ENTRY_FIELDS = {'id', 'path', 'source', 'source_sha256', 'media_type',
                'bytes', 'width', 'height', 'authorship', 'source_attribution'}
RECEIPT_ENTRY_FIELDS = {'admission_receipt', 'admission_receipt_sha256'}
RECEIPT_FIELDS = {'schema', 'course_id', 'unit_id', 'asset_id', 'source_sha256',
                  'metadata_sha256', 'decision', 'scope', 'original_authorship',
                  'source_attribution', 'visual_check', 'audit_report_sha256'}
IMAGE_STYLE = 'max-width:100%;height:auto'
MEDIA_EXTENSIONS = {'image/png': '.png', 'image/svg+xml': '.svg'}


def _asset_limit(row):
    return MAX_SVG_BYTES if row['media_type'] == 'image/svg+xml' else MAX_PNG_BYTES


def image_dimensions(row):
    if row['media_type'] == 'image/svg+xml':
        svg_dimensions(row['width'], row['height'])
        # HTML width/height attributes require integer pixels; SVG physical
        # lengths are not rounded or substituted with viewBox coordinates.
        value = row['width']
        css_width = value if value.endswith(('px', 'pt')) else value + 'px'
        return {'style': IMAGE_STYLE + ';width:' + css_width}
    return {'width': str(row['width']), 'height': str(row['height']), 'style': IMAGE_STYLE}


def validate_asset(data, row):
    validator = validate_svg if row['media_type'] == 'image/svg+xml' else validate_png
    validator(data, width=row['width'], height=row['height'], size=row['bytes'],
              sha256=row['source_sha256'])


def _json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))


def _sha(data):
    return hashlib.sha256(data).hexdigest().upper()


def _identifier(value, field):
    # Runtime import deliberately reuses the reader's public-name policy
    # without a module-initialization cycle when course_reader imports us.
    from course_reader import identifier
    return identifier(value, field)


def _text(value, field):
    from course_reader import public_text
    value = public_text(value, field)
    if (len(value) > 4096 or any(ord(c) < 32 or ord(c) == 127 for c in value)
            or '<' in value or '>' in value):
        raise ValueError('unsafe course asset public text: ' + field)
    return value


def _hash(value, field):
    if not isinstance(value, str) or not HASH.fullmatch(value):
        raise ValueError('exact uppercase course asset SHA-256 required: ' + field)
    return value


def _relative(value, field, suffix=None):
    if (not isinstance(value, str) or not value or len(value) > 512
            or '\\' in value or ':' in value or '%' in value or '?' in value
            or '#' in value):
        raise ValueError('unsafe course asset relative path: ' + field)
    parts = value.split('/')
    if len(parts) > 12 or any(part in {'', '.', '..'} for part in parts):
        raise ValueError('noncanonical course asset relative path: ' + field)
    for part in parts:
        _identifier(part, field)
    if suffix is not None and not value.endswith(suffix):
        raise ValueError('unsupported course asset extension: ' + field)
    return PurePosixPath(value)


def _image_relative(value):
    """Permit canonical leading parents only for the explicit Markdown alias.

    Its containment is checked against the exact lesson path by the loader;
    frozen source/receipt paths always use the traversal-free _relative policy.
    """
    if not isinstance(value, str) or len(value) > 512:
        raise ValueError('invalid lesson-relative course image path')
    parts = value.split('/')
    parents = 0
    while parents < len(parts) and parts[parents] == '..':
        parents += 1
    if len(parts) > 12:
        raise ValueError('course image relative path exceeds depth limit')
    alias = '/'.join(parts[parents:])
    _relative(alias, 'Markdown image path')
    if PurePosixPath(alias).suffix not in MEDIA_EXTENSIONS.values():
        raise ValueError('unsupported course image extension')
    return parts


def _image_source(lesson, alias):
    resolved = list(lesson.parts[:-1])
    for part in _image_relative(alias):
        if part == '..':
            if not resolved:
                raise ValueError('course image path escapes frozen catalog root')
            resolved.pop()
        else:
            resolved.append(part)
    return '/'.join(resolved)


def _records(unit):
    rows = unit.get('assets', [])
    if not isinstance(rows, list) or len(rows) > MAX_ASSETS:
        raise ValueError('course assets must be a bounded explicit list')
    ids, paths, sources, receipts = set(), set(), set(), set()
    for row in rows:
        if not isinstance(row, dict) or set(row) not in (ENTRY_FIELDS, ENTRY_FIELDS | RECEIPT_ENTRY_FIELDS):
            raise ValueError('course asset must contain exactly the public asset schema')
        _identifier(row['id'], 'asset id')
        _image_relative(row['path'])
        extension = MEDIA_EXTENSIONS.get(row['media_type'])
        if extension is None:
            raise ValueError('only image/png and static image/svg+xml assets are supported')
        _relative(row['source'], 'frozen image source', extension)
        if not row['path'].endswith(extension):
            raise ValueError('course image alias/source/media type mismatch')
        _hash(row['source_sha256'], 'image')
        if 'admission_receipt' in row:
            _relative(row['admission_receipt'], 'figure admission receipt', '.json')
            _hash(row['admission_receipt_sha256'], 'figure admission receipt')
        for field, limit in (('bytes', _asset_limit(row)),):
            if type(row[field]) is not int or not 0 < row[field] <= limit:
                raise ValueError('invalid or excessive course asset ' + field)
        if row['media_type'] == 'image/svg+xml':
            svg_dimensions(row['width'], row['height'])
        else:
            for field in ('width', 'height'):
                if type(row[field]) is not int or not 0 < row[field] <= MAX_DIMENSION:
                    raise ValueError('invalid or excessive course asset ' + field)
            if row['width'] * row['height'] > MAX_PIXELS:
                raise ValueError('course PNG pixel count exceeds limit')
        author = row['authorship']
        if (not isinstance(author, dict) or set(author) != {'kind', 'credit', 'statement'}
                or author['kind'] != 'original'):
            raise ValueError('course figures require explicit original authorship')
        for field in ('credit', 'statement'):
            _text(author[field], 'figure authorship ' + field)
        attribution = row['source_attribution']
        if not isinstance(attribution, list) or not 1 <= len(attribution) <= 32:
            raise ValueError('explicit source attribution and proof locators required')
        for value in attribution:
            _text(value, 'figure source attribution')
        for field, seen in (('id', ids), ('path', paths), ('source', sources),
                            ('admission_receipt', receipts)):
            if field not in row:
                continue
            key = row[field].casefold()
            if key in seen:
                raise ValueError('duplicate or case-colliding course asset ' + field)
            seen.add(key)
    return json.loads(_json(rows))  # caller mutation cannot change a frozen binding


def asset_semantic_fields(unit):
    """Merge into semantic_digest's metadata before its existing JSON hashing.

    Omitted and empty lists contribute no key, preserving text-only identities.
    Every field of every nonempty asset row, including evidence, is bound.
    """
    rows = _records(unit)
    return {'assets': rows} if rows else {}


def figure_metadata_sha256(row):
    """Receipt's non-circular binding to the complete asset description."""
    row = _records({'assets': [row]})[0]
    return _sha(_json({key: value for key, value in row.items()
                      if key not in {'admission_receipt', 'admission_receipt_sha256'}}).encode())


def _plain_path(path):
    path = Path(path).absolute()
    for component in (path, *path.parents):
        try:
            info = component.lstat()
        except FileNotFoundError:
            continue
        if (stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0)
                & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)):
            raise ValueError('course asset path traverses a symlink or reparse point')
    return path.resolve()


def _read_bound(root, relative, expected_hash, *, limit, expected_size=None):
    rel = _relative(relative, 'frozen input')
    root = _plain_path(root)
    path = _plain_path(root.joinpath(*rel.parts))
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError('course asset input missing or outside frozen root')
    flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    with os.fdopen(os.open(path, flags), 'rb') as handle:
        before = os.fstat(handle.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_size > limit
                or (expected_size is not None and before.st_size != expected_size)):
            raise ValueError('course asset input size mismatch or limit exceeded')
        data = handle.read(limit + 1)
        after = os.fstat(handle.fileno())
    current = _plain_path(root.joinpath(*rel.parts)).stat()
    if (len(data) > limit or len(data) != before.st_size
            or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            != (current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns)
            or _sha(data) != _hash(expected_hash, 'frozen input')):
        raise ValueError('frozen course asset hash mismatch or input changed')
    return path, data


def validate_png(data, *, width, height, size, sha256):
    """Validate bounded PNG framing/CRC/IHDR, not the figure's mathematical truth.

    Ancillary PNG chunks are retained byte-for-byte.  The separate figure audit
    must inspect labels, attribution, and metadata before admitting those bytes.
    No raster decoder or image generator is invoked.
    """
    if (type(size) is not int or not 0 < size <= MAX_PNG_BYTES or len(data) != size
            or _sha(data) != _hash(sha256, 'PNG') or not data.startswith(PNG_SIGNATURE)):
        raise ValueError('course PNG signature, size or SHA-256 mismatch')
    if (type(width) is not int or type(height) is not int
            or not 0 < width <= MAX_DIMENSION or not 0 < height <= MAX_DIMENSION
            or width * height > MAX_PIXELS):
        raise ValueError('invalid or excessive course PNG dimensions')
    offset, seen_ihdr, seen_idat, ended_idat, seen_plte = 8, False, False, False, False
    colour = None
    while offset < len(data):
        if offset + 12 > len(data):
            raise ValueError('truncated course PNG chunk')
        length, kind = struct.unpack('>I4s', data[offset:offset+8])
        end = offset + 12 + length
        if end > len(data) or not re.fullmatch(b'[A-Za-z]{4}', kind) or kind[2] & 32:
            raise ValueError('invalid course PNG chunk framing')
        payload = data[offset+8:end-4]
        crc, = struct.unpack('>I', data[end-4:end])
        if zlib.crc32(kind + payload) & 0xffffffff != crc:
            raise ValueError('course PNG chunk CRC mismatch')
        if not seen_ihdr and kind != b'IHDR':
            raise ValueError('course PNG must start with IHDR')
        if kind == b'IHDR':
            if seen_ihdr or length != 13:
                raise ValueError('invalid or duplicate course PNG IHDR')
            w, h, depth, colour, compression, filtering, interlace = struct.unpack('>IIBBBBB', payload)
            valid_depths = {0: {1, 2, 4, 8, 16}, 2: {8, 16}, 3: {1, 2, 4, 8},
                            4: {8, 16}, 6: {8, 16}}
            if ((w, h) != (width, height) or depth not in valid_depths.get(colour, set())
                    or compression != 0 or filtering != 0 or interlace not in {0, 1}):
                raise ValueError('course PNG IHDR/dimensions mismatch')
            seen_ihdr = True
        elif kind == b'PLTE':
            if seen_plte or seen_idat or not 0 < length <= 768 or length % 3 or colour in {0, 4}:
                raise ValueError('invalid course PNG palette')
            seen_plte = True
        elif kind == b'IDAT':
            if ended_idat or (colour == 3 and not seen_plte):
                raise ValueError('invalid course PNG image-data order')
            seen_idat = True
        elif kind == b'IEND':
            if length != 0 or not seen_idat or end != len(data):
                raise ValueError('invalid course PNG end or trailing bytes')
            return
        else:
            if kind in {b'acTL', b'fcTL', b'fdAT'} or not kind[0] & 32:
                raise ValueError('animated or unsupported critical course PNG chunk')
            if seen_idat:
                ended_idat = True
        offset = end
    raise ValueError('course PNG has no terminal IEND')


def asset_output_path(course_id, unit_id, row):
    """Reader-root-relative, deterministic destination; never a source basename."""
    cid = _identifier(course_id, 'course id')
    uid = _identifier(unit_id, 'unit id')
    row = _records({'assets': [row]})[0]
    return f"courses/{cid}/assets/{uid}/{row['id']}-{row['source_sha256']}{MEDIA_EXTENSIONS[row['media_type']]}"


def _read_receipt(root, cid, uid, row):
    path, data = _read_bound(root, row['admission_receipt'], row['admission_receipt_sha256'],
                             limit=MAX_RECEIPT_BYTES)
    try:
        def unique_fields(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('duplicate figure admission JSON field')
                result[key] = value
            return result
        receipt = json.loads(data.decode('utf-8'), object_pairs_hook=unique_fields)
    except (UnicodeError, ValueError) as exc:
        raise ValueError('invalid figure admission JSON') from exc
    if not isinstance(receipt, dict) or set(receipt) != RECEIPT_FIELDS:
        raise ValueError('figure admission must contain exactly the public figure schema')
    expected = {'schema': 'stacks-course-figure-admission/v1', 'course_id': cid,
                'unit_id': uid, 'asset_id': row['id'], 'source_sha256': row['source_sha256'],
                'metadata_sha256': figure_metadata_sha256(row), 'decision': 'admit_figure',
                'scope': 'illustration_only'}
    if any(receipt[key] != value for key, value in expected.items()):
        raise ValueError('figure admission does not bind exact figure/metadata/scope')
    if not all(receipt[key] is True for key in ('original_authorship', 'source_attribution', 'visual_check')):
        raise ValueError('figure admission evidence incomplete')
    _hash(receipt['audit_report_sha256'], 'figure audit report')
    return path


def _alt(token):
    allowed = {'text', 'code_inline', 'softbreak', 'hardbreak', 'em_open', 'em_close',
               'strong_open', 'strong_close', 'course_math'}
    if any(child.type not in allowed for child in token.children or []):
        raise ValueError('course image alt must be descriptive text, not links or nested images')
    value = ''.join(' ' if child.type in {'softbreak', 'hardbreak'} else child.content
                    for child in token.children or [])
    return meaningful_alt(value)


def meaningful_alt(value):
    value = _text(value, 'image alt')
    if (len(value.strip()) < 12 or len(re.findall(r'[^\W_]+', value, re.UNICODE)) < 3
            or re.fullmatch(r'(?:image|figure|diagram|photo|picture)(?:\s+\d+)?', value, re.I)
            or re.fullmatch(r'\S+\.(?:png|jpe?g|svg)', value, re.I)):
        raise ValueError('meaningful descriptive course image alt text required')
    return value


@dataclass(frozen=True)
class BoundCourseAssets:
    """Verified private handles plus a detached, public-safe metadata snapshot."""
    frozen_root: Path
    course_id: str
    unit_id: str
    records_json: str

    @property
    def records(self):
        return json.loads(self.records_json)

    def validate_image(self, token):
        if token.type != 'image' or set(token.attrs) - {'src', 'alt', 'title'}:
            raise ValueError('unsupported course image token or attributes')
        path = token.attrGet('src') or ''
        _image_relative(path)
        row = next((row for row in self.records if row['path'] == path), None)
        if row is None:
            raise ValueError('course image is not in this unit explicit asset allowlist')
        _alt(token)
        if token.attrGet('title') is not None:
            _text(token.attrGet('title'), 'image title')
        return row

    def validate_tokens(self, tokens):
        used = set()
        def walk(items):
            for token in items:
                if token.type == 'image':
                    used.add(self.validate_image(token)['id'])
                elif token.type in {'html_inline', 'html_block'}:
                    raise ValueError('raw HTML is not a course image admission route')
                if token.children:
                    walk(token.children)
        walk(tokens)
        if used != {row['id'] for row in self.records}:
            raise ValueError('listed course asset is unused in its frozen lesson')

    def render_image(self, tokens, index, options, env):
        token = tokens[index]
        row = self.validate_image(token)
        relative = asset_output_path(self.course_id, self.unit_id, row).split('/', 2)[2]
        attrs = {'src': relative, 'alt': _alt(token), 'class': 'course-figure',
                 **image_dimensions(row), 'loading': 'lazy', 'decoding': 'async',
                 'data-asset-id': row['id'], 'data-asset-sha256': row['source_sha256']}
        if 'admission_receipt_sha256' in row:
            attrs['data-figure-admission-sha256'] = row['admission_receipt_sha256']
        if token.attrGet('title') is not None:
            attrs['title'] = token.attrGet('title')
        return '<img ' + ' '.join(f'{key}="{html.escape(value, quote=True)}"'
                                 for key, value in attrs.items()) + '>'


def read_unit_assets(frozen_root, course_id, unit):
    """Validate listed PNG/SVG bytes and optional display-only receipts; never enumerate."""
    cid, uid = _identifier(course_id, 'course id'), _identifier(unit['id'], 'unit id')
    rows = _records(unit)
    root = _plain_path(frozen_root)
    if rows:
        lesson = _relative(unit['source'], 'lesson source', '.md')
        for row in rows:
            if _image_source(lesson, row['path']) != row['source']:
                raise ValueError('asset source must match its exact lesson-relative Markdown path')
            _, data = _read_bound(root, row['source'], row['source_sha256'],
                                  limit=_asset_limit(row), expected_size=row['bytes'])
            validate_asset(data, row)
            if 'admission_receipt' in row:
                _read_receipt(root, cid, uid, row)
    return BoundCourseAssets(root, cid, uid, _json(rows))


def install_course_image_rule(md, assets):
    if md.options.get('html') or not isinstance(assets, BoundCourseAssets):
        raise ValueError('course assets require the HTML-disabled Markdown parser and bound assets')
    md.renderer.rules['image'] = assets.render_image


def copy_unit_assets(assets, output_root):
    """Copy only admitted bytes, exclusively, inside an isolated reader output.

    Call after read_catalog validates all lessons.  No existing file is replaced;
    rechecking each source and receipt detects changes since the catalog read.
    """
    if not isinstance(assets, BoundCourseAssets):
        raise ValueError('copy requires verified course assets')
    if not assets.records:
        return []
    out = isolated_path(Path(output_root), protected=(assets.frozen_root,))
    rows = assets.records
    targets = []
    for row in rows:
        target = isolated_path(out / asset_output_path(assets.course_id, assets.unit_id, row),
                               protected=(assets.frozen_root,))
        if not target.is_relative_to(out) or target.exists():
            raise ValueError('course asset output exists or escapes reader root')
        targets.append(target)
    copied = []
    for row, target in zip(rows, targets):
        _, data = _read_bound(assets.frozen_root, row['source'], row['source_sha256'],
                              limit=_asset_limit(row), expected_size=row['bytes'])
        validate_asset(data, row)
        if 'admission_receipt' in row:
            _read_receipt(assets.frozen_root, assets.course_id, assets.unit_id, row)
        target.parent.mkdir(parents=True, exist_ok=True)
        isolated_path(target, protected=(assets.frozen_root,))
        with target.open('xb') as handle:
            handle.write(data)
        if target.read_bytes() != data:
            raise ValueError('course asset output copy identity mismatch')
        copied.append(target.relative_to(out).as_posix())
    return copied


def asset_input_files(assets):
    """Exact frozen-input ZIP additions; revalidate rather than globbing folders."""
    result = {}
    for row in assets.records:
        image, data = _read_bound(assets.frozen_root, row['source'], row['source_sha256'],
                                 limit=_asset_limit(row), expected_size=row['bytes'])
        validate_asset(data, row)
        result[row['source']] = image
        if 'admission_receipt' in row:
            result[row['admission_receipt']] = _read_receipt(
                assets.frozen_root, assets.course_id, assets.unit_id, row)
    return result


def figure_provenance(rows):
    """Visible illustration credits; never a mathematical-admission banner."""
    rows = _records({'assets': rows})
    if not rows:
        return ''
    figures = []
    for row in rows:
        author = row['authorship']
        sources = ''.join('<li>'+html.escape(value)+'</li>' for value in row['source_attribution'])
        receipt = ('<p>Illustration-only receipt SHA-256: <code>'+row['admission_receipt_sha256']+'</code></p>'
                   if 'admission_receipt_sha256' in row else '')
        figures.append('<li><strong>'+html.escape(row['id'])+'</strong> — '+html.escape(author['credit'])+
                       '<p>'+html.escape(author['statement'])+'</p><ul>'+sources+'</ul>'+
                       '<p>Figure SHA-256: <code>'+row['source_sha256']+'</code></p>'+receipt+'</li>')
    note = ('<p>These receipts cover illustrations only. They do not close a proof or admit the lesson.</p>'
            if any('admission_receipt_sha256' in row for row in rows) else
            '<p>These credits cover the illustrations only. They do not change the lesson’s proof status.</p>')
    return ('<details class="figure-provenance"><summary>Figure credits and source locators</summary>'+
            note+'<ul>'+''.join(figures)+'</ul></details>')


class _CourseMediaIndex(HTMLParser):
    """Read actual image elements and strict visible provenance DOM fragments."""
    _VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link',
             'meta', 'param', 'source', 'track', 'wbr'}
    _INERT = {'head', 'script', 'style', 'template', 'noscript', 'textarea', 'select', 'option'}
    _MEDIA = {'picture', 'source', 'object', 'embed', 'iframe', 'svg', 'video', 'audio', 'canvas'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.images, self.provenance, self.stack = [], [], []
        self.active, self.active_depth = None, None

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == 'img':
            if len(values) != len(attrs):
                raise ValueError('duplicate rendered course image attributes')
            self.images.append(values)
        if tag in self._MEDIA or (tag == 'input' and (values.get('type') or '').lower() == 'image'):
            raise ValueError('unsupported course image/media element')
        if 'figure-provenance' in (values.get('class') or '').split():
            if self.active is not None:
                raise ValueError('nested figure provenance block')
            for ancestor, attributes in self.stack:
                style = re.sub(r'\s+', '', attributes.get('style') or '').lower()
                styles = dict(part.split(':', 1) for part in style.replace('!important', '').split(';') if ':' in part)
                if (ancestor in self._INERT or 'hidden' in attributes or 'inert' in attributes
                        or (attributes.get('aria-hidden') or '').lower() == 'true'
                        or styles.get('display') == 'none'
                        or styles.get('visibility') in {'hidden', 'collapse'}
                        or re.fullmatch(r'0(?:\.0+)?', styles.get('opacity', ''))):
                    raise ValueError('figure provenance is inside a hidden or inert element')
            self.active, self.active_depth = [], len(self.stack) + 1
        if self.active is not None:
            if len(values) != len(attrs):
                raise ValueError('duplicate figure provenance attributes')
            self.active.append(('start', tag, tuple(sorted(attrs))))
        if tag not in self._VOID:
            self.stack.append((tag, values))

    def handle_endtag(self, tag):
        if self.active is not None:
            if not self.stack or self.stack[-1][0] != tag:
                raise ValueError('malformed figure provenance DOM')
            self.active.append(('end', tag))
            if len(self.stack) == self.active_depth:
                self.provenance.append(self.active)
                self.active, self.active_depth = None, None
        # Outside the controlled fragment, tolerate the page shell's optional
        # HTML end tags; inside it, the strict check above is authoritative.
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break

    def handle_data(self, data):
        if self.active is not None:
            if self.active and self.active[-1][0] == 'text':
                self.active[-1] = ('text', self.active[-1][1] + data)
            else:
                self.active.append(('text', data))

    def handle_comment(self, data):
        if self.active is not None:
            raise ValueError('unexpected comment in figure provenance DOM')

    def close(self):
        super().close()
        if self.active is not None:
            raise ValueError('unterminated figure provenance DOM')


def course_asset_errors(output_root, courses):
    """Cold-check output image inventory, image elements, hashes and metadata.

    `courses` is the public courses.json object.  Does not need private inputs.
    Existing build-manifest checks still independently bind every output byte.
    """
    errors, expected = [], set()
    root = Path(output_root)
    navigation = ['courses.html']
    for course in courses.get('courses', []):
        navigation.append(f"courses/{_identifier(course['id'], 'course id')}/index.html")
        for unit in course.get('units', []):
            key = f"{course['id']}:{unit['id']}"
            try:
                rows = _records(unit)
                by_src = {}
                for row in rows:
                    relative = asset_output_path(course['id'], unit['id'], row)
                    expected.add(relative)
                    _, data = _read_bound(root, relative, row['source_sha256'], limit=_asset_limit(row),
                                          expected_size=row['bytes'])
                    validate_asset(data, row)
                    by_src[relative.split('/', 2)[2]] = row
                page = _plain_path(root / f"courses/{_identifier(course['id'], 'course id')}/{_identifier(unit['id'], 'unit id')}.html")
                if not page.is_relative_to(root.resolve()):
                    raise ValueError('course image page escapes output')
                parser = _CourseMediaIndex()
                parser.feed(page.read_text(encoding='utf-8'))
                parser.close()
                admitted_provenance = _CourseMediaIndex()
                admitted_provenance.feed(figure_provenance(rows))
                admitted_provenance.close()
                if parser.provenance != admitted_provenance.provenance:
                    raise ValueError('visible figure provenance differs from bound credits/source locators')
                used = set()
                for attrs in parser.images:
                    row = by_src.get(attrs.get('src'))
                    if row is None:
                        raise ValueError('unlisted or nonlocal rendered course image')
                    meaningful_alt(attrs.get('alt'))
                    contract = {'class': 'course-figure', **image_dimensions(row),
                                'loading': 'lazy', 'decoding': 'async', 'data-asset-id': row['id'],
                                'data-asset-sha256': row['source_sha256']}
                    if 'admission_receipt_sha256' in row:
                        contract['data-figure-admission-sha256'] = row['admission_receipt_sha256']
                    if (set(attrs) - set(contract) - {'src', 'alt', 'title'}
                            or any(attrs.get(k) != v for k, v in contract.items())):
                        raise ValueError('rendered course image differs from admitted contract')
                    if 'title' in attrs:
                        _text(attrs['title'], 'rendered image title')
                    used.add(row['id'])
                if used != {row['id'] for row in rows}:
                    raise ValueError('missing rendered admitted course image')
            except (OSError, ValueError, TypeError, KeyError) as exc:
                errors.append('course asset ' + key + ': ' + str(exc))
    for relative in navigation:
        try:
            page = _plain_path(root / relative)
            if not page.is_relative_to(root.resolve()):
                raise ValueError('course navigation page escapes output')
            parser = _CourseMediaIndex()
            parser.feed(page.read_text(encoding='utf-8'))
            parser.close()
            if parser.images or parser.provenance:
                raise ValueError('uncontracted image or figure provenance on course navigation page')
        except (OSError, ValueError, TypeError) as exc:
            errors.append('course asset navigation ' + relative + ': ' + str(exc))
    actual = set()
    try:
        courses_dir = _plain_path(root / 'courses')
        if not courses_dir.is_relative_to(root.resolve()):
            raise ValueError('course assets directory escapes output')
        for path in courses_dir.rglob('*'):
            _plain_path(path)
            local = path.relative_to(courses_dir)
            if path.is_file() and ('assets' in local.parts or path.suffix.lower() in {'.png', '.svg'}):
                actual.add('courses/' + local.as_posix())
    except (OSError, ValueError) as exc:
        errors.append('course asset inventory: ' + str(exc))
    if actual != expected:
        errors.append('course asset output inventory differs from explicit unit allowlists')
    return errors
