"""Keep TeX pipes intact while delegating table structure to markdown-it-py.

Only the table block parser sees the temporary, same-length masking. Source
offsets and line numbers are unchanged, and inline token text is restored before
mathematics, links or headings are rendered. No authored source is rewritten.
"""
import re

from markdown_it.rules_block import table as markdown_table

DELIMITERS = (("$$", "$$"), (r"\[", r"\]"), (r"\(", r"\)"), ("$", "$"))


def math_pipe_positions(line):
    """Find pipes in closed single-line math, excluding Markdown code/escapes."""
    positions = []
    cursor = 0
    while cursor < len(line):
        if line[cursor] == '`':
            run = re.match(r'`+', line[cursor:]).group()
            closing = re.search(r'(?<!`)`{' + str(len(run)) + r'}(?!`)', line[cursor + len(run):])
            if closing:
                cursor += len(run) + closing.end()
            else:
                cursor += len(run)
            continue
        matched = False
        for opener, closer in DELIMITERS:
            if not line.startswith(opener, cursor):
                continue
            end = line.find(closer, cursor + len(opener))
            # Match the course renderer's existing inline math delimiters.
            while end >= 0 and line[end - 1] == '\\':
                end = line.find(closer, end + len(closer))
            if end >= 0:
                positions.extend(i for i in range(cursor, end + len(closer)) if line[i] == '|')
                cursor = end + len(closer)
                matched = True
            break
        if matched:
            continue
        cursor += 2 if line[cursor] == '\\' else 1
    return positions


def math_table(state, start, end, silent):
    """Run the ordinary table rule with exact TeX pipe preservation."""
    if start + 1 >= end:
        return False
    separator = state.src[state.bMarks[start + 1] + state.tShift[start + 1]:state.eMarks[start + 1]]
    if '-' not in separator or not re.fullmatch(r'[|:\- \t]+', separator):
        return False
    positions = []
    for line_number in range(start, end):
        if state.sCount[line_number] < state.blkIndent or state.is_code_block(line_number):
            break
        begin = state.bMarks[line_number] + state.tShift[line_number]
        line = state.src[begin:state.eMarks[line_number]]
        if not line.strip():
            break
        positions.extend(begin + pos for pos in math_pipe_positions(line))
    if not positions:
        return markdown_table(state, start, end, silent)

    original = state.src
    marker = next((chr(n) for n in range(0xE000, 0xF900) if chr(n) not in original), None)
    if marker is None:
        raise ValueError('table source exhausts temporary math marker space')
    parts, cursor = [], 0
    for position in positions:
        parts.extend((original[cursor:position], marker))
        cursor = position + 1
    parts.append(original[cursor:])
    token_start = len(state.tokens)
    state.src = ''.join(parts)
    try:
        return markdown_table(state, start, end, silent)
    finally:
        state.src = original
        for token in state.tokens[token_start:]:
            token.content = token.content.replace(marker, '|')


def install_math_tables(md):
    md.block.ruler.at('table', math_table, {'alt': ['paragraph', 'reference']})
