"""Bounded static SVG validation; never sanitizes, fetches or rewrites bytes.

This is a deliberately explicit static-vector profile, not an arbitrary SVG
renderer. Rejecting an unsupported file is preferable to changing its figure.
The catalog keeps native root width/height as exact strings (px, pt or unitless).
"""
from fractions import Fraction
import hashlib
import re
from xml.parsers import expat

MAX_SVG_BYTES = 4 * 1024 * 1024
MAX_DIMENSION = 16384
MAX_PIXELS = 40_000_000
MAX_NODES = 50_000
MAX_DEPTH = 64
MAX_EXPANDED_NODES = 200_000
SVG = 'http://www.w3.org/2000/svg'
XLINK = 'http://www.w3.org/1999/xlink'
XML = 'http://www.w3.org/XML/1998/namespace'
RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
DC = 'http://purl.org/dc/elements/1.1/'
CC = 'http://creativecommons.org/ns#'
NS = {SVG, XLINK, XML, RDF, DC, CC}
IDENT = r'[A-Za-z_][A-Za-z0-9_.-]*'
NUMBER = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d{1,3})?'
ROOT_LENGTH = re.compile(r'((?:\d+(?:\.\d*)?|\.\d+))(px|pt)?\Z')
SAFE_TAGS = {'svg', 'g', 'defs', 'path', 'rect', 'line', 'polyline', 'polygon',
             'circle', 'ellipse', 'text', 'tspan', 'use', 'clipPath', 'mask',
             'linearGradient', 'radialGradient', 'stop', 'pattern', 'marker',
             'title', 'desc', 'metadata', 'style'}
META_TAGS = {RDF: {'RDF', 'Description', 'Bag', 'Seq', 'li'},
             DC: {'title', 'date', 'description', 'format', 'creator', 'type',
                  'rights', 'source', 'identifier', 'publisher', 'contributor'},
             CC: {'Work', 'Agent', 'License', 'license', 'permits', 'requires', 'prohibits'}}
PAINT = {'fill', 'stroke', 'color', 'stop-color', 'flood-color'}
REF_PROPS = {'clip-path', 'mask', 'marker-start', 'marker-mid', 'marker-end'}
NUM_PROPS = {'opacity', 'fill-opacity', 'stroke-opacity', 'stroke-width',
             'stroke-miterlimit', 'stroke-dashoffset', 'font-size', 'font-weight',
             'letter-spacing', 'word-spacing', 'stop-opacity', 'flood-opacity'}
ENUM_PROPS = {
    'stroke-linejoin': {'miter', 'round', 'bevel'},
    'stroke-linecap': {'butt', 'round', 'square'},
    'fill-rule': {'nonzero', 'evenodd'}, 'clip-rule': {'nonzero', 'evenodd'},
    'font-style': {'normal', 'italic', 'oblique'},
    'font-variant': {'normal', 'small-caps'},
    'text-anchor': {'start', 'middle', 'end'},
    'dominant-baseline': {'auto', 'middle', 'central', 'hanging', 'alphabetic', 'text-before-edge', 'text-after-edge'},
    'alignment-baseline': {'auto', 'baseline', 'middle', 'central', 'hanging', 'alphabetic'},
    'vector-effect': {'none', 'non-scaling-stroke'},
    'shape-rendering': {'auto', 'optimizeSpeed', 'crispEdges', 'geometricPrecision'},
    'text-rendering': {'auto', 'optimizeSpeed', 'optimizeLegibility', 'geometricPrecision'},
}
PROPS = PAINT | REF_PROPS | NUM_PROPS | set(ENUM_PROPS) | {'stroke-dasharray', 'font-family'}
LENGTH_ATTRS = {'x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry',
                'width', 'height', 'dx', 'dy', 'fx', 'fy', 'fr', 'refX', 'refY',
                'markerWidth', 'markerHeight', 'textLength', 'offset'}
PLAIN_ATTRS = {'id', 'class', 'style', 'd', 'points', 'transform', 'gradientTransform',
               'patternTransform', 'viewBox', 'preserveAspectRatio', 'version', 'type',
               'href', 'clipPathUnits', 'maskUnits', 'maskContentUnits', 'gradientUnits',
               'patternUnits', 'patternContentUnits', 'spreadMethod', 'markerUnits',
               'orient', 'lengthAdjust', 'rotate', 'role', 'aria-label', 'aria-labelledby',
               'aria-describedby'} | LENGTH_ATTRS | PROPS


def dimensions(width, height):
    """Exact native SVG lengths, not rounded image pixels or guessed viewBox units."""
    values = []
    for value in (width, height):
        if not isinstance(value, str) or len(value) > 40:
            raise ValueError('SVG width/height must be exact native length strings')
        match = ROOT_LENGTH.fullmatch(value)
        if not match:
            raise ValueError('SVG dimensions require absolute px, pt or unitless lengths')
        pixels = Fraction(match[1]) * (Fraction(4, 3) if match[2] == 'pt' else 1)
        if not 0 < pixels <= MAX_DIMENSION:
            raise ValueError('SVG dimensions exceed limits')
        values.append(pixels)
    if values[0] * values[1] > MAX_PIXELS:
        raise ValueError('SVG viewport area exceeds limit')
    return tuple(values)


def _numbers(value, count=None, lengths=False):
    pattern = NUMBER + (r'(?:px|pt|%)?' if lengths else '')
    parts = re.split(r'[\s,]+', value.strip())
    if not parts or (count is not None and len(parts) != count) or len(parts) > 100_000:
        raise ValueError('unsupported SVG number list')
    if any(not re.fullmatch(pattern, part) for part in parts):
        raise ValueError('unsafe SVG numeric attribute')


def _fragment(value):
    if not re.fullmatch('#' + IDENT, value):
        raise ValueError('SVG references must be plain same-document fragments')
    return value[1:]


def _property(name, value, refs):
    if name not in PROPS or any(c in value for c in '\\@{}<>') or '/*' in value or '*/' in value:
        raise ValueError('unsupported or unsafe SVG CSS property')
    value = value.strip()
    if name in PAINT | REF_PROPS:
        ref = re.fullmatch(r'url\(\s*([\'\"]?)(#' + IDENT + r')\1\s*\)', value)
        if ref:
            refs.append(_fragment(ref[2]))
        elif name in REF_PROPS and value != 'none':
            raise ValueError('SVG reference property must be none or a local fragment')
        elif name in PAINT and not (re.fullmatch(r'#[0-9A-Fa-f]{3,8}|[A-Za-z]+', value)
                                  or re.fullmatch(r'(?:rgb|rgba|hsl|hsla)\([0-9.,%+\-\s]+\)', value)):
            raise ValueError('unsupported SVG paint')
    elif name in NUM_PROPS:
        if name == 'font-weight' and value in {'normal', 'bold', 'bolder', 'lighter'}:
            return
        _numbers(value, 1, lengths=True)
    elif name == 'stroke-dasharray':
        if value != 'none':
            _numbers(value, lengths=True)
    elif name == 'font-family':
        if not re.fullmatch(r"[A-Za-z0-9 _,'\"-]+", value):
            raise ValueError('unsafe SVG font-family')
    elif value not in ENUM_PROPS[name]:
        raise ValueError('unsupported SVG presentation value')


def _style(value, refs):
    if len(value) > 32768:
        raise ValueError('SVG style too large')
    for declaration in value.split(';'):
        if not declaration.strip():
            continue
        if declaration.count(':') != 1:
            raise ValueError('unsafe SVG style declaration')
        name, content = declaration.split(':', 1)
        _property(name.strip(), content.strip(), refs)


def validate_svg(data, *, width, height, size, sha256):
    """Verify exact bytes and an inert, bounded local-resource-only vector profile.

    Expat never resolves the historical Matplotlib SVG 1.1 DTD declaration.
    Only that known external declaration, without an internal subset, is inertly
    accepted; entity declarations, all other doctypes and processing instructions
    fail. No network/filesystem resolver or image conversion is involved.
    """
    dimensions(width, height)
    if (type(size) is not int or not 0 < size <= MAX_SVG_BYTES or len(data) != size
            or not isinstance(sha256, str) or not re.fullmatch('[A-F0-9]{64}', sha256)
            or hashlib.sha256(data).hexdigest().upper() != sha256):
        raise ValueError('SVG size or SHA-256 mismatch')
    try:
        data.decode('utf-8')
    except UnicodeError as exc:
        raise ValueError('SVG must be UTF-8') from exc
    if b'\x00' in data:
        raise ValueError('SVG cannot contain NUL bytes')
    parser = expat.ParserCreate(encoding='utf-8', namespace_separator='|')
    parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
    nodes, stack, ids, doctype_seen = [], [], {}, []

    def fail(*args):
        raise ValueError('SVG entities, external resolution and processing instructions are forbidden')

    def declaration(version, encoding, standalone):
        if version != '1.0' or (encoding and encoding.lower() not in {'utf-8', 'utf8'}):
            raise ValueError('unsupported SVG XML declaration')

    def doctype(name, system, public, internal):
        if doctype_seen or internal or (name, system, public) != (
                'svg', 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd', '-//W3C//DTD SVG 1.1//EN'):
            raise ValueError('unsupported SVG doctype or internal subset')
        doctype_seen.append(True)

    def namespace(prefix, uri):
        if uri not in NS:
            raise ValueError('unsupported SVG namespace')

    def start(name, attrs):
        if len(nodes) >= MAX_NODES or len(stack) >= MAX_DEPTH or len(attrs) > 64:
            raise ValueError('SVG node, depth or attribute limit exceeded')
        if any(len(value) > 1024 * 1024 for value in attrs.values()):
            raise ValueError('SVG attribute too large')
        namespace_uri, _, tag = name.rpartition('|')
        in_metadata = bool(stack and nodes[stack[-1]]['metadata']) or (namespace_uri == SVG and tag == 'metadata')
        if namespace_uri == SVG:
            if tag not in SAFE_TAGS or (in_metadata and tag not in {'metadata', 'title', 'desc'}):
                raise ValueError('unsupported or active SVG element: ' + tag)
        elif not in_metadata or tag not in META_TAGS.get(namespace_uri, set()):
            raise ValueError('unsupported SVG metadata namespace/element')
        if not stack:
            if nodes or name != SVG + '|svg' or attrs.get('width') != width or attrs.get('height') != height:
                raise ValueError('SVG root or exact native dimensions mismatch')
        elif tag == 'svg':
            raise ValueError('nested SVG viewports are outside this profile')
        index = len(nodes)
        node = {'tag': tag, 'metadata': in_metadata, 'edges': [], 'refs': [], 'text': []}
        nodes.append(node)
        if stack:
            nodes[stack[-1]]['edges'].append(index)
        stack.append(index)
        for key, value in attrs.items():
            uri, _, attr = key.rpartition('|')
            if in_metadata and uri == RDF and attr in {'resource', 'about'}:
                continue  # inert descriptive strings, never a load instruction
            if uri == XML and attr in {'space', 'lang'}:
                if attr == 'space' and value not in {'default', 'preserve'}:
                    raise ValueError('invalid XML whitespace mode')
                continue
            if uri == XLINK and attr == 'href':
                attr = 'href'
            elif uri:
                raise ValueError('unsupported namespaced SVG attribute')
            if attr not in PLAIN_ATTRS:
                raise ValueError('unsupported or active SVG attribute: ' + attr)
            if attr == 'id':
                if not re.fullmatch(IDENT, value) or value in ids:
                    raise ValueError('invalid or duplicate SVG id')
                ids[value] = index
            elif attr == 'href':
                if tag not in {'use', 'linearGradient', 'radialGradient', 'pattern'}:
                    raise ValueError('SVG href on unsupported element')
                node['refs'].append(_fragment(value))
            elif attr == 'style':
                _style(value, node['refs'])
            elif attr in PROPS:
                _property(attr, value, node['refs'])
            elif attr in LENGTH_ATTRS:
                _numbers(value, lengths=True)
            elif attr == 'viewBox':
                _numbers(value, 4)
                parts = re.split(r'[\s,]+', value.strip())
                if Fraction(parts[2]) <= 0 or Fraction(parts[3]) <= 0:
                    raise ValueError('SVG viewBox must have positive extent')
            elif attr in {'transform', 'gradientTransform', 'patternTransform'}:
                rest = re.sub(r'(?:matrix|translate|scale|rotate|skewX|skewY)\([0-9eE.,+\-\s]+\)', '', value)
                if rest.strip(' ,\t\r\n'):
                    raise ValueError('unsafe SVG transform')
            elif attr == 'd':
                if not re.fullmatch(r'[MmZzLlHhVvCcSsQqTtAaEe0-9.,+\-\s]*', value):
                    raise ValueError('unsupported SVG path data')
            elif attr in {'points', 'rotate'}:
                _numbers(value)
            elif attr in {'class', 'aria-labelledby', 'aria-describedby'}:
                if not all(re.fullmatch(IDENT, item) for item in value.split()):
                    raise ValueError('unsupported SVG token list')
            elif attr == 'type':
                if tag != 'style' or value != 'text/css':
                    raise ValueError('unsupported SVG type')
            elif attr == 'aria-label':
                if len(value) > 4096:
                    raise ValueError('SVG accessible label too large')
            elif not re.fullmatch(r'[A-Za-z0-9_.+\-\s]+', value):
                raise ValueError('unsafe SVG static attribute')

    def text(value):
        if stack and nodes[stack[-1]]['tag'] == 'style':
            node = nodes[stack[-1]]
            node['text'].append(value)
            if sum(map(len, node['text'])) > 32768:
                raise ValueError('SVG stylesheet too large')

    def end(name):
        node = nodes[stack.pop()]
        if node['tag'] == 'style':
            sheet = ''.join(node['text'])
            pos = 0
            for match in re.finditer(r'([^{}]+)\{([^{}]*)\}', sheet):
                if sheet[pos:match.start()].strip():
                    raise ValueError('unsafe SVG stylesheet syntax')
                for selector in match[1].split(','):
                    if not re.fullmatch(r'(?:\*|[A-Za-z][A-Za-z0-9-]*|[.#]' + IDENT + ')', selector.strip()):
                        raise ValueError('unsupported SVG stylesheet selector')
                _style(match[2], node['refs'])
                pos = match.end()
            if sheet[pos:].strip():
                raise ValueError('unsafe SVG stylesheet syntax')

    parser.XmlDeclHandler = declaration
    parser.StartDoctypeDeclHandler = doctype
    parser.StartNamespaceDeclHandler = namespace
    parser.EntityDeclHandler = fail
    parser.ExternalEntityRefHandler = fail
    parser.SkippedEntityHandler = fail
    parser.ProcessingInstructionHandler = fail
    parser.StartElementHandler = start
    parser.EndElementHandler = end
    parser.CharacterDataHandler = text
    try:
        parser.Parse(data, True)
    except (expat.ExpatError, RecursionError) as exc:
        raise ValueError('invalid or excessive SVG XML') from exc
    if not nodes or stack:
        raise ValueError('incomplete SVG document')
    for node in nodes:
        for ref in node['refs']:
            if ref not in ids:
                raise ValueError('missing local SVG reference: ' + ref)
            node['edges'].append(ids[ref])
    active, costs = set(), {}

    def visit(index, depth):
        if index in active or depth > MAX_DEPTH:
            raise ValueError('cyclic or excessive SVG reference depth')
        if index in costs:
            return costs[index]
        active.add(index)
        cost = 1
        for child in nodes[index]['edges']:
            cost += visit(child, depth + 1)
            if cost > MAX_EXPANDED_NODES:
                raise ValueError('SVG reference expansion exceeds limit')
        active.remove(index)
        costs[index] = cost
        return cost
    visit(0, 0)
    return {'nodes': len(nodes), 'ids': len(ids), 'local_references': sum(len(n['refs']) for n in nodes),
            'known_inert_doctype': bool(doctype_seen), 'byte_preserving': True}
