# Haar uniqueness through shrinking neighborhoods

*Adapted from D. H. Fremlin, Measure Theory, by GPT-6.1 Sol (OpenAI), Ultra reasoning effort, 3 October 2026. The neighborhood-ratio argument is Fremlin's; the compact shrinking argument and the final Borel-measure step translate it to the convention of this course. Self-checked by the adapting AI; no independent AI or human review is claimed.*

This proof compares the masses of small symmetric neighborhoods. It gives an alternative to [Theorem 9.2 of the Haar lesson](../haar-measure-on-locally-compact-groups.md#oa-fnd-hm-06), using the open-set case of the Radon-product theorem. Throughout, a Radon measure has the course's convention: it is finite on compact sets, outer regular on Borel sets and inner regular on open sets.

**Theorem.** Let \(G\) be an arbitrary locally compact Hausdorff group, and let \(\mu,\nu\) be nonzero left-invariant Radon measures on \(G\). There is a unique \(c>0\) such that \(\mu=c\nu\). Neither measure is assumed sigma-finite.

*Proof.* By [Proposition 9.1](../haar-measure-on-locally-compact-groups.md#oa-fnd-hm-06), each nonempty open set has positive measure for both measures. Relatively compact open sets have finite measure for both. Let \(\mathcal U\) be the symmetric relatively compact open neighborhoods of the identity, ordered by reverse inclusion. These form a neighborhood base: intersect an identity neighborhood with its inverse and with a relatively compact identity neighborhood.

Fix a nonempty relatively compact open set \(O\), and \(0<\varepsilon<1\). Inner regularity gives a compact \(K\subset O\) with
\[
\mu(K)>(1-\varepsilon)\mu(O).
\]
There are an open \(H\supset K\) and an identity neighborhood \(V\) such that \(HV\subset O\). Indeed, continuity of multiplication supplies a box \(H_x\times V_x\) whose product lies in \(O\) for each \(x\in K\); take finitely many \(H_x\) covering \(K\), their union for \(H\), and the intersection of the corresponding \(V_x\) for \(V\). Shrink \(V\) to a member of \(\mathcal U\).

For \(U\in\mathcal U\) with \(U\subset V\), put
\[
 W=\{(x,y)\in O\times O:x^{-1}y\in U\}.
\]
This is open in \(G\times G\). [Theorem 5.1(1)](../haar-measure-on-locally-compact-groups.md#oa-fnd-hm-10) identifies the two integrals of its sections with \((\mu\widehat\times\nu)(W)\); its open-set assertion does not require sigma-finiteness. If \(x\in H\), the vertical section contains \(xU\). A horizontal section at \(y\in O\) is contained in \(yU\), since \(U=U^{-1}\). Left invariance therefore gives
\[
 (1-\varepsilon)\mu(O)\nu(U)
 <\mu(H)\nu(U)
 \le (\mu\widehat\times\nu)(W)
 \le\mu(U)\nu(O).
\]
All the factors being divided by are positive and finite. Repeating the argument with the two measures exchanged gives, for all sufficiently small \(U\in\mathcal U\),
\[
 (1-\varepsilon)\frac{\mu(O)}{\nu(O)}
 \le\frac{\mu(U)}{\nu(U)}
 \le\frac1{1-\varepsilon}\frac{\mu(O)}{\nu(O)}.
\]
Thus the neighborhood net of ratios has limit \(\mu(O)/\nu(O)\). The net is the same for every such \(O\), so these ratios all have one common value \(c>0\).

Let \(A\) be any open set and \(K\subset A\) any compact set. Compact shrinking supplies a relatively compact open \(O\) with \(K\subset O\subset A\). Hence \(\mu(K)\le\mu(O)=c\nu(O)\le c\nu(A)\). Taking the supremum over \(K\), and then exchanging the measures, proves \(\mu(A)=c\nu(A)\), also when this value is infinite. Finally outer regularity gives \(\mu(E)=c\nu(E)\) for every Borel \(E\). Evaluating any nonempty relatively compact open set proves uniqueness of \(c\). \(\square\)

The signed-function kernel argument in the [quotient lesson](../quotient-measures-and-weils-integration-formula.md#exactly-when-the-quotient-measure-is-invariant) uses a different compact cutoff. It must equal one on the projection of the support of the original function; cancellation can make the support of its subgroup average smaller.

## Source and terms

D. H. Fremlin, [*Measure Theory*, Volume 4, Topological Measure Spaces](https://www1.essex.ac.uk/maths/people/fremlin/mt4.2013/index.htm), supplies the neighborhood-ratio proof. Copyright © 1998 D. H. Fremlin. The original supplied [editable TeX](https://www1.essex.ac.uk/maths/people/fremlin/mt4.2013/mt442.tex) remains attributed to Fremlin. This separately titled adaptation is distributed under the [Design Science License](../licenses/design-science-license.txt), with editable Markdown source. Changes on 3 October 2026: restriction to the course's LCH/Borel convention, expansion of compact shrinking, and replacement of the quasi-Radon base-uniqueness step by inner regularity on open sets and outer regularity on Borel sets. Adaptation and additions: GPT-6.1 Sol (OpenAI), Ultra.

THE WORK IS PROVIDED "AS IS," AND COMES WITH ABSOLUTELY NO WARRANTY, EXPRESS OR IMPLIED, TO THE EXTENT PERMITTED BY APPLICABLE LAW. The full warranty and liability terms are in the accompanying Design Science License.
