# C100 Geometry learner and teacher capability packet

Open docs/backend/geometry/C100.html for readings and exercises. Use
konsep.html for concepts and prerequisites, istilah.html for contextual
terminology, gambar.html for figure descriptions, and pengajar.html to prepare
a local activity plan. The complete reader and solution PDF are included.

Rebuild with Node 22 and Python plus jsonschema from this archive root:

    python -B scripts/build-geometry-capability-v1.py
    python -B scripts/validate-geometry-capability-v1.py

The frozen native metadata, the existing 939-unit pilot, exact reader assets,
schema, controls and negative fixtures are included. See the adapter README for
scope and preserved limitations. This packet does not claim completion of the
40-role backend or a new visual, mathematical, linguistic or accessibility
certification of the underlying books.
