# D80 category and homological methods capability packet

Open docs/backend/d80/D80.html for the learner route and
docs/backend/d80/D80-pengajar.html for the aligned educator view.

Rebuild and validate with Python 3 from this archive root:

    python -B scripts/build_d80_capability_v1.py --native-root native
    python -B scripts/validate_d80_capability_v1.py --native-root native

The packet contains the 20 exact frozen native inputs needed for replay, the
146 translated-source unit identities, two separately attributed independent
mastery bridges, all eleven negative fixtures, and the generated thin adapter.
It preserves the 50 superseded checkpoint hashes and the malformed 67-character
historical value rather than treating them as current target identities.

This packet does not claim native static MathML, WCAG conformance, source-book
solutions, a deterministic replay of the native TeX build, or completion of the
40-role program backend. The original producer repository and public editions
remain authoritative for the book itself.
