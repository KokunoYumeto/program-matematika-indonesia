# B80 learning capability preservation packet

Open docs/backend/b80/B80.html for the Indonesian exercise map, or
docs/backend/b80/B80-pengajar.html for the teacher view. The lesson links open
the public native book; this is not a copy of that book or its Python runtime.

Rebuild from this archive root with Node 22 and Python plus jsonschema 4.26.0:

    node scripts/build-b80-capability-v1.mjs
    python -B scripts/validate-b80-capability-v1.py

All frozen metadata, schemas and tests needed for the adapter are included.
docs/id/index.html is the central course-link fixture, not a complete offline
copy of the multilingual program. The adapter is course-learning-capability/1,
not an assertion of contract-2.3.1 conformance or new textbook translation.

The full program-wide modular backend remains unfinished. This packet is one
verified increment in its existing GitHub and Zenodo preservation lineages.
