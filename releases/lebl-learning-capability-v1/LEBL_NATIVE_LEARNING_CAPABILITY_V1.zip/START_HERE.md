# Lebl learner and teacher capability packet

Open docs/backend/lebl/B70.html, C10.html, C20.html or C50.html.
Use the matching -pengajar.html page for teacher plans, and istilah.html for
terminology. Books remain external; download linked PDFs separately.

Rebuild with Node 22 and Python plus jsonschema from this archive root:

    node scripts/build-lebl-capability-v1.mjs
    python -B scripts/validate-lebl-capability-v1.py

Frozen metadata, source binding, schemas and tests are included. The two parent
navigation HTML files are link fixtures, not a complete offline curriculum.
See the adapter README for scope, provenance, design and preserved limitations.
This does not claim full native replay or completion of the 40-role backend.
