# C90 Topology learner and educator capability packet

Open docs/backend/topology/C90.html for the course route. Use latihan.html for
the 1,227 staged support and mastery records, pengajar.html to assemble an
educator activity packet, istilah.html for terminology, and catatan.html for
corrections, rights, accessibility, and release boundaries.

Rebuild with Node 22 and Python plus jsonschema from this archive root:

    python -B scripts/build-topology-capability-v1.py
    python -B scripts/validate-topology-capability-v1.py

The frozen native metadata, all 4,908 staged destination byte identities,
schema, controls, and negative fixtures are included. The original reader
remains externally linked and is not duplicated here. See the adapter README
for scope and preserved limitations. This packet does not claim completion of
the 40-role backend or a new human, linguistic, mathematical, or accessibility
certification of the underlying book.
