export const courses = [
  {
    id: 'A00', ownerLane: 'R001', level: 'A', topic: 'Fondasi & Kalkulus', state: 'published',
    title: 'Praaljabar dan Fondasi Kuantitatif', prerequisites: [],
    purpose: 'Bilangan bulat, pecahan, desimal, persen, rasio, pengukuran, dan persamaan dasar dengan jalur diagnosis yang dapat dilewati.',
    outcome: 'Mengolah representasi numerik dengan andal dan mengenali apakah kesalahan berikutnya bersifat aritmetis atau konseptual.',
    corpus: 'OpenStax Prealgebra 2e — edisi Bahasa Indonesia lengkap',
    note: 'Selesai dan terverifikasi publik: 75/75 referensi sumber, pembaca PDF 3.016 halaman, reader HTML responsif, dan backend deterministik 519.678 rekaman. Item Figshare opsional tetap diblokir oleh akun layanan yang tidak aktif; Zenodo dan GitHub tidak terpengaruh.',
    reader: 'https://kokunoyumeto.github.io/openstax-prealgebra-2e-id-ID/',
    edition: 'https://zenodo.org/records/22070683/files/prealgebra-2e-id-ID-v0.2.7-reader.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/openstax-prealgebra-2e-id-ID',
    zenodo: 'https://doi.org/10.5281/zenodo.22070683'
  },
  {
    id: 'A10', ownerLane: 'OPENSTAX-ELEMENTARY', level: 'A', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Aljabar Dasar', prerequisites: ['A00'],
    purpose: 'Persamaan dan pertidaksamaan linear, grafik, sistem, eksponen, polinom, faktorisasi, bentuk rasional, dan akar.',
    outcome: 'Menerjemahkan hubungan kuantitatif ke bentuk aljabar dan menyelesaikannya dengan langkah yang dapat dijelaskan.',
    corpus: 'OpenStax Elementary Algebra 2e — 82 modul', note: 'Korpus terpilih; produksi masih pada tahap awal.'
  },
  {
    id: 'A20', ownerLane: 'OPENSTAX-INTERMEDIATE', level: 'A', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Aljabar Menengah', prerequisites: ['A10'],
    purpose: 'Fungsi, model kuadrat dan rasional, akar, bilangan kompleks, eksponensial, logaritma, irisan kerucut, dan barisan.',
    outcome: 'Memasuki prakalkulus dengan kefasihan simbolik dan pemahaman fungsi yang stabil.',
    corpus: 'OpenStax Intermediate Algebra 2e — 83 modul', note: 'Korpus terpilih; produksi berada pada batas 39/83 modul dan QA terminologi untuk m81389 sedang ditutup.'
  },
  {
    id: 'A30', ownerLane: 'R002', level: 'A', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Prakalkulus dan Trigonometri', prerequisites: ['A20'],
    purpose: 'Transformasi fungsi, model polinom, rasional, eksponensial dan logaritmik, trigonometri, geometri analitik, sistem, barisan, dan limit awal.',
    outcome: 'Memodelkan dengan fungsi elementer dan memulai kalkulus tanpa menyembunyikan kebutuhan perbaikan aljabar.',
    corpus: 'OpenStax Precalculus 2e', note: 'Korpus terpilih; fondasi modular enam modul sudah lolos audit byte. Paket pembantu HP-A30-001 berstatus manager-clean untuk lima unit m49369, m49371, m49372, m49374, dan m49384; paket menunggu QA pemilik kanonik (owner-QA) dan integrasi tiga-arah, serta belum terintegrasi atau diterbitkan.'
  },
  {
    id: 'B10', ownerLane: 'R004', level: 'B', topic: 'Diskrit & Logika', state: 'published',
    title: 'Pembuktian, Logika, dan Struktur Diskrit', prerequisites: ['A30'],
    purpose: 'Logika proposisional dan predikat, himpunan, fungsi, relasi, teknik bukti, teori graf, pencacahan, dan barisan.',
    outcome: 'Membaca, menyusun, dan mengkritik bukti elementer sebelum memasuki teori tingkat lanjut.',
    corpus: 'Discrete Mathematics: An Open Introduction 4', note: 'Edisi Bahasa Indonesia selesai dan rilis preservasi 2026.08.22 telah diverifikasi publik.',
    reader: 'https://kokunoyumeto.github.io/discrete-mathematics-open-introduction-id/',
    edition: 'https://zenodo.org/records/22060439/files/00_MATEMATIKA_DISKRET_EDISI_KEEMPAT_BAHASA_INDONESIA_READER.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/discrete-mathematics-open-introduction-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22060439'
  },
  {
    id: 'B20', ownerLane: 'R003', level: 'B', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Kalkulus Diferensial', prerequisites: ['A30'],
    purpose: 'Limit, kontinuitas, turunan, pendekatan, optimisasi, dan pemodelan dengan masalah terpecahkan yang terintegrasi.',
    outcome: 'Menggunakan turunan secara komputasional dan konseptual serta menjelaskan hipotesis yang dipakai.',
    corpus: 'CLP Calculus — kalkulus diferensial', note: 'Korpus terpilih; pemetaan latihan dan backend sedang dibangun.',
    repository: 'https://github.com/KokunoYumeto/clp1-differential-calculus-id'
  },
  {
    id: 'B30', ownerLane: 'R003', level: 'B', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Kalkulus Integral', prerequisites: ['B20'],
    purpose: 'Integral, teorema dasar kalkulus, teknik integrasi, penerapan, barisan, deret, dan persamaan diferensial awal.',
    outcome: 'Memilih dan membenarkan metode integral atau deret serta menghubungkan akumulasi dengan laju lokal.',
    corpus: 'CLP Calculus — kalkulus integral',
    note: 'Checkpoint publik CLP-2 WIP.9/CP0047-R1 memuat pembaca 674 halaman, SHA-256 863e9c5709ff961b3ba09f93da973a8188849d81a4e9680900e1d66a58232bd6. Backend 105.047 rekaman dapat direproduksi persis dan paket HP-CLP2-001/002 telah diterima; R003 tetap belum lengkap.',
    edition: 'https://zenodo.org/records/22077325/files/CLP-2_Kalkulus_Integral_Bahasa_Indonesia_checkpoint_2026-08-24_s2.1.pdf?download=1',
    zenodo: 'https://doi.org/10.5281/zenodo.22077325'
  },
  {
    id: 'B40', ownerLane: 'R005', level: 'B', topic: 'Aljabar', state: 'published',
    title: 'Aljabar Linear', prerequisites: ['A30', 'B10'],
    purpose: 'Sistem linear, ruang vektor, pemetaan linear, matriks, determinan, nilai dan vektor eigen, serta penerapan.',
    outcome: 'Berpindah dengan lancar antara perhitungan, struktur, dan pembuktian dalam matematika berdimensi hingga.',
    corpus: 'Hefferon — Linear Algebra lengkap',
    note: 'Edisi Bahasa Indonesia lengkap dan terverifikasi publik: buku 580 halaman, jawaban bekerja 435 halaman, laboratorium Sage 109 halaman, dan pembaca kumulatif 1.124 halaman.',
    reader: 'https://kokunoyumeto.github.io/hefferon-linear-algebra-id/',
    edition: 'https://zenodo.org/records/22070458',
    repository: 'https://github.com/KokunoYumeto/hefferon-linear-algebra-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22070458'
  },
  {
    id: 'B50', ownerLane: 'R003', level: 'B', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Kalkulus Multivariabel', prerequisites: ['B30', 'B40'],
    purpose: 'Geometri beberapa variabel, turunan parsial, integral lipat, optimisasi berkendala, dan sistem koordinat.',
    outcome: 'Menganalisis fungsi skalar multivariabel dan menghubungkan linearisasi lokal dengan geometri.',
    corpus: 'CLP Calculus — kalkulus multivariabel', note: 'Korpus terpilih dalam jalur produksi CLP bersama.'
  },
  {
    id: 'B60', ownerLane: 'R003', level: 'B', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Kalkulus Vektor', prerequisites: ['B50'],
    purpose: 'Medan vektor, integral garis dan permukaan, serta teorema Green, Stokes, dan divergensi.',
    outcome: 'Menafsirkan teorema integral utama yang menghubungkan struktur diferensial lokal dengan besaran global.',
    corpus: 'CLP Calculus — kalkulus vektor', note: 'Korpus terpilih dalam jalur produksi CLP bersama.'
  },
  {
    id: 'B70', ownerLane: 'R006-R008', level: 'B', topic: 'Fondasi & Kalkulus', state: 'production',
    title: 'Persamaan Diferensial Biasa dan Sistem Dinamika Pengantar', prerequisites: ['B30', 'B40'],
    purpose: 'Persamaan orde satu, persamaan linear orde tinggi, sistem, transformasi, deret, bidang fase nonlinear, dan pengantar Fourier/PDP.',
    outcome: 'Merumuskan, menganalisis, mendekati, dan mengomunikasikan solusi model PDB standar.',
    corpus: 'Korpus keluarga Lebl',
    note: 'Checkpoint publik U336 memuat 15 unit R007 sampai rumus integral tentu untuk masalah nilai awal. Korpus ODE tetap belum lengkap dan belum memiliki pembaca mandiri.',
    edition: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id/releases/tag/lebl-family-id-wip.2026.08.24.u336',
    repository: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22082567'
  },
  {
    id: 'B80', ownerLane: 'O002', level: 'B', topic: 'Komputasi & Optimisasi', state: 'published',
    title: 'Komputasi Matematis dan Eksperimen Reprodusibel', prerequisites: ['A30'],
    purpose: 'Python, SageMath, SymPy, NumPy/SciPy, komputasi eksak dan floating, visualisasi, pengujian, notebook literat, serta eksperimen reprodusibel.',
    outcome: 'Menerapkan objek dan eksperimen matematis sambil membedakan komputasi, bukti pendukung, dan pembuktian.',
    corpus: 'Rangka asli lengkap: P01/P02 + 12 unit, SciPy, SageMath, visualisasi, lingkungan, dan penguasaan',
    note: 'Edisi B80 lengkap dan terverifikasi publik: 14 unit, 75 latihan, 177 uji lulus, pembaca PDF 159 halaman, serta HTML, EPUB, sumber editabel, dan paket luring.',
    reader: 'https://kokunoyumeto.github.io/mathematical-computing-reproducible-experiments-id/',
    edition: 'https://zenodo.org/records/22053905/files/Komputasi-Matematis-dan-Eksperimen-yang-Dapat-Direproduksi.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/mathematical-computing-reproducible-experiments-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22053905'
  },
  {
    id: 'B90', ownerLane: 'R010', level: 'B', topic: 'Peluang & Statistika', state: 'published',
    title: 'Probabilitas Berbasis Kalkulus', prerequisites: ['B30'],
    purpose: 'Probabilitas diskrit dan kontinu, probabilitas bersyarat, peubah acak, harapan, limit, simulasi, jalan acak, dan rantai Markov.',
    outcome: 'Membangun dan menganalisis model peluang serta menghubungkan hasil analitik dengan simulasi.',
    corpus: 'Grinstead–Snell', note: 'Edisi 554 halaman selesai; backend modular berada dalam edisi kursus yang sama.',
    reader: 'https://kokunoyumeto.github.io/introduction-to-probability-id/',
    edition: 'https://zenodo.org/records/22062144/files/PENGANTAR_PELUANG_GRINSTEAD_SNELL_ID.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/introduction-to-probability-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22062144'
  },
  {
    id: 'B95', ownerLane: 'R011', level: 'B', topic: 'Peluang & Statistika', state: 'production',
    title: 'Statistika Terapan dan Analisis Data', prerequisites: ['A30', 'B90'],
    purpose: 'Pengumpulan data, deskripsi, ketidakpastian, inferensi, eksperimen, regresi, dan analisis reprodusibel dengan perangkat lunak terbuka.',
    outcome: 'Mengkritik proses pembentukan data dan melakukan analisis statistik awal secara transparan.',
    corpus: 'OpenIntro Statistics', note: 'Korpus terpilih; produksi berlanjut pada Bagian 3.2 setelah checkpoint B009 terverifikasi.'
  },
  {
    id: 'C10', ownerLane: 'R006-R008', level: 'C', topic: 'Analisis', state: 'published',
    title: 'Analisis Real I', prerequisites: ['B10', 'B30'],
    purpose: 'Bilangan real, barisan, deret, kontinuitas, diferensiasi, dan integrasi Riemann dengan penekanan pada bukti.',
    outcome: 'Mengendalikan kuantor dan menyusun argumen rigor tentang limit, kontinuitas, turunan, dan integral.',
    corpus: 'Lebl — Basic Analysis, Volume I',
    note: 'Jilid I lengkap, 334 halaman, dan tetap terverifikasi publik di U336; keluarga Lebl memuat 336 unit: R006 271, R007 15, dan R008 50.',
    edition: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id/releases/tag/lebl-family-id-wip.2026.08.24.u336',
    repository: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22082567'
  },
  {
    id: 'C20', ownerLane: 'R006-R008', level: 'C', topic: 'Analisis', state: 'production',
    title: 'Analisis Real II', prerequisites: ['C10', 'B50'],
    purpose: 'Barisan fungsi, ruang metrik, diferensiasi dan integrasi multivariabel, serta konstruksi limit.',
    outcome: 'Bekerja fasih dengan abstraksi ruang metrik dan bukti analitik multivariabel.',
    corpus: 'Lebl — Basic Analysis, Volume II',
    note: 'Checkpoint publik U336 memuat pembaca Jilid II 198 halaman sampai akhir Bagian 11.4, termasuk semua 11 latihan; SHA-256 78543d4e8087e68589e8f15d0a3a969b3282247c7c9c2cdcb6f658dfa4b68e4f. Ini tetap pekerjaan berjalan, bukan edisi lengkap C20.',
    edition: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id/releases/tag/lebl-family-id-wip.2026.08.24.u336',
    repository: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22082567'
  },
  {
    id: 'C30', ownerLane: 'R009', level: 'C', topic: 'Aljabar', state: 'published',
    title: 'Aljabar Abstrak I', prerequisites: ['B10', 'B40'],
    purpose: 'Grup, subgrup, homomorfisme, struktur hasil bagi, aksi grup, dan penerapan simetri.',
    outcome: 'Bernalar secara struktural dengan objek aljabar dan membuktikan hasil dari aksioma.',
    corpus: 'Judson — Abstract Algebra: Theory and Applications', note: 'Edisi Bahasa Indonesia selesai dan tersedia untuk umum.',
    reader: 'https://kokunoyumeto.github.io/abstract-algebra-theory-and-applications-id/',
    edition: 'https://zenodo.org/records/22062449/files/ALJABAR_ABSTRAK_TEORI_DAN_PENERAPAN_ID_2026.08.22.2.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/abstract-algebra-theory-and-applications-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22062449'
  },
  {
    id: 'C40', ownerLane: 'R009', level: 'C', topic: 'Aljabar', state: 'published',
    title: 'Aljabar Abstrak II', prerequisites: ['C30'],
    purpose: 'Gelanggang, ideal, gelanggang hasil bagi, domain integral, polinom, medan, perluasan, dan teori Galois awal.',
    outcome: 'Menggunakan struktur aljabar untuk menganalisis persamaan, faktorisasi, dan perluasan medan.',
    corpus: 'Judson — Abstract Algebra: Theory and Applications', note: 'Selesai dalam edisi Judson Bahasa Indonesia yang sama.',
    reader: 'https://kokunoyumeto.github.io/abstract-algebra-theory-and-applications-id/',
    edition: 'https://zenodo.org/records/22062449/files/ALJABAR_ABSTRAK_TEORI_DAN_PENERAPAN_ID_2026.08.22.2.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/abstract-algebra-theory-and-applications-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22062449'
  },
  {
    id: 'C50', ownerLane: 'R006-R008', level: 'C', topic: 'Analisis', state: 'production',
    title: 'Analisis Kompleks', prerequisites: ['C20'],
    purpose: 'Fungsi holomorf, integrasi kontur, teori Cauchy, residu, keluarga normal, pemetaan konformal, fungsi harmonik, dan kelanjutan analitik.',
    outcome: 'Membaca dan menghasilkan pembuktian analisis kompleks pada tingkat masuk pascasarjana.',
    corpus: 'Korpus analisis kompleks Lebl',
    note: 'Checkpoint publik U336 memuat 50 unit R008 sampai akhir bagian bola Riemann. Korpus Analisis Kompleks tetap belum lengkap dan belum memiliki pembaca mandiri.',
    edition: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id/releases/tag/lebl-family-id-wip.2026.08.24.u336',
    repository: 'https://github.com/KokunoYumeto/lebl-mathematics-family-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22082567'
  },
  {
    id: 'C60', ownerLane: 'R014', level: 'C', topic: 'Diskrit & Logika', state: 'published',
    title: 'Teori Bilangan dan Kriptologi', prerequisites: ['B10', 'C30'],
    purpose: 'Keterbagian, kongruensi, bilangan prima, fungsi aritmetika, masalah Diophantus, dan konstruksi kriptografi kunci publik.',
    outcome: 'Membuktikan hasil teori bilangan elementer dan menganalisis asumsi matematika di balik kriptosistem dasar.',
    corpus: 'Jonathan Poritz — Yet Another Introductory Number Theory Textbook',
    note: 'Edisi Bahasa Indonesia lengkap dan terverifikasi publik: 138 halaman, 5.272 rekaman native, dan cakupan hingga kriptografi kunci publik. Pendamping penguasaan tetap merupakan penutupan terpilih untuk keterbatasan solusi sumber dan dilacak terpisah dari selesainya terjemahan buku.',
    reader: 'https://kokunoyumeto.github.io/yet-another-introductory-number-theory-textbook-id/',
    edition: 'https://github.com/KokunoYumeto/yet-another-introductory-number-theory-textbook-id/releases/tag/v1.0.0',
    repository: 'https://github.com/KokunoYumeto/yet-another-introductory-number-theory-textbook-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22052196'
  },
  {
    id: 'C70', ownerLane: 'R012', level: 'C', topic: 'Diskrit & Logika', state: 'published',
    title: 'Kombinatorika Terapan', prerequisites: ['B10'],
    purpose: 'Pencacahan lanjut, rekurensi, fungsi pembangkit, teori graf, himpunan terurut sebagian, dan metode ekstremal.',
    outcome: 'Memilih dan membenarkan model serta teknik pembuktian kombinatorial untuk berbagai masalah diskrit.',
    corpus: 'Keller–Trotter — Applied Combinatorics', note: 'Edisi Bahasa Indonesia lengkap dan terverifikasi publik: pembaca 350 halaman, 19.048 rekaman native, 19.049 rekaman backend bersama termasuk satu jangkar prasyarat eksternal B10, HTML luring, sumber koresponding, dan tiga mirror preservasi.',
    reader: 'https://kokunoyumeto.github.io/applied-combinatorics-id/',
    edition: 'https://zenodo.org/records/22062005/files/00_KOMBINATORIKA_TERAPAN_ID-ID_COMPLETE_LINKED_READER_2026.08.22.2.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/applied-combinatorics-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22062005'
  },
  {
    id: 'C80', ownerLane: 'R013', level: 'C', topic: 'Diskrit & Logika', state: 'published',
    title: 'Logika Matematis, Teori Himpunan, dan Komputabilitas', prerequisites: ['B10'],
    purpose: 'Bahasa dan semantik formal, sistem bukti, ketaklengkapan, fondasi komputabilitas, teori himpunan aksiomatik, dan teori model awal.',
    outcome: 'Memahami batas formal dan kerangka fondasional dalam praktik matematika biasa.',
    corpus: 'Open Logic Project — OLP-0722, 722/722 modul', note: 'Edisi Bahasa Indonesia lengkap dan diterbitkan dengan lisensi CC BY 4.0.',
    edition: 'https://zenodo.org/records/21932787/files/00_OPENLOGIC_id_COMPLETE_LINKED_READER_OLP-0722.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/OpenLogic-id',
    zenodo: 'https://doi.org/10.5281/zenodo.21932787'
  },
  {
    id: 'C90', ownerLane: 'O003', level: 'C', topic: 'Geometri & Topologi', state: 'production',
    title: 'Topologi Himpunan-Titik', prerequisites: ['B10', 'C10'],
    purpose: 'Ruang topologis, basis, kontinuitas, produk dan hasil bagi, kekompakan, keterhubungan, aksioma pemisahan, keterhitungan, metrisasi, dan ruang fungsi.',
    outcome: 'Menggunakan invarian dan konstruksi topologis sebagai bahasa bersama analisis, geometri, dan aljabar.',
    corpus: 'GVSU Topology lengkap + pendamping PreTeXt asli', note: 'Korpus terpilih dan diserahkan; dukungan respons pembelajar Bab 12 sedang diproduksi setelah sensus dikoreksi menjadi 79 unit.',
    repository: 'https://github.com/KokunoYumeto/topology-an-inquiry-based-approach-id'
  },
  {
    id: 'C100', ownerLane: 'O004', level: 'C', topic: 'Geometri & Topologi', state: 'production',
    title: 'Geometri: Euklides, Afin, Projektif, dan Non-Euklides', prerequisites: ['B10', 'B40', 'B60'],
    purpose: 'Geometri aksiomatik dan transformasional, metode afin dan projektif, geometri hiperbolik dan sferis, permukaan, dan konstruksi.',
    outcome: 'Membandingkan geometri melalui aksioma, transformasi, dan invarian, bukan sebagai satu konvensi tunggal.',
    corpus: 'Petrunin sebagai donor utama yang sah untuk buku kursus asli CC BY-SA + Clemens/Snapp sebagai pendamping terpisah berlisensi CC BY-NC-SA/GPL',
    note: 'Arsitektur sumber dipilih. Sintesis asli geometri afin, projektif, dan non-Euklides, perbaikan rigor, aset bersih, solusi, dan asesmen masih harus diselesaikan; pendamping Clemens/Snapp tetap dikemas terpisah agar hak komponennya tidak disamarkan.'
  },
  {
    id: 'C110', ownerLane: 'R015', level: 'C', topic: 'Komputasi & Optimisasi', state: 'published',
    title: 'Analisis Numerik', prerequisites: ['B30', 'B40', 'B80', 'C10'],
    purpose: 'Galat floating-point, pencarian akar, interpolasi, pendekatan, diferensiasi dan integrasi numerik, serta aljabar linear numerik.',
    outcome: 'Menurunkan, menerapkan, dan menilai algoritma numerik dengan alasan stabilitas dan galat yang eksplisit.',
    corpus: 'Tea Time Numerical Analysis — edisi Bahasa Indonesia lengkap',
    note: 'Selesai dan terverifikasi publik: 31/31 unit, pembaca 387 halaman, 28.172 rekaman backend, 17.614 relasi, dan 20/20 uji akhir. Arsip Zenodo tetap publik; akses akun GitHub telah dipulihkan dan sinkronisasi mirror kembali dimungkinkan.',
    edition: 'https://zenodo.org/records/22054086/files/Tea-Time-Numerical-Analysis-id-ID.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/tea-time-numerical-analysis-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22054086'
  },
  {
    id: 'C120', ownerLane: 'O005', level: 'C', topic: 'Komputasi & Optimisasi', state: 'published',
    title: 'Pemodelan Matematis dan Dinamika Nonlinear', prerequisites: ['B70', 'B80', 'C10'],
    purpose: 'Analisis dimensi, konstruksi dan validasi model, sistem dinamis diskrit/kontinu, bifurkasi, chaos, dan studi kasus.',
    outcome: 'Bergerak iteratif antara asumsi, struktur matematika, komputasi, data, dan kritik model.',
    corpus: 'Lega v1.01 plus jembatan komputasi dan penguasaan — edisi Bahasa Indonesia lengkap',
    note: 'Selesai dan terverifikasi publik: 22 unit sumber plus 4 jembatan, 4.105 segmen, 141 rekaman penguasaan, 26 notebook, 12 paket proyek, dan pembaca PDF 355 halaman.',
    reader: 'https://kokunoyumeto.github.io/mathematical-modeling-nonlinear-dynamics-id/',
    edition: 'https://zenodo.org/records/22070943/files/01_Pengantar_Pemodelan_Matematika_Edisi_Bahasa_Indonesia_Lengkap.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/mathematical-modeling-nonlinear-dynamics-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22070943'
  },
  {
    id: 'C130', ownerLane: 'O018', level: 'C', topic: 'Komputasi & Optimisasi', state: 'published',
    title: 'Optimisasi Linear dan Integer / Riset Operasi', prerequisites: ['B40', 'B80', 'C70'],
    purpose: 'Program linear, dualitas, konsep simpleks/interior, jaringan, program integer, kompleksitas, pemodelan, dan implementasi dengan solver bebas.',
    outcome: 'Merumuskan, menyelesaikan, dan mengkritik model optimisasi tanpa bergantung pada solver proprieter.',
    corpus: 'Open Optimization Book 1 plus laboratorium Pyomo/HiGHS O018 — edisi Bahasa Indonesia lengkap',
    note: 'Selesai dan terverifikasi publik: pembaca 666 halaman, 1.993 unit, 5.525 segmen, 9.545 relasi, backend deterministik 32 berkas, dan laboratorium solver terbuka yang diatribusikan terpisah.',
    reader: 'https://kokunoyumeto.github.io/open-optimization-or-book-id/',
    edition: 'https://zenodo.org/records/22070653/files/pemrograman-matematis-dan-riset-operasi-buku-1-id-ID.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/open-optimization-or-book-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22070653'
  },
  {
    id: 'C140', ownerLane: 'O006', level: 'C', topic: 'Peluang & Statistika', state: 'production',
    title: 'Statistika Matematis', prerequisites: ['B90', 'B95', 'B40', 'C10'],
    purpose: 'Distribusi sampling, kecukupan, estimasi, likelihood, interval kepercayaan, uji hipotesis, perbandingan Bayes, regresi, dan asimtotik.',
    outcome: 'Menurunkan dan menilai prosedur statistik, bukan sekadar menerapkannya sebagai kotak hitam.',
    corpus: 'Penn State STAT 415 lengkap + satu unit Random tentang kecukupan/kelengkapan + pendamping rigor dan penguasaan asli',
    note: 'Checkpoint pendukung Random 16 dari 29 unit sudah publik. Edisi Random penuh, spine Penn State, dan pendamping rigor/penguasaan asli tetap belum selesai; C140 tidak diklaim sebagai edisi lengkap.',
    edition: 'https://zenodo.org/records/22071140/files/00_statistika-matematis-id-reader-2026.08.23.16.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/mathematical-statistics-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22071140'
  },
  {
    id: 'D10', ownerLane: 'O007', level: 'D', topic: 'Analisis', state: 'production',
    title: 'Ukuran dan Integrasi', prerequisites: ['C20', 'C90'],
    purpose: 'Sigma-aljabar, ukuran, fungsi terukur, integral Lebesgue, teorema konvergensi, ukuran produk, Radon–Nikodym, dan ruang Lp.',
    outcome: 'Menggunakan teori integrasi modern sebagai dasar peluang, analisis fungsional, dan PDP.',
    corpus: 'Fremlin — Measure Theory Jilid 1–2', note: 'Korpus terpilih; batch setingkat bab mt133–mt136 sedang ditutup.',
    repository: 'https://github.com/KokunoYumeto/fremlin-measure-theory-id'
  },
  {
    id: 'D20', ownerLane: 'O008', level: 'D', topic: 'Analisis', state: 'production',
    title: 'Analisis Fungsional', prerequisites: ['D10', 'B40'],
    purpose: 'Ruang bernorma, Banach dan Hilbert; operator terbatas; Hahn–Banach; boundedness seragam; pemetaan terbuka; dualitas; teori kompak dan spektral.',
    outcome: 'Bernalar dengan ruang dan operator berdimensi tak hingga pada tingkat pascasarjana awal.',
    corpus: 'Erdman — Functional Analysis',
    note: 'Pembaca kumulatif Bab 1–12 sepanjang 179 halaman sudah terverifikasi publik. Produksi berlanjut ke Bab 13; korpus lengkap D20 belum selesai.',
    edition: 'https://zenodo.org/records/22072541/files/analisis-fungsional-dan-aljabar-operator-id-bab-1-12.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/functional-analysis-erdman-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22072541'
  },
  {
    id: 'D30', ownerLane: 'O009', level: 'D', topic: 'Peluang & Statistika', state: 'production',
    title: 'Probabilitas Teoretis-Ukuran dan Proses Stokastik', prerequisites: ['D10', 'B90', 'C140'],
    purpose: 'Ruang peluang, modus konvergensi, hukum bilangan besar, limit pusat, harapan bersyarat, martingal, proses Markov/Poisson, dan gerak Brown.',
    outcome: 'Membaca literatur peluang modern dan proses stokastik dengan kefasihan teori ukuran.',
    corpus: '27 halaman semantik Random + QuantEcon — Continuous Time Markov Chains (100 hlm.) + 2 irisan laboratorium Žitković + penutupan asli',
    note: 'Checkpoint publik 20 memuat pembaca kumulatif 223 halaman dan 26 halaman HTML termanifestasi. Tiga dari delapan bab QuantEcon sudah selesai; lima bab, jembatan Random/Brownian terpilih, dan penutupan asli masih diproduksi.',
    edition: 'https://zenodo.org/api/records/22074332/files/00_PROBABILITAS_TEORI_UKURAN_PROSES_STOKASTIK_ID_READER_CHECKPOINT_20.pdf/content',
    repository: 'https://github.com/KokunoYumeto/measure-theoretic-probability-stochastic-processes-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22074332'
  },
  {
    id: 'D40', ownerLane: 'O010', level: 'D', topic: 'Analisis', state: 'production',
    title: 'Persamaan Diferensial Parsial', prerequisites: ['B70', 'C110', 'D10', 'D20'],
    purpose: 'Persamaan orde satu dan dua klasik, distribusi, ruang Sobolev, solusi lemah, metode energi dan Fourier, serta titik kontak numerik.',
    outcome: 'Mengenali tipe PDP, membuktikan hasil dasar, dan membedakan solusi klasik, lemah, serta numerik.',
    corpus: 'Dionne — Partial Differential Equations lengkap + 8 simpul FEniCSx (7 wajib + 1 pengayaan) + penutupan soal, asesmen, dan laboratorium asli',
    note: 'Unit 09 Dionne telah terbit dan terverifikasi sebagai pembaca kumulatif 77 halaman, 4.414.297 byte, SHA-256 f2869bc0c38153d2223a03e8dccc85c306cefdc4eea15f9fe6a560a6d1f7ce91. Bab klasifikasi selesai pada batas publik ini; Dionne, irisan FEniCSx, dan penutupan asli tetap diproduksi.',
    edition: 'https://zenodo.org/records/22086227/files/PERSAMAAN_DIFERENSIAL_PARSIAL_DIONNE_ID_UNIT_09.pdf?download=1',
    zenodo: 'https://doi.org/10.5281/zenodo.22086227'
  },
  {
    id: 'D50', ownerLane: 'O011', level: 'D', topic: 'Geometri & Topologi', state: 'production',
    title: 'Lipatan Mulus dan Geometri Diferensial', prerequisites: ['C90', 'B60', 'C30'],
    purpose: 'Lipatan, struktur tangen dan kotangen, bentuk diferensial, integrasi dan Stokes, grup Lie, metrik Riemann, koneksi, dan kelengkungan.',
    outcome: 'Menggunakan bahasa geometri bebas koordinat dan membuktikan hasil dasar tentang lipatan serta kelengkungan.',
    corpus: 'Brenner lengkap — 29 kuliah + 29 lembar kerja; dua jembatan asli grup Lie/de Rham; bank 10 ujian resmi',
    note: 'Unit 10 telah terbit dan terverifikasi sebagai pembaca kumulatif 165 halaman. Unit 11–13 sudah selesai terjemahan dan QA berbatas tetapi belum diterbitkan; dua jembatan dan penutupan asesmen menyusul.',
    edition: 'https://zenodo.org/api/records/22073928/files/geometri-diferensial-manifold-mulus-hingga-unit-10-id.pdf/content',
    zenodo: 'https://doi.org/10.5281/zenodo.22073928'
  },
  {
    id: 'D60', ownerLane: 'O012', level: 'D', topic: 'Geometri & Topologi', state: 'production',
    title: 'Topologi Aljabar', prerequisites: ['C90', 'C30'],
    purpose: 'Grup fundamental, ruang penutup, homologi simplisial/seluler, kohomologi, barisan eksak, derajat, dan metode homotopi terpilih.',
    outcome: 'Menerjemahkan pertanyaan geometri menjadi invarian aljabar yang dapat dihitung dan merekonstruksi bukti standar.',
    corpus: 'Roberts lengkap (30 kuliah) + jembatan homologi Fomberg §§1.1–1.13 + penutupan bukti, solusi, dan laboratorium asli',
    note: 'Batas publik mencakup Roberts Kuliah 1–30 lengkap dan jembatan Fomberg §§1.1–1.2 dalam pembaca 362 halaman, 2.322.978 byte, SHA-256 fb81f2b2c0f73c17c4e3be4eaae164eaeaeb0c4ff0661580acfc7aa9b6d5f749. Sisa jembatan Fomberg dan penutupan bukti, solusi, serta laboratorium asli masih diproduksi.',
    edition: 'https://zenodo.org/api/records/22084021/files/00_TOPOLOGI_ALJABAR_ID_ROBERTS_001_030_FOMBERG_001_READER.pdf/content',
    repository: 'https://github.com/KokunoYumeto/algebraic-topology-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22084021'
  },
  {
    id: 'D70', ownerLane: 'O013', level: 'D', topic: 'Aljabar', state: 'production',
    title: 'Aljabar Pascasarjana', prerequisites: ['C40', 'B40'],
    purpose: 'Modul, hasil kali tensor, barisan eksak, teori medan/Galois lanjut, aljabar komutatif, teori representasi, dan struktur untuk geometri/topologi.',
    outcome: 'Memasuki literatur aljabar pascasarjana dengan penguasaan konstruksi universal dan bukti struktural.',
    corpus: 'Wen-Wei Li Jilid 1 lengkap + TeX teori representasi Alexander Duncan berlisensi CC BY 4.0 + enam rentang CRing/GFDL berbatas + lapisan penghubung dan solusi asli',
    note: 'Arsitektur sumber dipilih dan digunakan oleh pemilik produksi. Etingof/MIT tetap referensi saja; lembar tugas eksternal dikecualikan dari korpus yang diterima.',
    repository: 'https://github.com/KokunoYumeto/metode-aljabar-jilid-1-id'
  },
  {
    id: 'D80', ownerLane: 'O014', level: 'D', topic: 'Aljabar', state: 'production',
    title: 'Teori Kategori dan Metode Homologis', prerequisites: ['C30', 'C80'],
    purpose: 'Kategori, funktor, transformasi natural, limit/kolimit, adjungsi, representabilitas, kategori abelian, kompleks rantai, funktor turunan, dan orientasi barisan spektral.',
    outcome: 'Menggunakan bahasa kategoris sebagai matematika kerja, bukan hiasan abstrak.',
    corpus: 'Li — Methods of Algebra Volume 2 lengkap', note: 'Korpus terpilih dan diakui; produksi unit sedang berjalan.'
  },
  {
    id: 'D90', ownerLane: 'O015', level: 'D', topic: 'Komputasi & Optimisasi', state: 'production',
    title: 'Optimisasi Lanjut dan Analisis Konveks', prerequisites: ['C110', 'C130', 'D20'],
    purpose: 'Himpunan dan fungsi konveks, separasi, dualitas, KKT, algoritma, metode nonsmooth, optimisasi stokastik, dan sudut pandang variasional.',
    outcome: 'Menganalisis masalah optimisasi kontinu dan algoritma modern melampaui program linear/integer.',
    corpus: 'Habring arXiv 2607.11664v1 berlisensi CC BY 4.0 sebagai spine TeX kanonik + modul TeX Becker berlisensi MIT + penutupan KKT, stokastik, variasional, dan solusi asli',
    note: 'Arsitektur sumber editabel dipilih. Materi MIT 6.253 dan Royer dipertahankan sebagai pendamping berlisensi terpisah, bukan spine kanonik. Checkpoint pendamping publik terbaru adalah MIT L10, Kuliah 6 halaman 64–85, 10 halaman, SHA-256 3b01d57e8e8a7d7887f36cfdc205d1b68d1d007a152bd8e0cd75479628e1abc0; L11 masih lokal.',
    edition: 'https://zenodo.org/records/22077419/files/D90-MIT-10-kuliah-6-irisan-tertutup-dan-hiperbidang-id.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22077419'
  },
  {
    id: 'D100', ownerLane: 'O016', level: 'D', topic: 'Geometri & Topologi', state: 'production',
    title: 'Jembatan Geometri Aljabar', prerequisites: ['D70', 'D80', 'C90', 'D60'],
    purpose: 'Varietas afin/projektif, gelanggang koordinat, skema, sheaf, morfisme, dimensi, orientasi kohomologis, dan penggunaan terpandu Stacks Project.',
    outcome: 'Berpindah dari aljabar pascasarjana ke geometri aljabar tingkat sumber dan menavigasi korpus rujukan hidup.',
    corpus: 'Brenner Algebraische Kurven lengkap (337 halaman) + Bündel, Garben und Kohomologie lengkap (265 halaman) + penutupan penguasaan dan integrasi asli',
    note: 'Unit 1–15 volume klasik sudah publik dalam pembaca 267 halaman, 6.502.255 byte, SHA-256 e56aae414a9d7e252485d06e7da790fae9bf972514c8fe47fc31d26eddd3699c. Unit 16–18 adalah checkpoint internal, bukan rilis publik; Unit 19 dibekukan tetapi belum didispatch. Stacks tetap rujukan hilir terpandu dan Napkin hanya donor penjelasan opsional.',
    edition: 'https://zenodo.org/records/22077441/files/kurva-aljabar-id-unit-15.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/algebraic-geometry-bridge-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22077441'
  },
  {
    id: 'D110', ownerLane: 'LEAN', level: 'D', topic: 'Praktik Riset', state: 'published',
    title: 'Matematika Terformalisasi dalam Lean', prerequisites: ['B10', 'B40', 'C10', 'C30'],
    purpose: 'Sintaks dan taktik Lean, proposisi dan bukti, himpunan/fungsi, struktur aljabar, contoh topologi/analisis, dan navigasi pustaka.',
    outcome: 'Mengodekan dan memverifikasi matematika nontrivial serta menyumbangkan koreksi atau contoh berbatas.',
    corpus: 'Mathematics in Lean — korpus Lean 4 lengkap',
    note: 'Edisi Bahasa Indonesia v4.30.0-id.3 lengkap dan terverifikasi publik: 219 halaman, 10.978 rekaman backend, build Lean lulus, dan QA terminologi Indonesia berbasis arXiv tercatat.',
    reader: 'https://kokunoyumeto.github.io/mathematics-in-lean-id/',
    edition: 'https://zenodo.org/records/22062017/files/matematika-dalam-lean-bahasa-indonesia.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/mathematics-in-lean-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22062017'
  },
  {
    id: 'D120', ownerLane: 'O017', level: 'D', topic: 'Praktik Riset', state: 'production',
    title: 'Membaca Riset, Eksposisi, dan Kerja Matematis Reprodusibel', prerequisites: ['C20', 'C40', 'B80'],
    purpose: 'Membaca artikel dan monograf, rekonstruksi sumber, sitasi, tulisan ekspositoris, catatan seminar, errata, komputasi reprodusibel, kritik sejawat, dan proyek kontribusi.',
    outcome: 'Berpartisipasi secara konstruktif dalam komunitas matematika sambil menyatakan dependensi, bukti, dan ketidakpastian secara tepat.',
    corpus: 'Kerja Matematika yang Dapat Ditelusuri — rangka asli sembilan unit + donor metodologis Turing Way/PyRSE yang dibekukan',
    note: 'Edisi mandiri 128 halaman sudah publik; handoff penyelesaian akhir masih menunggu pemeriksaan status koleksi Figshare yang sudah ada.',
    edition: 'https://zenodo.org/records/22051978/files/kerja-matematika-yang-dapat-ditelusuri-id-2026.08.22.pdf?download=1',
    repository: 'https://github.com/KokunoYumeto/kerja-matematika-yang-dapat-ditelusuri-id',
    zenodo: 'https://doi.org/10.5281/zenodo.22051978'
  }
];

export const topics = [
  'Fondasi & Kalkulus',
  'Analisis',
  'Aljabar',
  'Geometri & Topologi',
  'Peluang & Statistika',
  'Diskrit & Logika',
  'Komputasi & Optimisasi',
  'Praktik Riset'
];

export const program = Object.freeze({
  id: 'program-matematika-indonesia',
  title: 'Program Matematika Indonesia — Peta Kurikulum Terbuka',
  language: 'id-ID',
  version: '0.52.0',
  snapshotDate: '2026-08-25',
  totalCourseRoles: 40,
  selectedCorpusRoles: 40,
  unresolvedRoleIds: [],
  completedPublicCourseRoleIds: ['A00', 'B10', 'B40', 'B80', 'B90', 'C10', 'C30', 'C40', 'C60', 'C70', 'C80', 'C110', 'C120', 'C130', 'D110'],
  completedPublicRecordDois: [
    '10.5281/zenodo.22070683',
    '10.5281/zenodo.22060439',
    '10.5281/zenodo.22070458',
    '10.5281/zenodo.22053905',
    '10.5281/zenodo.22062144',
    '10.5281/zenodo.22082567',
    '10.5281/zenodo.22062449',
    '10.5281/zenodo.22052196',
    '10.5281/zenodo.22062005',
    '10.5281/zenodo.21932787',
    '10.5281/zenodo.22054086',
    '10.5281/zenodo.22070943',
    '10.5281/zenodo.22070653',
    '10.5281/zenodo.22062017'
  ],
  website: 'https://kokunoyumeto.github.io/program-matematika-indonesia/',
  zenodo: 'https://doi.org/10.5281/zenodo.22088577',
  zenodoConcept: 'https://doi.org/10.5281/zenodo.22059707',
  provenance: {
    model: 'OpenAI Codex gpt-5.6-sol, Ultra',
    role: 'Koordinasi, rekayasa backend, dan penerbitan snapshot pusat atas instruksi pengguna; kredit sumber dan kontributor tetap melekat pada setiap komponen.'
  },
  backend: {
    schemaVersion: '1.0.0',
    status: 'validated',
    centralRecordCount: 2122,
    completeCorpusMigrations: [
      {
        corpus: 'Discrete Mathematics: An Open Introduction 4 — Bahasa Indonesia',
        recordCount: 163583,
        result: 'lossless-zero-copy-pass'
      },
      {
        corpus: 'Hefferon — Linear Algebra, Bahasa Indonesia v2026.08.22',
        recordCount: 22131,
        result: 'lossless-zero-copy-one-to-one-native-backend-adapter-pass'
      },
      {
        corpus: 'Komputasi Matematis dan Eksperimen yang Dapat Direproduksi — Bahasa Indonesia',
        recordCount: 339,
        result: 'lossless-zero-copy-one-to-one-native-catalog-adapter-pass'
      },
      {
        corpus: 'Open Logic Project — OLP-0722, Bahasa Indonesia',
        recordCount: 6522,
        result: 'deterministic-zero-copy-pass'
      },
      {
        corpus: 'Judson — Abstract Algebra: Theory and Applications, Bahasa Indonesia',
        recordCount: 36978,
        result: 'additive-zero-copy-pass'
      },
      {
        corpus: 'Yet Another Introductory Number Theory Textbook, Bahasa Indonesia',
        recordCount: 6967,
        result: 'lossless-additive-adapter-pass'
      },
      {
        corpus: 'Keller–Trotter — Applied Combinatorics, Bahasa Indonesia',
        recordCount: 19049,
        result: 'lossless-additive-one-common-record-per-native-record-pass'
      },
      {
        corpus: 'Mathematics in Lean — Bahasa Indonesia v4.30.0-id.3',
        recordCount: 10978,
        result: 'lossless-zero-copy-one-to-one-pass'
      },
      {
        corpus: 'OpenStax Prealgebra 2e — Bahasa Indonesia v0.2.7',
        recordCount: 523046,
        result: 'lossless-streaming-zero-copy-adapter-pass'
      },
      {
        corpus: 'Lega v1.01 — Pemodelan Matematis, Bahasa Indonesia',
        recordCount: 16029,
        result: 'lossless-replayable-zero-copy-adapter-pass'
      },
      {
        corpus: 'Open Optimization Book 1 + laboratorium Pyomo/HiGHS O018, Bahasa Indonesia',
        recordCount: 25805,
        result: 'lossless-zero-copy-one-to-one-plus-segment-variant-projection-pass'
      },
      {
        corpus: 'Tea Time Numerical Analysis — Bahasa Indonesia v3.0-id.2-r1',
        recordCount: 53055,
        result: 'additive-zero-copy-virtual-adapter-pass'
      }
    ],
    schema: 'https://zenodo.org/records/22088577/files/interlanguage-math-backend-v1.schema.json?download=1',
    sourceFormatProfile: 'https://zenodo.org/records/22088577/files/interlanguage-source-format-profile-v1.schema.json?download=1',
    package: 'https://zenodo.org/records/22088577/files/program-matematika-indonesia-backend-v1-v0.52.0.zip?download=1',
    federationV2: {
      version: '0.1.0',
      status: 'validated',
      recordCount: 2439,
      datasetCount: 34,
      courseCount: 40,
      learnerSurfaceCount: 136,
      webRouteCount: 41,
      identityCrosswalkCount: 2122,
      package: 'https://zenodo.org/records/22088577/files/program-matematika-indonesia-backend-v2-v0.52.0.zip?download=1',
      packageSchema: 'https://zenodo.org/records/22088577/files/federation-package-v2.schema.json?download=1',
      recordSchema: 'https://zenodo.org/records/22088577/files/federation-record-v2.schema.json?download=1',
      validationReceipt: 'https://zenodo.org/records/22088577/files/GLOBAL_BACKEND_V2_PHASE1_VALIDATION_RECEIPT_v0.52.0.json?download=1'
    }
  },
  repositories: {
    github: {
      url: 'https://github.com/KokunoYumeto/program-matematika-indonesia',
      status: 'available',
      lastConfirmedAt: '2026-08-25'
    }
  },
  status: 'in-progress'
});
